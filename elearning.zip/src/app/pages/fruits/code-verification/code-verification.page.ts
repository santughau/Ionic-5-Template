import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-code-verification',
  templateUrl: './code-verification.page.html',
  styleUrls: ['./code-verification.page.scss'],
})
export class CodeVerificationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
