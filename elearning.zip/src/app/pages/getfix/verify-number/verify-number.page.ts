import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-number',
  templateUrl: './verify-number.page.html',
  styleUrls: ['./verify-number.page.scss'],
})
export class VerifyNumberPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
