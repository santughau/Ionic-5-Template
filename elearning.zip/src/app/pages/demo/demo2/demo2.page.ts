import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo2',
  templateUrl: './demo2.page.html',
  styleUrls: ['./demo2.page.scss'],
})
export class Demo2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
