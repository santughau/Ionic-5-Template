(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_next_next6_next6_module_ts"],{

/***/ 42562:
/*!**********************************************************!*\
  !*** ./src/app/pages/next/next6/next6-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Next6PageRoutingModule": () => (/* binding */ Next6PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _next6_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./next6.page */ 77451);




const routes = [
    {
        path: '',
        component: _next6_page__WEBPACK_IMPORTED_MODULE_0__.Next6Page
    }
];
let Next6PageRoutingModule = class Next6PageRoutingModule {
};
Next6PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Next6PageRoutingModule);



/***/ }),

/***/ 10823:
/*!**************************************************!*\
  !*** ./src/app/pages/next/next6/next6.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Next6PageModule": () => (/* binding */ Next6PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _next6_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./next6-routing.module */ 42562);
/* harmony import */ var _next6_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./next6.page */ 77451);







let Next6PageModule = class Next6PageModule {
};
Next6PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _next6_routing_module__WEBPACK_IMPORTED_MODULE_0__.Next6PageRoutingModule
        ],
        declarations: [_next6_page__WEBPACK_IMPORTED_MODULE_1__.Next6Page]
    })
], Next6PageModule);



/***/ }),

/***/ 77451:
/*!************************************************!*\
  !*** ./src/app/pages/next/next6/next6.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Next6Page": () => (/* binding */ Next6Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_next6_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./next6.page.html */ 74448);
/* harmony import */ var _next6_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./next6.page.scss */ 39251);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 29535);





let Next6Page = class Next6Page {
    constructor(_router) {
        this._router = _router;
        this.slideOpts = {
            slidesPerView: 1.5
        };
    }
    ngOnInit() {
        this.students = [
            {
                img: 'assets/1.jpg',
                name: 'Miss Priyanka'
            },
            {
                img: 'assets/2.jpg',
                name: 'Miss Yamini'
            },
            {
                img: 'assets/4.jpg',
                name: 'Miss Laxmi'
            },
            {
                img: 'assets/6.jpg',
                name: 'Miss Piyusha'
            },
            {
                img: 'assets/8.jpg',
                name: 'Miss Swara'
            }
        ];
    }
    goBack() {
        this._router.navigate(['/home1']);
    }
};
Next6Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
Next6Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-next6',
        template: _raw_loader_next6_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_next6_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Next6Page);



/***/ }),

/***/ 39251:
/*!**************************************************!*\
  !*** ./src/app/pages/next/next6/next6.page.scss ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".main_content_div {\n  width: 100%;\n}\n.main_content_div .back_div {\n  width: 100%;\n  height: 350px;\n  background: linear-gradient(to right, #2F0743, #41295a);\n  border-bottom-right-radius: 50%;\n  border-bottom-left-radius: 50%;\n  border-top-right-radius: 50%;\n  position: relative;\n}\n.main_content_div .back_div .back_btn {\n  font-size: 30px;\n  left: 16px;\n  top: 40px;\n  position: absolute;\n}\n.main_content_div .back_div .white_div {\n  height: 130px;\n  width: 130px;\n  background: white;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .back_div img {\n  width: 70px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .bottom_div {\n  padding: 20px;\n  padding-top: 100px;\n}\n.main_content_div .bottom_div .slide_div {\n  display: flex;\n  align-items: center;\n  text-align: left;\n}\n.main_content_div .bottom_div .slide_div .user_back {\n  height: 70px;\n  width: 70px;\n  min-width: 70px;\n  border-radius: 100%;\n  background-position: top;\n  z-index: 999;\n}\n.main_content_div .bottom_div .slide_div .bg_image {\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n.main_content_div .bottom_div .slide_div .content_div {\n  margin-left: -20px;\n  padding-left: 25px;\n  padding-right: 25px;\n  height: 50px;\n  background: #2F0743;\n  color: white;\n  border-top-right-radius: 25px;\n  border-bottom-right-radius: 25px;\n  z-index: 0;\n  display: flex;\n  align-items: center;\n}\n.main_content_div .bottom_div .slide_div .content_div ion-label {\n  display: block;\n  font-size: 14px;\n}\n.main_content_div .bottom_div .btn_div {\n  margin-top: 50px;\n  text-align: center;\n}\n.main_content_div .bottom_div .btn_div ion-button {\n  color: #2F0743;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5leHQ2LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJQTtFQUNJLFdBQUE7QUFISjtBQUlJO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSx1REFBQTtFQUNBLCtCQUFBO0VBQ0EsOEJBQUE7RUFDQSw0QkFBQTtFQUVBLGtCQUFBO0FBSFI7QUFLUTtFQUNJLGVBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0FBSFo7QUFNUTtFQUNJLGFBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxRQUFBO0VBQ0EsZ0NBQUE7QUFKWjtBQU9RO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtBQUxaO0FBU0k7RUFDSSxhQUFBO0VBQ0Esa0JBQUE7QUFQUjtBQVFRO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFOWjtBQVFZO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSx3QkFBQTtFQUNBLFlBQUE7QUFOaEI7QUFTWTtFQUNJLDJCQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtBQVBoQjtBQVVZO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBUmhCO0FBU2dCO0VBQ0ksY0FBQTtFQUNBLGVBQUE7QUFQcEI7QUFZUTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUFWWjtBQVdZO0VBQ0ksY0FBQTtBQVRoQiIsImZpbGUiOiJuZXh0Ni5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcclxuXHJcbn1cclxuXHJcbi5tYWluX2NvbnRlbnRfZGl2e1xyXG4gICAgd2lkdGg6MTAwJTtcclxuICAgIC5iYWNrX2RpdntcclxuICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIGhlaWdodDogMzUwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KCB0byByaWdodCwgIzJGMDc0MywgIzQxMjk1YSk7XHJcbiAgICAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDUwJTtcclxuICAgICAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDUwJTtcclxuICAgICAgICBcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgICAgIC5iYWNrX2J0bntcclxuICAgICAgICAgICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgICAgICAgICBsZWZ0OjE2cHg7XHJcbiAgICAgICAgICAgIHRvcDo0MHB4O1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAud2hpdGVfZGl2e1xyXG4gICAgICAgICAgICBoZWlnaHQ6MTMwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOjEzMHB4O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgIGxlZnQ6NTAlO1xyXG4gICAgICAgICAgICB0b3A6NTAlO1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaW1ne1xyXG4gICAgICAgICAgICB3aWR0aDogNzBweDtcclxuICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHRvcDogNTAlO1xyXG4gICAgICAgICAgICBsZWZ0OiA1MCU7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5ib3R0b21fZGl2e1xyXG4gICAgICAgIHBhZGRpbmc6MjBweDtcclxuICAgICAgICBwYWRkaW5nLXRvcDoxMDBweDtcclxuICAgICAgICAuc2xpZGVfZGl2e1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG5cclxuICAgICAgICAgICAgLnVzZXJfYmFja3tcclxuICAgICAgICAgICAgICAgIGhlaWdodDo3MHB4O1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6NzBweDtcclxuICAgICAgICAgICAgICAgIG1pbi13aWR0aDogNzBweDtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiB0b3A7XHJcbiAgICAgICAgICAgICAgICB6LWluZGV4OiA5OTk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5iZ19pbWFnZXtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuY29udGVudF9kaXZ7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDotMjBweDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDoyNXB4O1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDogMjVweDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDo1MHB4O1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDojMkYwNzQzO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDI1cHg7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjVweDtcclxuICAgICAgICAgICAgICAgIHotaW5kZXg6IDA7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OmZsZXg7XHJcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZToxNHB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuYnRuX2RpdntcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDo1MHB4O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojMkYwNzQzO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxufSJdfQ== */");

/***/ }),

/***/ 74448:
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/next/next6/next6.page.html ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"main_content_div\">\n    <div class=\"back_div\">\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"light\" class=\"back_btn\"></ion-icon>\n\n      <div class=\"white_div\">\n        <img src=\"../../../../assets/statistics.png\" />\n      </div>\n    </div>\n\n    <div class=\"bottom_div\">\n      <ion-slides [options]=\"slideOpts\">\n        <ion-slide *ngFor=\"let item of students\">\n          <div class=\"slide_div\">\n            <div class=\"user_back bg_image\" [style.backgroundImage]=\"'url( '+item.img+' )'\"></div>\n            <div class=\"content_div\">\n              <ion-label>{{item.name}}</ion-label>\n            </div>\n          </div>\n        </ion-slide>\n      </ion-slides>\n\n      <div class=\"btn_div\">\n        <ion-button (click)=\"goToSubjectDetails()\" fill=\"outline\" shape=\"round\">\n          Next\n        </ion-button>\n      </div>\n    </div>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_next_next6_next6_module_ts.js.map