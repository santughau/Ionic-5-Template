(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_profile_profile2_profile2_module_ts"],{

/***/ 22055:
/*!*******************************************************************!*\
  !*** ./src/app/pages/profile/profile2/profile2-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Profile2PageRoutingModule": () => (/* binding */ Profile2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _profile2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile2.page */ 52530);




const routes = [
    {
        path: '',
        component: _profile2_page__WEBPACK_IMPORTED_MODULE_0__.Profile2Page
    }
];
let Profile2PageRoutingModule = class Profile2PageRoutingModule {
};
Profile2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Profile2PageRoutingModule);



/***/ }),

/***/ 23121:
/*!***********************************************************!*\
  !*** ./src/app/pages/profile/profile2/profile2.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Profile2PageModule": () => (/* binding */ Profile2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _profile2_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile2-routing.module */ 22055);
/* harmony import */ var _profile2_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile2.page */ 52530);







let Profile2PageModule = class Profile2PageModule {
};
Profile2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _profile2_routing_module__WEBPACK_IMPORTED_MODULE_0__.Profile2PageRoutingModule
        ],
        declarations: [_profile2_page__WEBPACK_IMPORTED_MODULE_1__.Profile2Page]
    })
], Profile2PageModule);



/***/ }),

/***/ 52530:
/*!*********************************************************!*\
  !*** ./src/app/pages/profile/profile2/profile2.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Profile2Page": () => (/* binding */ Profile2Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_profile2_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./profile2.page.html */ 14052);
/* harmony import */ var _profile2_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile2.page.scss */ 18822);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let Profile2Page = class Profile2Page {
    constructor() { }
    ngOnInit() {
    }
};
Profile2Page.ctorParameters = () => [];
Profile2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-profile2',
        template: _raw_loader_profile2_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_profile2_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Profile2Page);



/***/ }),

/***/ 18822:
/*!***********************************************************!*\
  !*** ./src/app/pages/profile/profile2/profile2.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".main_content_div {\n  width: 100%;\n}\n.main_content_div .menu_btn {\n  position: absolute;\n  top: 40px;\n  left: 10;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .user_div {\n  padding: 20px;\n  width: 100%;\n  height: 260px;\n  background: linear-gradient(to right, #045de9, #09c6f9);\n  display: flex;\n  justify-content: space-between;\n  padding-top: 40px;\n}\n.main_content_div .user_div .first_div {\n  padding-top: 70px;\n}\n.main_content_div .user_div .first_div .username {\n  font-size: 18px;\n  color: white;\n  font-weight: 600;\n}\n.main_content_div .user_div .user_back {\n  height: 100px;\n  width: 80px;\n  border: 3px solid white;\n  background-position: top;\n  background-size: cover;\n  background-repeat: no-repeat;\n  border-radius: 7px;\n}\n.main_content_div .content_div {\n  background: white;\n  width: 100%;\n  border-top-left-radius: 75px;\n  border-top-right-radius: 75px;\n  margin-top: -90px;\n  padding: 20px;\n  padding-top: 30px;\n}\n.main_content_div .content_div .test_detail {\n  width: 100%;\n  border-radius: 5px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n  padding: 10px;\n}\n.main_content_div .content_div .test_detail ion-grid {\n  padding: 0;\n}\n.main_content_div .content_div .test_detail ion-grid ion-col {\n  padding: 10px;\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div {\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div .round_div {\n  height: 40px;\n  width: 40px;\n  border-radius: 100%;\n  background: #045de9;\n  position: relative;\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div .round_div img {\n  width: 30px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div .details {\n  padding-left: 5px;\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div .details .bold_lbl {\n  font-weight: 600;\n  font-size: 14px;\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div .details .small_lbl {\n  font-size: 12px;\n}\n.main_content_div .content_div .list_div {\n  display: flex;\n  justify-content: space-between;\n  border-radius: 5px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n  margin-top: 20px;\n  padding: 15px;\n}\n.main_content_div .content_div .list_div ion-icon {\n  font-size: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2ZpbGUyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUFDSjtBQUFJO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0VBQ0EsUUFBQTtBQUVSO0FBQ0k7RUFDSSxjQUFBO0FBQ1I7QUFDSTtFQUNJLGFBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLHVEQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsaUJBQUE7QUFDUjtBQUNRO0VBQ0EsaUJBQUE7QUFDUjtBQUFZO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUVoQjtBQUNJO0VBQ0ksYUFBQTtFQUNBLFdBQUE7RUFDQSx1QkFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7RUFDQSw0QkFBQTtFQUNBLGtCQUFBO0FBQ1I7QUFFSTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtBQUFKO0FBQ0k7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtFQUNBLGFBQUE7QUFDUjtBQUFRO0VBQ0ksVUFBQTtBQUVaO0FBRFk7RUFDSSxhQUFBO0FBR2hCO0FBRFk7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQUdoQjtBQUZnQjtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBSXBCO0FBSG9CO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtBQUt4QjtBQUZnQjtFQUNJLGlCQUFBO0FBSXBCO0FBSG9CO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0FBS3hCO0FBRm9CO0VBQ0ksZUFBQTtBQUl4QjtBQUdJO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtBQURSO0FBR1E7RUFDSSxlQUFBO0FBRFoiLCJmaWxlIjoicHJvZmlsZTIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW5fY29udGVudF9kaXZ7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIC5tZW51X2J0bntcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgdG9wOjQwcHg7XHJcbiAgICAgICAgbGVmdDoxMDtcclxuICAgIH1cclxuXHJcbiAgICBpb24tbGFiZWwge1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgfVxyXG4gICAgLnVzZXJfZGl2e1xyXG4gICAgICAgIHBhZGRpbmc6IDIwcHg7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgaGVpZ2h0OiAyNjBweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCggdG8gcmlnaHQsICMwNDVkZTkgLCAjMDljNmY5ICk7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6c3BhY2UtYmV0d2VlbjtcclxuICAgICAgICBwYWRkaW5nLXRvcDo0MHB4O1xyXG4gICAgXHJcbiAgICAgICAgLmZpcnN0X2RpdntcclxuICAgICAgICBwYWRkaW5nLXRvcDo3MHB4O1xyXG4gICAgICAgICAgICAudXNlcm5hbWV7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgLnVzZXJfYmFja3tcclxuICAgICAgICBoZWlnaHQ6MTAwcHg7XHJcbiAgICAgICAgd2lkdGg6IDgwcHg7XHJcbiAgICAgICAgYm9yZGVyOjNweCBzb2xpZCB3aGl0ZTtcclxuICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiB0b3A7XHJcbiAgICAgICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6N3B4IDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAuY29udGVudF9kaXZ7XHJcbiAgICBiYWNrZ3JvdW5kOndoaXRlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOjc1cHg7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czo3NXB4O1xyXG4gICAgbWFyZ2luLXRvcDotOTBweDtcclxuICAgIHBhZGRpbmc6MjBweDtcclxuICAgIHBhZGRpbmctdG9wOjMwcHg7XHJcbiAgICAudGVzdF9kZXRhaWx7XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLDAsMCwwLjMpO1xyXG4gICAgICAgIHBhZGRpbmc6MTBweDtcclxuICAgICAgICBpb24tZ3JpZHtcclxuICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgaW9uLWNvbHtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6MTBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuZmxleF9kaXZ7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OmZsZXg7XHJcbiAgICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjpyb3c7XHJcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgLnJvdW5kX2RpdntcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6NDBweDtcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDo0MHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6MTAwJTtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiMwNDVkZTk7XHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246cmVsYXRpdmU7XHJcbiAgICAgICAgICAgICAgICAgICAgaW1ne1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDozMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG9wOjUwJTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGVmdDo1MCU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLmRldGFpbHN7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiA1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgLmJvbGRfbGJse1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6MTRweDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC5zbWFsbF9sYmx7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLmxpc3RfZGl2e1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OnNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czo1cHg7XHJcbiAgICAgICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLDAsMCwwLjMpO1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICAgICAgcGFkZGluZzoxNXB4O1xyXG5cclxuICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG59XHJcblxyXG4iXX0= */");

/***/ }),

/***/ 14052:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile2/profile2.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"main_content_div\">\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n\n    <div class=\"user_div\">\n      <div class=\"first_div\">\n        <ion-label class=\"username\">Yamini</ion-label>\n      </div>\n      <div class=\"user_back\" [style.backgroundImage]=\"'url(assets/14.jpg)'\"></div>\n    </div>\n\n    <div class=\"content_div\">\n      <div class=\"test_detail\">\n        <ion-grid fixed>\n          <ion-row>\n            <ion-col size=\"6\">\n              <div class=\"flex_div\">\n                <div class=\"round_div\">\n                  <img src=\"../../../../assets/idea.png\">\n                </div>\n\n                <div class=\"details\">\n                  <ion-label class=\"bold_lbl\">100</ion-label>\n                  <ion-label class=\"small_lbl\">Attempt</ion-label>\n                </div>\n              </div>\n            </ion-col>\n            <ion-col size=\"6\">\n              <div class=\"flex_div\">\n                <div class=\"round_div\">\n                  <img src=\"../../../../assets/clock.png\">\n                </div>\n\n                <div class=\"details\">\n                  <ion-label class=\"bold_lbl\">2Hr 10 Min</ion-label>\n                  <ion-label class=\"small_lbl\">Time</ion-label>\n                </div>\n              </div>\n            </ion-col>\n            <ion-col size=\"6\">\n              <div class=\"flex_div\">\n                <div class=\"round_div\">\n                  <img src=\"../../../../assets/speed.png\">\n                </div>\n\n                <div class=\"details\">\n                  <ion-label class=\"bold_lbl\">70Q/Hr</ion-label>\n                  <ion-label class=\"small_lbl\">Speed</ion-label>\n                </div>\n              </div>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </div>\n\n      <div class=\"list_div\">\n        <ion-label>Edit Profile</ion-label>\n        <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n      </div>\n\n      <div class=\"list_div\">\n        <ion-label>Test List</ion-label>\n        <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n      </div>\n\n      <div class=\"list_div\">\n        <ion-label>Faviourite Books</ion-label>\n        <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n      </div>\n\n      <div class=\"list_div\">\n        <ion-label>Log Out</ion-label>\n        <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n      </div>\n    </div>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_profile2_profile2_module_ts.js.map