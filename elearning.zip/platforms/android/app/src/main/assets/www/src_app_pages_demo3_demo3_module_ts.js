(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_demo3_demo3_module_ts"],{

/***/ 50064:
/*!*****************************************************!*\
  !*** ./src/app/pages/demo3/demo3-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Demo3PageRoutingModule": () => (/* binding */ Demo3PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _demo3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./demo3.page */ 15744);




const routes = [
    {
        path: '',
        component: _demo3_page__WEBPACK_IMPORTED_MODULE_0__.Demo3Page
    }
];
let Demo3PageRoutingModule = class Demo3PageRoutingModule {
};
Demo3PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Demo3PageRoutingModule);



/***/ }),

/***/ 21002:
/*!*********************************************!*\
  !*** ./src/app/pages/demo3/demo3.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Demo3PageModule": () => (/* binding */ Demo3PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _demo3_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./demo3-routing.module */ 50064);
/* harmony import */ var _demo3_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./demo3.page */ 15744);







let Demo3PageModule = class Demo3PageModule {
};
Demo3PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _demo3_routing_module__WEBPACK_IMPORTED_MODULE_0__.Demo3PageRoutingModule
        ],
        declarations: [_demo3_page__WEBPACK_IMPORTED_MODULE_1__.Demo3Page]
    })
], Demo3PageModule);



/***/ }),

/***/ 15744:
/*!*******************************************!*\
  !*** ./src/app/pages/demo3/demo3.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Demo3Page": () => (/* binding */ Demo3Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_demo3_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./demo3.page.html */ 48499);
/* harmony import */ var _demo3_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./demo3.page.scss */ 45199);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 29535);





let Demo3Page = class Demo3Page {
    constructor(_router) {
        this._router = _router;
    }
    ngOnInit() {
    }
    goBack() {
        this._router.navigate(['/home1']);
    }
};
Demo3Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
Demo3Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-demo3',
        template: _raw_loader_demo3_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_demo3_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Demo3Page);



/***/ }),

/***/ 45199:
/*!*********************************************!*\
  !*** ./src/app/pages/demo3/demo3.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap\");\nion-content {\n  --background: #f1f5f9;\n}\nion-content .main {\n  width: 100%;\n  height: 100%;\n  position: relative;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content .main .header {\n  background-color: #FF6EA1;\n  height: 100px;\n  box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);\n}\nion-content .main .header .back_btn {\n  font-size: 30px;\n  left: 16px;\n  top: 40px;\n  position: absolute;\n}\nion-content .main .header ion-label {\n  position: absolute;\n  top: 40px;\n  left: 55px;\n  color: #fff;\n  font-size: 25px;\n}\nion-content .main .profile {\n  position: absolute;\n  top: 50px;\n  right: 25px;\n}\nion-content .main .profile img {\n  border-radius: 50%;\n  width: 100px;\n  height: 100px;\n}\nion-content .main .editProfile {\n  position: absolute;\n  top: 160px;\n  right: 25px;\n}\nion-content .main .editProfile .profileBtn {\n  padding: 10px 20px;\n  border: 1px solid #FF6EA1;\n  background: rgba(255, 110, 161, 0.09);\n  color: #FF6EA1;\n}\nion-content .main .statics {\n  width: 70%;\n  margin-top: 30px;\n  margin-left: 20px;\n}\nion-content .main .statics .staticsNumber {\n  font-size: 30px;\n  color: #FF6EA1;\n}\nion-content .main .statics .staticsText {\n  font-size: 10px;\n  color: gray;\n  margin-top: -10px;\n}\nion-content .main .account {\n  padding: 20px;\n}\nion-content .main .account .accountDiv {\n  background: #fff;\n  width: 100%;\n  height: 100px;\n  margin-top: 10px;\n}\nion-content .main .account .accountDiv ion-icon {\n  color: #FF6EA1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlbW8zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBUSw2RkFBQTtBQUNSO0VBQ0kscUJBQUE7QUFDSjtBQUFBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtDQUFBO0FBRUo7QUFESTtFQUNJLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLDBDQUFBO0FBR1I7QUFGUTtFQUNJLGVBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0FBSVo7QUFGUTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQUlaO0FBREk7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0FBR1I7QUFGUTtFQUNJLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUFJWjtBQURJO0VBQ0ksa0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtBQUdSO0FBRlE7RUFDSSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EscUNBQUE7RUFDQSxjQUFBO0FBSVo7QUFESTtFQUNJLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBR1I7QUFGUTtFQUNJLGVBQUE7RUFDQSxjQUFBO0FBSVo7QUFGUTtFQUNLLGVBQUE7RUFDRCxXQUFBO0VBQ0EsaUJBQUE7QUFJWjtBQURJO0VBQ0ksYUFBQTtBQUdSO0FBRFE7RUFDSSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0MsZ0JBQUE7QUFHYjtBQUZhO0VBQ0ksY0FBQTtBQUlqQiIsImZpbGUiOiJkZW1vMy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1Qb3BwaW5zOndnaHRANDAwOzUwMDs3MDAmZGlzcGxheT1zd2FwJyk7XHJcbmlvbi1jb250ZW50e1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZjFmNWY5O1xyXG4ubWFpbntcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIC5oZWFkZXJ7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0ZGNkVBMTtcclxuICAgICAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDJweCAycHggNXB4IHJnYigwIDAgMCAvIDIwJSk7XHJcbiAgICAgICAgLmJhY2tfYnRue1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICAgICAgICAgIGxlZnQ6MTZweDtcclxuICAgICAgICAgICAgdG9wOjQwcHg7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHRvcDo0MHB4O1xyXG4gICAgICAgICAgICBsZWZ0OjU1cHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZToyNXB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5wcm9maWxle1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB0b3A6NTBweDtcclxuICAgICAgICByaWdodDoyNXB4O1xyXG4gICAgICAgIGltZ3tcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICB3aWR0aDoxMDBweDtcclxuICAgICAgICAgICAgaGVpZ2h0OjEwMHB4O1xyXG4gICAgICAgIH0gICAgICAgIFxyXG4gICAgfVxyXG4gICAgLmVkaXRQcm9maWxle1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB0b3A6MTYwcHg7XHJcbiAgICAgICAgcmlnaHQ6MjVweDtcclxuICAgICAgICAucHJvZmlsZUJ0bnsgICAgICAgICAgIFxyXG4gICAgICAgICAgICBwYWRkaW5nOjEwcHggMjBweDtcclxuICAgICAgICAgICAgYm9yZGVyOjFweCBzb2xpZCAjRkY2RUExO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwxMTAsMTYxLDAuMDkpO1xyXG4gICAgICAgICAgICBjb2xvcjojRkY2RUExXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLnN0YXRpY3N7XHJcbiAgICAgICAgd2lkdGg6NzAlO1xyXG4gICAgICAgIG1hcmdpbi10b3A6MzBweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICAgICAgICAuc3RhdGljc051bWJlcntcclxuICAgICAgICAgICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgICAgICAgICBjb2xvcjojRkY2RUExOyAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICAuc3RhdGljc1RleHR7XHJcbiAgICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICAgICAgICAgIGNvbG9yOmdyYXk7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6LTEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmFjY291bnR7XHJcbiAgICAgICAgcGFkZGluZzoyMHB4O1xyXG4gICAgICAgXHJcbiAgICAgICAgLmFjY291bnREaXZ7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6I2ZmZjtcclxuICAgICAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICAgICAgaGVpZ2h0OjEwMHB4O1xyXG4gICAgICAgICAgICAgbWFyZ2luLXRvcDoxMHB4O1xyXG4gICAgICAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgICAgICAgY29sb3I6I0ZGNkVBMTtcclxuICAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxufSJdfQ== */");

/***/ }),

/***/ 48499:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/demo3/demo3.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"main\">\n    <div class=\"header\">\n      <div class=\"back_div\">\n        <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"light\" class=\"back_btn\"></ion-icon>\n      </div>\n      <ion-label>Yamini Sontakke</ion-label>\n    </div>\n    <div class=\"profile\">\n      <img src=\"../../../assets/14.jpg\" />\n    </div>\n    <div class=\"editProfile\">\n      <button class=\"profileBtn\">Edit Profile</button>\n    </div>\n    <div class=\"statics\">\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <div class=\"staticsNumber\">21</div>\n            <div class=\"staticsText\">Books</div>\n          </ion-col>\n          <ion-col>\n            <div class=\"staticsNumber\">50K</div>\n            <div class=\"staticsText\">Followers</div>\n          </ion-col>\n          <ion-col>\n            <div class=\"staticsNumber\">30</div>\n            <div class=\"staticsText\">Following</div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n    <div class=\"account\">\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <ion-label>Account</ion-label>\n            <div class=\"accountDiv\">\n              <ion-item>\n                <ion-icon name=\"cart\" slot=\"start\"></ion-icon>\n                <ion-label>\n                  My Cart\n                </ion-label>\n              </ion-item>\n\n              <ion-item>\n                <ion-icon name=\"wallet\" slot=\"start\"></ion-icon>\n                <ion-label>\n                  Purchase\n                </ion-label>\n              </ion-item>\n\n              <ion-item>\n                <ion-icon name=\"person\" slot=\"start\"></ion-icon>\n                <ion-label>\n                  Account\n                </ion-label>\n              </ion-item>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n\n    \n    <div class=\"account\">\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <ion-label>Setting</ion-label>\n            <div class=\"accountDiv\">\n              <ion-item>\n                <ion-icon color=\"dark\" name=\"moon\" slot=\"start\"></ion-icon>\n                <ion-label>\n                 Night Mode\n                </ion-label>\n              </ion-item>\n    \n              <ion-item>\n                <ion-icon name=\"notifications\" slot=\"start\"></ion-icon>\n                <ion-label>\n                  Notification\n                </ion-label>\n              </ion-item>\n    \n              <ion-item>\n                <ion-icon name=\"globe\" slot=\"start\"></ion-icon>\n                <ion-label>\n                  Language\n                </ion-label>\n              </ion-item>\n\n              <ion-item>\n                <ion-icon name=\"information-circle\" slot=\"start\"></ion-icon>\n                <ion-label>\n                  Help\n                </ion-label>\n              </ion-item>\n\n              <ion-item>\n                <ion-icon name=\"log-in\" slot=\"start\"></ion-icon>\n                <ion-label>\n                  Sign Out\n                </ion-label>\n              </ion-item>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_demo3_demo3_module_ts.js.map