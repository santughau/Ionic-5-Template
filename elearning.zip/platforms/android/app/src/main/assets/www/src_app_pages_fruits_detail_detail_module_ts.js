(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_fruits_detail_detail_module_ts"],{

/***/ 60288:
/*!**************************************************************!*\
  !*** ./src/app/pages/fruits/detail/detail-routing.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPageRoutingModule": () => (/* binding */ DetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail.page */ 23871);




const routes = [
    {
        path: '',
        component: _detail_page__WEBPACK_IMPORTED_MODULE_0__.DetailPage
    }
];
let DetailPageRoutingModule = class DetailPageRoutingModule {
};
DetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DetailPageRoutingModule);



/***/ }),

/***/ 54148:
/*!******************************************************!*\
  !*** ./src/app/pages/fruits/detail/detail.module.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPageModule": () => (/* binding */ DetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _detail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail-routing.module */ 60288);
/* harmony import */ var _detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail.page */ 23871);







let DetailPageModule = class DetailPageModule {
};
DetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _detail_routing_module__WEBPACK_IMPORTED_MODULE_0__.DetailPageRoutingModule
        ],
        declarations: [_detail_page__WEBPACK_IMPORTED_MODULE_1__.DetailPage]
    })
], DetailPageModule);



/***/ }),

/***/ 23871:
/*!****************************************************!*\
  !*** ./src/app/pages/fruits/detail/detail.page.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPage": () => (/* binding */ DetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_detail_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./detail.page.html */ 77009);
/* harmony import */ var _detail_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail.page.scss */ 35474);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let DetailPage = class DetailPage {
    constructor() { }
    ngOnInit() {
    }
};
DetailPage.ctorParameters = () => [];
DetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-detail',
        template: _raw_loader_detail_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DetailPage);



/***/ }),

/***/ 35474:
/*!******************************************************!*\
  !*** ./src/app/pages/fruits/detail/detail.page.scss ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".toolbar {\n  height: 84px;\n  --background:#69A03A;\n  color: #fff;\n  font-size: 20px;\n  line-height: 84px;\n}\n\nion-content img {\n  border-radius: 15px;\n}\n\nion-content .main_container ion-label {\n  color: gray;\n  font-weight: 600;\n}\n\nion-content .main_container .grapesPara {\n  text-align: justify;\n}\n\nion-footer .headingClass {\n  margin-left: 20px;\n  color: #69A03A;\n}\n\nion-footer .btn {\n  background: #69A03A;\n  padding: 10px 20px;\n  margin-top: 40px !important;\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0Esb0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBR0k7RUFDSSxtQkFBQTtBQUFSOztBQUdRO0VBQ0ksV0FBQTtFQUNBLGdCQUFBO0FBRFo7O0FBR1E7RUFDSSxtQkFBQTtBQURaOztBQU1JO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0FBSFI7O0FBS0k7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxXQUFBO0FBSFIiLCJmaWxlIjoiZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sYmFye1xyXG4gICAgaGVpZ2h0Ojg0cHg7XHJcbiAgICAtLWJhY2tncm91bmQ6IzY5QTAzQTtcclxuICAgIGNvbG9yOiNmZmY7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBsaW5lLWhlaWdodDo4NHB4O1xyXG59XHJcblxyXG5pb24tY29udGVudHtcclxuICAgIGltZ3tcclxuICAgICAgICBib3JkZXItcmFkaXVzOjE1cHg7XHJcbiAgICB9XHJcbiAgICAubWFpbl9jb250YWluZXJ7XHJcbiAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICBjb2xvcjpncmF5O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuZ3JhcGVzUGFyYXtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuaW9uLWZvb3RlcntcclxuICAgIC5oZWFkaW5nQ2xhc3N7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6MjBweDtcclxuICAgICAgICBjb2xvcjojNjlBMDNBO1xyXG4gICAgfVxyXG4gICAgLmJ0bntcclxuICAgICAgICBiYWNrZ3JvdW5kOiM2OUEwM0E7XHJcbiAgICAgICAgcGFkZGluZzoxMHB4IDIwcHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogNDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICB9XHJcbn0iXX0= */");

/***/ }),

/***/ 77009:
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/fruits/detail/detail.page.html ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-back-button color=\"light\" defaultHref=\"home1\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Details</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <img src=\"../../../../assets/grapes.JPG\" />\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <div class=\"main_container\">\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-label>Grapes</ion-label>\n          <p class=\"grapesPara\">Grapes will provide natural nutrients. The Chemical\n            in organic grapes which can be healthier hair and\n            skin. It can be improve Your heart health. Protect your\n            body from Cancer.</p>\n          <ion-label>Nutrition</ion-label>\n          <ion-list>\n            <ion-item>\n              <ion-label>Pokémon Yellow</ion-label>\n            </ion-item>\n            <ion-item>\n              <ion-label>Mega Man X</ion-label>\n            </ion-item>\n            <ion-item>\n              <ion-label>The Legend of Zelda</ion-label>\n            </ion-item>\n            <ion-item>\n              <ion-label>Pac-Man</ion-label>\n            </ion-item>\n            <ion-item>\n              <ion-label>Super Mario World</ion-label>\n            </ion-item>\n          </ion-list>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n</ion-content>\n<ion-footer  class=\"ion-no-border\">\n  <ion-row>\n    <ion-col size=\"7\">\n      <ion-text>\n        <h4 class=\"headingClass\" >Rs 160 Per/Kg</h4>\n      </ion-text>\n    </ion-col>\n  \n    <ion-col size=\"5\">\n      <buttoon class=\"btn\">Buy Now</buttoon>\n    </ion-col>\n  </ion-row>\n</ion-footer>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_fruits_detail_detail_module_ts.js.map