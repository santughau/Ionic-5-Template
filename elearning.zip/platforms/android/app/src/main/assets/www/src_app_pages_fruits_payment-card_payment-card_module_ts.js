(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_fruits_payment-card_payment-card_module_ts"],{

/***/ 48359:
/*!**************************************************************************!*\
  !*** ./src/app/pages/fruits/payment-card/payment-card-routing.module.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentCardPageRoutingModule": () => (/* binding */ PaymentCardPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _payment_card_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-card.page */ 75382);




const routes = [
    {
        path: '',
        component: _payment_card_page__WEBPACK_IMPORTED_MODULE_0__.PaymentCardPage
    }
];
let PaymentCardPageRoutingModule = class PaymentCardPageRoutingModule {
};
PaymentCardPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PaymentCardPageRoutingModule);



/***/ }),

/***/ 54433:
/*!******************************************************************!*\
  !*** ./src/app/pages/fruits/payment-card/payment-card.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentCardPageModule": () => (/* binding */ PaymentCardPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _payment_card_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-card-routing.module */ 48359);
/* harmony import */ var _payment_card_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-card.page */ 75382);







let PaymentCardPageModule = class PaymentCardPageModule {
};
PaymentCardPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _payment_card_routing_module__WEBPACK_IMPORTED_MODULE_0__.PaymentCardPageRoutingModule
        ],
        declarations: [_payment_card_page__WEBPACK_IMPORTED_MODULE_1__.PaymentCardPage]
    })
], PaymentCardPageModule);



/***/ }),

/***/ 75382:
/*!****************************************************************!*\
  !*** ./src/app/pages/fruits/payment-card/payment-card.page.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentCardPage": () => (/* binding */ PaymentCardPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_payment_card_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./payment-card.page.html */ 96971);
/* harmony import */ var _payment_card_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-card.page.scss */ 3096);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let PaymentCardPage = class PaymentCardPage {
    constructor() {
        this.month = ['January', 'February', 'March', 'April', 'May',
            'June', 'Jully', 'August', 'September', 'October', 'November', 'December'];
        this.year = [];
    }
    ngOnInit() {
        for (let i = 2021; i < 2032; i++) {
            this.year.push(i);
        }
    }
};
PaymentCardPage.ctorParameters = () => [];
PaymentCardPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-payment-card',
        template: _raw_loader_payment_card_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_payment_card_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PaymentCardPage);



/***/ }),

/***/ 3096:
/*!******************************************************************!*\
  !*** ./src/app/pages/fruits/payment-card/payment-card.page.scss ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".toolbar {\n  height: 84px;\n  --background:#69A03A;\n  color: #fff;\n  font-size: 20px;\n  line-height: 84px;\n}\n.toolbar #userIcon {\n  color: #fff;\n  font-size: 2.5rem;\n  margin-right: 10px;\n}\n.container {\n  width: 100%;\n  padding: 20px;\n}\n.container .img {\n  margin: auto !important;\n  width: 100%;\n}\n.container .lbl {\n  color: #69A03A;\n  font-size: 20px;\n}\n.container ion-input {\n  border: 1px solid gray;\n  margin-top: 10px;\n  min-height: 45px !important;\n  padding-left: 20px !important;\n  border-radius: 5px;\n  --placeholder-color:#69A03A !important;\n}\n.container ion-checkbox {\n  width: 45px;\n  height: 45px;\n  margin-top: 10px;\n  float: left;\n}\n.container .cvv_lbl {\n  color: #69A03A;\n  font-size: 20px;\n  float: left;\n  margin-top: 20px;\n  margin-left: 20px;\n}\n.container .btn {\n  width: 100%;\n  padding: 10px 20px;\n  font-size: 20px;\n  background-color: #69A03A;\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBheW1lbnQtY2FyZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0Esb0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBQ0o7QUFBSTtFQUNJLFdBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBRVI7QUFFQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0FBQ0o7QUFBSTtFQUNJLHVCQUFBO0VBQ0EsV0FBQTtBQUVSO0FBQ0k7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQUNSO0FBQ0k7RUFDSSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0EsMkJBQUE7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0NBQUE7QUFDUjtBQUdJO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7QUFEUjtBQUlJO0VBQ0ssY0FBQTtFQUNELGVBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQUZSO0FBSUE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0FBRkoiLCJmaWxlIjoicGF5bWVudC1jYXJkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sYmFye1xyXG4gICAgaGVpZ2h0Ojg0cHg7XHJcbiAgICAtLWJhY2tncm91bmQ6IzY5QTAzQTtcclxuICAgIGNvbG9yOiNmZmY7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBsaW5lLWhlaWdodDo4NHB4O1xyXG4gICAgI3VzZXJJY29ue1xyXG4gICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgZm9udC1zaXplOjIuNXJlbTtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6MTBweDtcclxuICAgIH1cclxufVxyXG5cclxuLmNvbnRhaW5lcntcclxuICAgIHdpZHRoOjEwMCU7XHJcbiAgICBwYWRkaW5nOjIwcHg7XHJcbiAgICAuaW1ne1xyXG4gICAgICAgIG1hcmdpbjphdXRvICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgIH1cclxuICAgIFxyXG4gICAgLmxibHtcclxuICAgICAgICBjb2xvcjojNjlBMDNBO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIH1cclxuICAgIGlvbi1pbnB1dHtcclxuICAgICAgICBib3JkZXI6MXB4IHNvbGlkIGdyYXk7XHJcbiAgICAgICAgbWFyZ2luLXRvcDoxMHB4O1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6NDVweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIHBhZGRpbmctbGVmdDoyMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICAgIC0tcGxhY2Vob2xkZXItY29sb3I6IzY5QTAzQSAhaW1wb3J0YW50OyAgICAgICBcclxuICAgICAgICBcclxuICAgIH1cclxuICAgIFxyXG4gICAgaW9uLWNoZWNrYm94e1xyXG4gICAgICAgIHdpZHRoOjQ1cHg7XHJcbiAgICAgICAgaGVpZ2h0OjQ1cHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDoxMHB4O1xyXG4gICAgICAgIGZsb2F0OmxlZnQ7XHJcbiAgICB9XHJcblxyXG4gICAgLmN2dl9sYmx7XHJcbiAgICAgICAgIGNvbG9yOiM2OUEwM0E7XHJcbiAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICAgIG1hcmdpbi10b3A6MjBweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDoyMHB4O1xyXG4gICAgfVxyXG4uYnRue1xyXG4gICAgd2lkdGg6MTAwJTtcclxuICAgIHBhZGRpbmc6MTBweCAyMHB4O1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjojNjlBMDNBO1xyXG4gICAgY29sb3I6I2ZmZjtcclxuICAgIFxyXG5cclxufVxyXG4gICAgXHJcbn1cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ 96971:
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/fruits/payment-card/payment-card.page.html ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar class=\"toolbar\">\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-back-button color=\"light\" defaultHref=\"home1\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Add Your Card</ion-title>\n    <ion-buttons slot=\"end\" class=\"menu_btn\">\n      <ion-icon id=\"userIcon\" name=\"person-circle-outline\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content >\n  <div class=\"container\">\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <img src=\"../../../../assets/visaCard.png\" class=\"img\"/>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col class=\"ion-margin-top\">\n          <ion-label class=\"lbl\" position=\"stacked\">Card Holder Name</ion-label>\n          <ion-input placeholder=\"Yamini Sontakke\"></ion-input>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size=\"12\" class=\"ion-margin-top\">\n          <ion-label class=\"lbl\" position=\"stacked\">Card Number</ion-label>\n        </ion-col>\n\n        <ion-col size=\"3\">\n\n          <ion-input placeholder=\"2308\"></ion-input>\n        </ion-col>\n        <ion-col size=\"3\">\n          <ion-input placeholder=\"2308\"></ion-input>\n        </ion-col>\n        <ion-col size=\"3\">\n          <ion-input placeholder=\"2308\"></ion-input>\n        </ion-col>\n        <ion-col size=\"3\">\n          <ion-input placeholder=\"2308\"></ion-input>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size=\"6\" class=\"ion-margin-top\">\n          <ion-item style=\"border:1px solid gray; border-radius:5px;\">\n            <ion-label style=\"font-size:20px; color:#69A03A;\">Month</ion-label>\n            <ion-select mode=\"ios\" interface=\"action-sheet\" placeholder=\"Select One\">\n              <ion-select-option value=\"{{option}}\" *ngFor=\"let option of month\">{{option}}</ion-select-option>\n            </ion-select>\n          </ion-item>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-margin-top\">\n          <ion-item style=\"border:1px solid gray; border-radius:5px;\">\n            <ion-label style=\"font-size:20px; color:#69A03A;\">Year</ion-label>\n            <ion-select mode=\"ios\" interface=\"action-sheet\" placeholder=\"Select One\">\n              <ion-select-option  value=\"{{option}}\" *ngFor=\"let option of year\">{{option}}</ion-select-option>\n            </ion-select>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size=\"12\" class=\"ion-margin-top\">\n          <ion-label class=\"lbl\" position=\"stacked\">CVV / CVC</ion-label>\n        </ion-col>\n      \n        <ion-col size=\"4\">      \n          <ion-input placeholder=\"238\"></ion-input>\n        </ion-col>\n\n        <ion-col size=\"8\">\n          <ion-checkbox mode=\"ios\" color=\"danger\"></ion-checkbox>\n          <ion-label class=\"cvv_lbl\" >Make Default Card</ion-label>\n        </ion-col>\n        \n      </ion-row>\n\n      <ion-row>\n        <ion-col size=\"12\" class=\"ion-margin-top\">\n       <button class=\"btn\">Add Card Number</button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_fruits_payment-card_payment-card_module_ts.js.map