(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_subject_subject5_subject5_module_ts"],{

/***/ 15944:
/*!*******************************************************************!*\
  !*** ./src/app/pages/subject/subject5/subject5-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject5PageRoutingModule": () => (/* binding */ Subject5PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _subject5_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject5.page */ 30330);




const routes = [
    {
        path: '',
        component: _subject5_page__WEBPACK_IMPORTED_MODULE_0__.Subject5Page
    }
];
let Subject5PageRoutingModule = class Subject5PageRoutingModule {
};
Subject5PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Subject5PageRoutingModule);



/***/ }),

/***/ 96976:
/*!***********************************************************!*\
  !*** ./src/app/pages/subject/subject5/subject5.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject5PageModule": () => (/* binding */ Subject5PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _subject5_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject5-routing.module */ 15944);
/* harmony import */ var _subject5_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject5.page */ 30330);







let Subject5PageModule = class Subject5PageModule {
};
Subject5PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _subject5_routing_module__WEBPACK_IMPORTED_MODULE_0__.Subject5PageRoutingModule
        ],
        declarations: [_subject5_page__WEBPACK_IMPORTED_MODULE_1__.Subject5Page]
    })
], Subject5PageModule);



/***/ }),

/***/ 30330:
/*!*********************************************************!*\
  !*** ./src/app/pages/subject/subject5/subject5.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject5Page": () => (/* binding */ Subject5Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_subject5_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./subject5.page.html */ 83401);
/* harmony import */ var _subject5_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject5.page.scss */ 55192);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let Subject5Page = class Subject5Page {
    constructor() {
        this.segId = 'Chapters';
    }
    ngOnInit() {
        this.chapters = [
            {
                img: 'assets/light.jpg',
                name: 'Theory of Light',
                per: 90
            },
            {
                img: 'assets/water.jpg',
                name: 'Theory of Water',
                per: 40
            },
            {
                img: 'assets/motion.jpg',
                name: 'Theory of Motion',
                per: 50
            },
            {
                img: 'assets/sound.jpg',
                name: 'Theory of Sound',
                per: 65
            },
            {
                img: 'assets/sky.jpg',
                name: 'Theory of Sky',
                per: 75
            },
            {
                img: 'assets/energy.jpg',
                name: 'Theory of Energy',
                per: 45
            },
        ];
    }
    segmentChanged(eve) {
        this.segId = eve.details.value;
    }
};
Subject5Page.ctorParameters = () => [];
Subject5Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-subject5',
        template: _raw_loader_subject5_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_subject5_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Subject5Page);



/***/ }),

/***/ 55192:
/*!***********************************************************!*\
  !*** ./src/app/pages/subject/subject5/subject5.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".grad_back {\n  width: 100%;\n  height: 150px;\n  background: linear-gradient(to right, #f46b45, #eea849);\n  border-bottom-left-radius: 50px;\n  position: relative;\n}\n.grad_back .subject {\n  color: white;\n  font-weight: 600;\n  font-size: 24px;\n  position: absolute;\n  left: 150px;\n  bottom: 16px;\n}\n.grad_back .btn_flex {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  height: 50px;\n  align-items: center;\n  padding-top: 40px;\n}\n.grad_back ion-icon {\n  font-size: 20px;\n  color: white;\n}\n.main_content_div {\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .card_div {\n  padding: 10px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 10px;\n  margin-bottom: 15px;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  position: relative;\n}\n.main_content_div .card_div .download {\n  width: 18px;\n  position: absolute;\n  right: 10px;\n  top: 10px;\n  z-index: 99999;\n}\n.main_content_div .card_div .round_image {\n  height: 50px;\n  width: 50px;\n  border-radius: 50%;\n  min-width: 50px;\n}\n.main_content_div .card_div .content_div {\n  width: 100%;\n  padding-left: 10px;\n  position: relative;\n}\n.main_content_div .card_div .content_div .title_lbl {\n  font-size: 16px;\n  font-weight: 600;\n  color: #f46b45;\n}\n.main_content_div .card_div .content_div .small_lbl {\n  font-size: 12px;\n  color: gray;\n  margin-top: 5px;\n  margin-bottom: 5px;\n}\n.main_content_div .card_div .content_div .abs_lbl {\n  position: absolute;\n  right: 0;\n  bottom: 0;\n  font-size: 12px;\n  color: #f46b45;\n}\nion-segment-button {\n  --indicator-color:linear-gradient( to right, #f46b45 , #eea849) ;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1YmplY3Q1LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdURBQUE7RUFFQSwrQkFBQTtFQUNBLGtCQUFBO0FBQUo7QUFFSTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBQVI7QUFHSTtFQUNHLFdBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQURQO0FBSUk7RUFDRyxlQUFBO0VBQ0EsWUFBQTtBQUZQO0FBTUE7RUFDSSxhQUFBO0FBSEo7QUFLSTtFQUNJLGNBQUE7QUFIUjtBQU1JO0VBQ0ksYUFBQTtFQUNBLDBDQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFKUjtBQUtRO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxjQUFBO0FBSFo7QUFLUTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBSFo7QUFLUTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBSFo7QUFJWTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFGaEI7QUFLWTtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBSGhCO0FBS1k7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFIaEI7QUFZQTtFQUNJLGdFQUFBO0FBVEoiLCJmaWxlIjoic3ViamVjdDUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmdyYWRfYmFja3tcclxuICAgIHdpZHRoOjEwMCU7XHJcbiAgICBoZWlnaHQ6MTUwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoIHRvIHJpZ2h0LCAjZjQ2YjQ1ICwgI2VlYTg0OSk7XHJcbiAgICBcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDUwcHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgLnN1YmplY3R7XHJcbiAgICAgICAgY29sb3I6d2hpdGU7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgbGVmdDoxNTBweDtcclxuICAgICAgICBib3R0b206MTZweDtcclxuICAgIH1cclxuXHJcbiAgICAuYnRuX2ZsZXh7XHJcbiAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgZGlzcGxheTogZmxleDsgXHJcbiAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgcGFkZGluZy10b3A6IDQwcHg7XHJcbiAgICB9XHJcblxyXG4gICAgaW9uLWljb257XHJcbiAgICAgICBmb250LXNpemU6IDIwcHg7IFxyXG4gICAgICAgY29sb3I6d2hpdGU7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5tYWluX2NvbnRlbnRfZGl2e1xyXG4gICAgcGFkZGluZzoxNnB4O1xyXG5cclxuICAgIGlvbi1sYWJlbHtcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIH1cclxuXHJcbiAgICAuY2FyZF9kaXZ7XHJcbiAgICAgICAgcGFkZGluZzoxMHB4O1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwwLDAsMC4yKTtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgcG9zaXRpb246cmVsYXRpdmU7XHJcbiAgICAgICAgLmRvd25sb2Fke1xyXG4gICAgICAgICAgICB3aWR0aDogMThweDtcclxuICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHJpZ2h0OiAxMHB4O1xyXG4gICAgICAgICAgICB0b3A6MTBweDtcclxuICAgICAgICAgICAgei1pbmRleDogOTk5OTk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5yb3VuZF9pbWFnZXtcclxuICAgICAgICAgICAgaGVpZ2h0OjUwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOjUwJTtcclxuICAgICAgICAgICAgbWluLXdpZHRoOiA1MHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAuY29udGVudF9kaXZ7XHJcbiAgICAgICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDoxMHB4O1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICAgIC50aXRsZV9sYmx7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6I2Y0NmI0NTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLnNtYWxsX2xibHtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOmdyYXk7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLmFic19sYmx7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgIHJpZ2h0OiAwO1xyXG4gICAgICAgICAgICAgICAgYm90dG9tOiAwO1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6I2Y0NmI0NVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuXHJcblxyXG5pb24tc2VnbWVudC1idXR0b257XHJcbiAgICAtLWluZGljYXRvci1jb2xvcjpsaW5lYXItZ3JhZGllbnQoIHRvIHJpZ2h0LCAjZjQ2YjQ1ICwgI2VlYTg0OSlcclxufSJdfQ== */");

/***/ }),

/***/ 83401:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/subject/subject5/subject5.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <div class=\"grad_back\">\n    <div class=\"btn_flex\">\n      <div>\n        <ion-buttons slot=\"start\">\n          <ion-back-button defaultHref=\"/home1\" color=\"light\"></ion-back-button>\n        </ion-buttons>\n      </div>\n\n      <div>\n        <ion-button fill=\"clear\" size=\"small\">\n          <ion-icon name=\"search-outline\"></ion-icon>\n        </ion-button>\n\n        <ion-button fill=\"clear\" size=\"small\">\n          <ion-icon name=\"notifications-outline\"></ion-icon>\n        </ion-button>\n      </div>\n    </div>\n    <ion-label class=\"subject\">Select Chapter</ion-label>\n  </div>\n\n  <ion-segment value=\"Chapters\" mode=\"md\" (ionChange)=\"segmentChanged($event)\">\n    <ion-segment-button value=\"Chapters\">\n      <ion-label>Chapters</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"Tests\">\n      <ion-label>Tests</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n    <span *ngIf=\"segId == 'Chapters'\">\n      <div class=\"card_div\" *ngFor=\"let item of chapters\">\n        <img src=\"../../../../assets/download.png\" class=\"download\" />\n\n        <div class=\"round_image bg_image\" [style.backgroundImage]=\"'url( ' + item.img+')'\">\n        </div>\n\n        <div class=\"content_div\">\n          <ion-label class=\"title_lbl\">{{item.name}}</ion-label>\n          <ion-label class=\"small_lbl\">{{item.name}}</ion-label>\n          <ion-progress-bar color=\"warning\" value=\"{{item.per/100}}\"></ion-progress-bar>\n          <ion-label class=\"small_lbl\">Download Notes Of This Chapter</ion-label>\n          <ion-label class=\"abs_lbl\">{{item.per}}</ion-label>\n        </div>\n      </div>\n    </span>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_subject_subject5_subject5_module_ts.js.map