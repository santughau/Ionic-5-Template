(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_home_home4_home4_module_ts"],{

/***/ 79982:
/*!**********************************************************!*\
  !*** ./src/app/pages/home/home4/home4-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home4PageRoutingModule": () => (/* binding */ Home4PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _home4_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home4.page */ 5851);




const routes = [
    {
        path: '',
        component: _home4_page__WEBPACK_IMPORTED_MODULE_0__.Home4Page
    }
];
let Home4PageRoutingModule = class Home4PageRoutingModule {
};
Home4PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Home4PageRoutingModule);



/***/ }),

/***/ 49776:
/*!**************************************************!*\
  !*** ./src/app/pages/home/home4/home4.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home4PageModule": () => (/* binding */ Home4PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _home4_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home4-routing.module */ 79982);
/* harmony import */ var _home4_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home4.page */ 5851);







let Home4PageModule = class Home4PageModule {
};
Home4PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home4_routing_module__WEBPACK_IMPORTED_MODULE_0__.Home4PageRoutingModule
        ],
        declarations: [_home4_page__WEBPACK_IMPORTED_MODULE_1__.Home4Page]
    })
], Home4PageModule);



/***/ }),

/***/ 5851:
/*!************************************************!*\
  !*** ./src/app/pages/home/home4/home4.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home4Page": () => (/* binding */ Home4Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_home4_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./home4.page.html */ 84543);
/* harmony import */ var _home4_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home4.page.scss */ 22457);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 29535);





let Home4Page = class Home4Page {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
        this.subjects = [
            {
                img: 'assets/english.png',
                name: 'English'
            },
            {
                img: 'assets/chemistry.png',
                name: 'Chemistry'
            },
            {
                img: 'assets/statistics.png',
                name: 'Statistics'
            },
            {
                img: 'assets/maths.png',
                name: 'Mathamatics'
            },
            {
                img: 'assets/physics.png',
                name: 'Physics'
            },
            {
                img: 'assets/social.png',
                name: 'Social Science'
            },
        ];
    }
    goToSubject() {
    }
};
Home4Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
Home4Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-home4',
        template: _raw_loader_home4_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_home4_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Home4Page);



/***/ }),

/***/ 22457:
/*!**************************************************!*\
  !*** ./src/app/pages/home/home4/home4.page.scss ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background:linear-gradient( to right, #243949 ,#517fa4);\n}\n\n.main_content_div {\n  width: 100%;\n}\n\n.main_content_div .menu_btn {\n  position: absolute;\n  top: 40px;\n  left: 10px;\n}\n\n.main_content_div ion-label {\n  display: block;\n  color: #243949;\n  text-align: center;\n}\n\n.main_content_div .user_div {\n  padding: 20px;\n  width: 100%;\n  height: 260px;\n  background: linear-gradient(to right, #243949, #517fa4);\n  display: flex;\n  padding-top: 40px;\n  justify-content: space-between;\n}\n\n.main_content_div .user_div .first_div {\n  padding-top: 35px;\n}\n\n.main_content_div .user_div .first_div .welcome {\n  font-size: 18px;\n  color: white;\n  font-weight: 500;\n}\n\n.main_content_div .user_div .first_div .username {\n  font-size: 24px;\n  color: white;\n  font-weight: 600;\n}\n\n.main_content_div .user_div .user_back {\n  height: 100px;\n  width: 80px;\n  border: 3px solid white;\n  background-position: top;\n  background-size: cover;\n  background-repeat: no-repeat;\n  border-radius: 7px;\n}\n\n.main_content_div .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 75px;\n  border-top-left-radius: 75px;\n  margin-top: -90px;\n  padding: 20px;\n  padding-top: 30px;\n}\n\n.main_content_div .content_div .hello_lbl {\n  font-weight: 600;\n  font-size: 18px;\n  margin-bottom: 10px;\n  padding-left: 5px;\n  margin-top: 10px;\n}\n\n.main_content_div .content_div ion-grid {\n  padding: 0px;\n}\n\n.main_content_div .content_div .col_div {\n  background: linear-gradient(to right, #243949, #517fa4);\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 5px;\n}\n\n.main_content_div .content_div .col_div img {\n  width: 70px;\n}\n\n.main_content_div .content_div .col_div ion-label {\n  color: white;\n  margin-top: 5px;\n}\n\n.animated {\n  animation-duration: 10s;\n  animation-fill-mode: both;\n}\n\n.bounceInUp {\n  animation-name: bounceInUp;\n}\n\n@keyframes bounceInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translateY(-30px);\n  }\n  80% {\n    -webkit-transform: translateY(10px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWU0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHlEQUFBO0FBQ0o7O0FBRUE7RUFDSyxXQUFBO0FBQ0w7O0FBQ0k7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FBQ1I7O0FBRUk7RUFDSSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBQVI7O0FBR0k7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSx1REFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLDhCQUFBO0FBRFI7O0FBR1E7RUFDSSxpQkFBQTtBQURaOztBQUdZO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQURoQjs7QUFHWTtFQUNJLGVBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFEaEI7O0FBS1E7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLHVCQUFBO0VBQ0Esd0JBQUE7RUFDQSxzQkFBQTtFQUNBLDRCQUFBO0VBQ0Esa0JBQUE7QUFIWjs7QUFPSTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtBQUxSOztBQU9RO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBTFo7O0FBUVM7RUFDRyxZQUFBO0FBTlo7O0FBU1E7RUFDSyx1REFBQTtFQUNELGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSwwQ0FBQTtFQUNBLGtCQUFBO0FBUFo7O0FBUVk7RUFDSSxXQUFBO0FBTmhCOztBQVNZO0VBQ0ksWUFBQTtFQUNBLGVBQUE7QUFQaEI7O0FBZ0JBO0VBRUksdUJBQUE7RUFFQSx5QkFBQTtBQWJKOztBQW1DQTtFQUVJLDBCQUFBO0FBaEJKOztBQW1CQTtFQUNJO0lBQ0ksVUFBQTtJQUNBLHFDQUFBO0VBaEJOO0VBa0JFO0lBQ0ksVUFBQTtJQUNBLG9DQUFBO0VBaEJOO0VBa0JFO0lBRUksbUNBQUE7RUFqQk47RUFvQkU7SUFFSSxnQ0FBQTtFQW5CTjtBQUNGIiwiZmlsZSI6ImhvbWU0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gICAgLS1iYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCggdG8gcmlnaHQsICMyNDM5NDkgLCM1MTdmYTQpO1xyXG59XHJcblxyXG4ubWFpbl9jb250ZW50X2RpdntcclxuICAgICB3aWR0aDogMTAwJTtcclxuICAgIFxyXG4gICAgLm1lbnVfYnRue1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB0b3A6IDQwcHg7XHJcbiAgICAgICAgbGVmdDogMTBweDtcclxuICAgIH1cclxuXHJcbiAgICBpb24tbGFiZWwge1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgIGNvbG9yOiMyNDM5NDk7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgfVxyXG5cclxuICAgIC51c2VyX2RpdntcclxuICAgICAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGhlaWdodDogMjYwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KCB0byByaWdodCwgIzI0Mzk0OSAsIzUxN2ZhNCk7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBwYWRkaW5nLXRvcDogNDBweDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblxyXG4gICAgICAgIC5maXJzdF9kaXZ7XHJcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiAzNXB4O1xyXG5cclxuICAgICAgICAgICAgLndlbGNvbWV7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC51c2VybmFtZXtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC51c2VyX2JhY2t7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTAwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiA4MHB4O1xyXG4gICAgICAgICAgICBib3JkZXI6IDNweCBzb2xpZCB3aGl0ZTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogdG9wO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA3cHggO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuY29udGVudF9kaXZ7XHJcbiAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDc1cHg7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNzVweDtcclxuICAgICAgICBtYXJnaW4tdG9wOi05MHB4O1xyXG4gICAgICAgIHBhZGRpbmc6MjBweDtcclxuICAgICAgICBwYWRkaW5nLXRvcDozMHB4O1xyXG5cclxuICAgICAgICAuaGVsbG9fbGJse1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogNXB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgIGlvbi1ncmlke1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY29sX2RpdntcclxuICAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCggdG8gcmlnaHQsICMyNDM5NDkgLCM1MTdmYTQpO1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDE1MHB4O1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsMCwwLDAuMik7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgICAgICAgaW1ne1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDcwcHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIFxyXG5cclxuICAgIH1cclxufVxyXG5cclxuLmFuaW1hdGVke1xyXG4gICAgLXdlYmtpdC1hbmltYXRpb24tZHVyYXRpb246MTBzO1xyXG4gICAgYW5pbWF0aW9uLWR1cmF0aW9uIDoxMHM7XHJcbiAgICAtd2Via2l0LWFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XHJcbiAgICBhbmltYXRpb24tZmlsbC1tb2RlOiBib3RoO1xyXG59XHJcblxyXG5ALXdlYmtpdC1rZXlmcmFtZXMgYm91bmNlSW5VcHtcclxuICAgIDAle1xyXG4gICAgICAgIG9wYWNpdHk6MDtcclxuICAgICAgICAtd2Via2l0LXRyYW5zZm9ybSA6dHJhbnNsYXRlWSgyMDAwcHgpO1xyXG4gICAgfVxyXG4gICAgNjAle1xyXG4gICAgICAgIG9wYWNpdHk6MTtcclxuICAgICAgICAtd2Via2l0LXRyYW5zZm9ybSA6dHJhbnNsYXRlWSgtMzBweCk7XHJcbiAgICB9XHJcbiAgICA4MCV7XHJcbiAgICAgICBcclxuICAgICAgICAtd2Via2l0LXRyYW5zZm9ybSA6dHJhbnNsYXRlWSgxMHB4KTtcclxuICAgIH1cclxuXHJcbiAgICAxMDAle1xyXG4gICAgICBcclxuICAgICAgICAtd2Via2l0LXRyYW5zZm9ybSA6dHJhbnNsYXRlWSgwKTtcclxuICAgIH1cclxufVxyXG4uYm91bmNlSW5VcHtcclxuICAgIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IGJvdW5jZUluVXA7XHJcbiAgICBhbmltYXRpb24tbmFtZTogYm91bmNlSW5VcDtcclxufVxyXG5cclxuQGtleWZyYW1lcyBib3VuY2VJblVwe1xyXG4gICAgMCV7XHJcbiAgICAgICAgb3BhY2l0eTowO1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKDIwMDBweCk7XHJcbiAgICB9XHJcbiAgICA2MCV7XHJcbiAgICAgICAgb3BhY2l0eToxO1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKC0zMHB4KTtcclxuICAgIH1cclxuICAgIDgwJXtcclxuICAgICAgIFxyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKDEwcHgpO1xyXG4gICAgfVxyXG5cclxuICAgIDEwMCV7XHJcbiAgICAgIFxyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKDApO1xyXG4gICAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 84543:
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home4/home4.page.html ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"main_content_div\">\n\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n\n    <div class=\"user_div\">\n      <div class=\"first_div\">\n        <ion-label class=\"welcome\">Welcome</ion-label>\n        <ion-label class=\"username\">Yamini</ion-label>\n      </div>\n      <div class=\"user_back\" [style.backgroundImage]=\"'url(assets/11.jpg)'\"></div>\n    </div>\n\n    <div class=\"content_div animated bounceInUp\">\n      <ion-label class=\"hello_lbl\">Hello , Please Choose Your Subject</ion-label>\n\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"6\" (click)=\"goToSubject()\" *ngFor=\"let item of subjects \">\n            <div class=\"col_div\">\n              <img src=\"{{item.img}}\">\n              <ion-label>{{item.name}}</ion-label>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_home4_home4_module_ts.js.map