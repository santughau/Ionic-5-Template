(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_subject_subject2_subject2_module_ts"],{

/***/ 84532:
/*!*******************************************************************!*\
  !*** ./src/app/pages/subject/subject2/subject2-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject2PageRoutingModule": () => (/* binding */ Subject2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _subject2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject2.page */ 24636);




const routes = [
    {
        path: '',
        component: _subject2_page__WEBPACK_IMPORTED_MODULE_0__.Subject2Page
    }
];
let Subject2PageRoutingModule = class Subject2PageRoutingModule {
};
Subject2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Subject2PageRoutingModule);



/***/ }),

/***/ 21751:
/*!***********************************************************!*\
  !*** ./src/app/pages/subject/subject2/subject2.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject2PageModule": () => (/* binding */ Subject2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _subject2_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject2-routing.module */ 84532);
/* harmony import */ var _subject2_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject2.page */ 24636);







let Subject2PageModule = class Subject2PageModule {
};
Subject2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _subject2_routing_module__WEBPACK_IMPORTED_MODULE_0__.Subject2PageRoutingModule
        ],
        declarations: [_subject2_page__WEBPACK_IMPORTED_MODULE_1__.Subject2Page]
    })
], Subject2PageModule);



/***/ }),

/***/ 24636:
/*!*********************************************************!*\
  !*** ./src/app/pages/subject/subject2/subject2.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject2Page": () => (/* binding */ Subject2Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_subject2_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./subject2.page.html */ 72538);
/* harmony import */ var _subject2_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject2.page.scss */ 8661);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let Subject2Page = class Subject2Page {
    constructor() {
        this.segId = 'Chapters';
    }
    ngOnInit() {
        this.chapters = [
            {
                img: 'assets/light.jpg',
                name: 'Theory of Light',
                per: 90
            },
            {
                img: 'assets/water.jpg',
                name: 'Theory of Water',
                per: 40
            },
            {
                img: 'assets/motion.jpg',
                name: 'Theory of Motion',
                per: 50
            },
            {
                img: 'assets/sound.jpg',
                name: 'Theory of Sound',
                per: 65
            },
            {
                img: 'assets/sky.jpg',
                name: 'Theory of Sky',
                per: 75
            },
            {
                img: 'assets/energy.jpg',
                name: 'Theory of Energy',
                per: 45
            },
        ];
    }
    segmentChanged(eve) {
        this.segId = eve.details.value;
    }
};
Subject2Page.ctorParameters = () => [];
Subject2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-subject2',
        template: _raw_loader_subject2_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_subject2_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Subject2Page);



/***/ }),

/***/ 8661:
/*!***********************************************************!*\
  !*** ./src/app/pages/subject/subject2/subject2.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".grad_back {\n  width: 100%;\n  height: 150px;\n  background: linear-gradient(to right, #045de9, #09c6f9);\n  border-bottom-right-radius: 50px;\n  border-top-right-radius: 50px;\n  position: relative;\n}\n.grad_back .subject {\n  color: white;\n  font-weight: 600;\n  font-size: 24px;\n  position: absolute;\n  left: 16px;\n  bottom: 16px;\n}\n.grad_back .btn_flex {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  height: 50px;\n  align-items: center;\n  padding-top: 40px;\n}\n.grad_back ion-icon {\n  font-size: 20px;\n  color: white;\n}\n.main_content_div {\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .card_div {\n  padding: 10px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 10px;\n  margin-bottom: 15px;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  position: relative;\n}\n.main_content_div .card_div .download {\n  width: 18px;\n  position: absolute;\n  right: 10px;\n  top: 10px;\n  z-index: 99999;\n}\n.main_content_div .card_div .round_image {\n  height: 50px;\n  width: 50px;\n  border-radius: 50%;\n  min-width: 50px;\n}\n.main_content_div .card_div .content_div {\n  width: 100%;\n  padding-left: 10px;\n  position: relative;\n}\n.main_content_div .card_div .content_div .title_lbl {\n  font-size: 16px;\n  font-weight: 600;\n  color: #045de9;\n}\n.main_content_div .card_div .content_div .small_lbl {\n  font-size: 12px;\n  color: gray;\n  margin-top: 5px;\n  margin-bottom: 5px;\n}\n.main_content_div .card_div .content_div .abs_lbl {\n  position: absolute;\n  right: 0;\n  bottom: 0;\n  font-size: 12px;\n  color: #045de9;\n}\nion-segment-button {\n  --indicator-color:linear-gradient( to right, #045de9 , #09c6f9) ;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1YmplY3QyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdURBQUE7RUFDQSxnQ0FBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7QUFDSjtBQUNJO0VBQ0ksWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUFDUjtBQUVJO0VBQ0csV0FBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FBQVA7QUFHSTtFQUNHLGVBQUE7RUFDQSxZQUFBO0FBRFA7QUFLQTtFQUNJLGFBQUE7QUFGSjtBQUlJO0VBQ0ksY0FBQTtBQUZSO0FBS0k7RUFDSSxhQUFBO0VBQ0EsMENBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhSO0FBSVE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGNBQUE7QUFGWjtBQUlRO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFGWjtBQUlRO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFGWjtBQUdZO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQURoQjtBQUlZO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFGaEI7QUFJWTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQUZoQjtBQVdBO0VBQ0ksZ0VBQUE7QUFSSiIsImZpbGUiOiJzdWJqZWN0Mi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZ3JhZF9iYWNre1xyXG4gICAgd2lkdGg6MTAwJTtcclxuICAgIGhlaWdodDoxNTBweDtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCggdG8gcmlnaHQsICMwNDVkZTkgLCAjMDljNmY5KTtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1MHB4O1xyXG4gICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDUwcHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgLnN1YmplY3R7XHJcbiAgICAgICAgY29sb3I6d2hpdGU7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgbGVmdDoxNnB4O1xyXG4gICAgICAgIGJvdHRvbToxNnB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5idG5fZmxleHtcclxuICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICBkaXNwbGF5OiBmbGV4OyBcclxuICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgIGhlaWdodDogNTBweDtcclxuICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICBwYWRkaW5nLXRvcDogNDBweDtcclxuICAgIH1cclxuXHJcbiAgICBpb24taWNvbntcclxuICAgICAgIGZvbnQtc2l6ZTogMjBweDsgXHJcbiAgICAgICBjb2xvcjp3aGl0ZTtcclxuICAgIH1cclxufVxyXG5cclxuLm1haW5fY29udGVudF9kaXZ7XHJcbiAgICBwYWRkaW5nOjE2cHg7XHJcblxyXG4gICAgaW9uLWxhYmVse1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgfVxyXG5cclxuICAgIC5jYXJkX2RpdntcclxuICAgICAgICBwYWRkaW5nOjEwcHg7XHJcbiAgICAgICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLDAsMCwwLjIpO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuICAgICAgICAuZG93bmxvYWR7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxOHB4O1xyXG4gICAgICAgICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgICAgICAgICAgcmlnaHQ6IDEwcHg7XHJcbiAgICAgICAgICAgIHRvcDoxMHB4O1xyXG4gICAgICAgICAgICB6LWluZGV4OiA5OTk5OTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnJvdW5kX2ltYWdle1xyXG4gICAgICAgICAgICBoZWlnaHQ6NTBweDtcclxuICAgICAgICAgICAgd2lkdGg6IDUwcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6NTAlO1xyXG4gICAgICAgICAgICBtaW4td2lkdGg6IDUwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5jb250ZW50X2RpdntcclxuICAgICAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OjEwcHg7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICAgICAgLnRpdGxlX2xibHtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojMDQ1ZGU5O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuc21hbGxfbGJse1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6Z3JheTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuYWJzX2xibHtcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICAgICAgICBib3R0b206IDA7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojMDQ1ZGU5XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5cclxuXHJcbmlvbi1zZWdtZW50LWJ1dHRvbntcclxuICAgIC0taW5kaWNhdG9yLWNvbG9yOmxpbmVhci1ncmFkaWVudCggdG8gcmlnaHQsICMwNDVkZTkgLCAjMDljNmY5KVxyXG59Il19 */");

/***/ }),

/***/ 72538:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/subject/subject2/subject2.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <div class=\"grad_back\">\n    <div class=\"btn_flex\">\n      <div>\n        <ion-buttons slot=\"start\">\n          <ion-back-button defaultHref=\"/home1\" color=\"light\"></ion-back-button>\n        </ion-buttons>\n      </div>\n\n      <div>\n        <ion-button fill=\"clear\" size=\"small\">\n          <ion-icon name=\"search-outline\"></ion-icon>\n        </ion-button>\n\n        <ion-button fill=\"clear\" size=\"small\">\n          <ion-icon name=\"notifications-outline\"></ion-icon>\n        </ion-button>\n      </div>\n    </div>\n    <ion-label class=\"subject\">Select Chapter</ion-label>\n  </div>\n\n  <ion-segment value=\"Chapters\" mode=\"md\" (ionChange)=\"segmentChanged($event)\">\n    <ion-segment-button value=\"Chapters\">\n      <ion-label>Chapters</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"Tests\">\n      <ion-label>Tests</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n    <span *ngIf=\"segId == 'Chapters'\">\n      <div class=\"card_div\" *ngFor=\"let item of chapters\">\n        <img src=\"../../../../assets/download.png\" class=\"download\" />\n\n        <div class=\"round_image bg_image\" [style.backgroundImage]=\"'url( ' + item.img+')'\">\n        </div>\n\n        <div class=\"content_div\">\n          <ion-label class=\"title_lbl\">{{item.name}}</ion-label>\n          <ion-label class=\"small_lbl\">{{item.name}}</ion-label>\n          <ion-progress-bar value=\"{{item.per/100}}\"></ion-progress-bar>\n          <ion-label class=\"small_lbl\">Download Notes Of This Chapter</ion-label>\n          <ion-label class=\"abs_lbl\">{{item.per}}</ion-label>\n        </div>\n      </div>\n    </span>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_subject_subject2_subject2_module_ts.js.map