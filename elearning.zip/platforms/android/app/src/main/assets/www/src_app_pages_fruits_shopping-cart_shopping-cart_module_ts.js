(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_fruits_shopping-cart_shopping-cart_module_ts"],{

/***/ 2858:
/*!****************************************************************************!*\
  !*** ./src/app/pages/fruits/shopping-cart/shopping-cart-routing.module.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ShoppingCartPageRoutingModule": () => (/* binding */ ShoppingCartPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _shopping_cart_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./shopping-cart.page */ 50269);




const routes = [
    {
        path: '',
        component: _shopping_cart_page__WEBPACK_IMPORTED_MODULE_0__.ShoppingCartPage
    }
];
let ShoppingCartPageRoutingModule = class ShoppingCartPageRoutingModule {
};
ShoppingCartPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ShoppingCartPageRoutingModule);



/***/ }),

/***/ 48310:
/*!********************************************************************!*\
  !*** ./src/app/pages/fruits/shopping-cart/shopping-cart.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ShoppingCartPageModule": () => (/* binding */ ShoppingCartPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _shopping_cart_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./shopping-cart-routing.module */ 2858);
/* harmony import */ var _shopping_cart_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./shopping-cart.page */ 50269);







let ShoppingCartPageModule = class ShoppingCartPageModule {
};
ShoppingCartPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _shopping_cart_routing_module__WEBPACK_IMPORTED_MODULE_0__.ShoppingCartPageRoutingModule
        ],
        declarations: [_shopping_cart_page__WEBPACK_IMPORTED_MODULE_1__.ShoppingCartPage]
    })
], ShoppingCartPageModule);



/***/ }),

/***/ 50269:
/*!******************************************************************!*\
  !*** ./src/app/pages/fruits/shopping-cart/shopping-cart.page.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ShoppingCartPage": () => (/* binding */ ShoppingCartPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_shopping_cart_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./shopping-cart.page.html */ 2503);
/* harmony import */ var _shopping_cart_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./shopping-cart.page.scss */ 76471);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let ShoppingCartPage = class ShoppingCartPage {
    constructor() { }
    ngOnInit() {
    }
};
ShoppingCartPage.ctorParameters = () => [];
ShoppingCartPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-shopping-cart',
        template: _raw_loader_shopping_cart_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_shopping_cart_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ShoppingCartPage);



/***/ }),

/***/ 76471:
/*!********************************************************************!*\
  !*** ./src/app/pages/fruits/shopping-cart/shopping-cart.page.scss ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".toolbar {\n  height: 84px;\n  --background:#69A03A;\n  color: #fff;\n  font-size: 20px;\n  line-height: 84px;\n}\n.toolbar #userIcon {\n  color: #fff;\n  font-size: 2.5rem;\n  margin-right: 10px;\n}\n.container {\n  width: 100%;\n}\n.container ion-thumbnail {\n  width: 100px !important;\n  height: 100px !important;\n}\n.container ion-thumbnail img {\n  border-radius: 10px;\n}\n.container #rate {\n  color: #ccc;\n}\n.container #qty {\n  margin-top: 5px;\n}\n.container #qty .plus {\n  margin-left: 20px;\n  font-weight: 600;\n  padding: 5px;\n}\n.container #qty .minus {\n  font-weight: 600;\n  padding: 5px;\n  margin-right: 20px;\n}\n.container #qty #btn {\n  padding: 10px 20px;\n  color: #fff;\n  background: #69A03A;\n}\nion-footer .headingClass {\n  margin-left: 20px;\n  color: #69A03A;\n}\nion-footer .btn {\n  background: #69A03A;\n  padding: 10px 20px;\n  margin-top: 40px !important;\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNob3BwaW5nLWNhcnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtFQUNBLG9CQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUNKO0FBQUk7RUFDSSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUVSO0FBRUE7RUFDSSxXQUFBO0FBQ0o7QUFDSTtFQUNJLHVCQUFBO0VBQ0Esd0JBQUE7QUFDUjtBQUFRO0VBQ0ksbUJBQUE7QUFFWjtBQUVJO0VBQ0ksV0FBQTtBQUFSO0FBR0k7RUFDSSxlQUFBO0FBRFI7QUFFUTtFQUNRLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0FBQWhCO0FBSVk7RUFFSSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUhoQjtBQU1ZO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7QUFKaEI7QUFjSTtFQUNJLGlCQUFBO0VBQ0EsY0FBQTtBQVhSO0FBYUk7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxXQUFBO0FBWFIiLCJmaWxlIjoic2hvcHBpbmctY2FydC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudG9vbGJhcntcclxuICAgIGhlaWdodDo4NHB4O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiM2OUEwM0E7XHJcbiAgICBjb2xvcjojZmZmO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6ODRweDtcclxuICAgICN1c2VySWNvbntcclxuICAgICAgICBjb2xvcjojZmZmO1xyXG4gICAgICAgIGZvbnQtc2l6ZToyLjVyZW07XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OjEwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5jb250YWluZXJ7XHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgXHJcbiAgICBpb24tdGh1bWJuYWlse1xyXG4gICAgICAgIHdpZHRoOjEwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgaGVpZ2h0OjEwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgaW1ne1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAjcmF0ZXtcclxuICAgICAgICBjb2xvcjojY2NjO1xyXG4gICAgfVxyXG5cclxuICAgICNxdHl7XHJcbiAgICAgICAgbWFyZ2luLXRvcDo1cHg7XHJcbiAgICAgICAgLnBsdXN7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDoyMHB4O1xyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6NXB4O1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAubWludXN7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOjVweDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDoyMHB4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAjYnRue1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzoxMHB4IDIwcHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojZmZmO1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDojNjlBMDNBXHJcbiAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuXHJcbiAgICBcclxufVxyXG5cclxuaW9uLWZvb3RlcntcclxuICAgIC5oZWFkaW5nQ2xhc3N7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6MjBweDtcclxuICAgICAgICBjb2xvcjojNjlBMDNBO1xyXG4gICAgfVxyXG4gICAgLmJ0bntcclxuICAgICAgICBiYWNrZ3JvdW5kOiM2OUEwM0E7XHJcbiAgICAgICAgcGFkZGluZzoxMHB4IDIwcHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogNDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICB9XHJcbn0iXX0= */");

/***/ }),

/***/ 2503:
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/fruits/shopping-cart/shopping-cart.page.html ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar class=\"toolbar\" >\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-back-button color=\"light\" defaultHref=\"home1\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Shopping Cart</ion-title>\n    <ion-buttons slot=\"end\" class=\"menu_btn\">\n      <ion-icon id=\"userIcon\" name=\"person-circle-outline\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n  <ion-toolbar >\n    <ion-list>\n    \n      <ion-item>\n        <ion-label>Sort By</ion-label>\n        <ion-select value=\"brown\" okText=\"Okay\" cancelText=\"Dismiss\">\n          <ion-select-option value=\"brown\">Fruits</ion-select-option>\n          <ion-select-option value=\"blonde\">Vegetables</ion-select-option>          \n        </ion-select>\n      </ion-item>\n    \n    </ion-list>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content scrollY=\"true\">\n  <div class=\"container\">\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-list style=\"overflow-y: scroll !important; height: 100%;\">\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/brocolli.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Broccoli<span style=\"font-size:20px;float: right; color:red !important\">\n                  <ion-icon name=\"trash-outline\"></ion-icon>\n                  </span></h2>\n                <h3 style=\"color:#69A03A;\"> 160Per/Kg</h3>\n                <p id=\"rate\">Rs 40 Saved</p>\n                <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                  <span style=\"float: right;\">\n                    <button id=\"btn\">Add</button>\n                  </span>\n                </div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/onion.jpeg\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Onion<span style=\"font-size:20px;float: right; color:red !important\">\n                  <ion-icon name=\"trash-outline\"></ion-icon>\n                </span></h2>\n                <h3 style=\"color:#69A03A;\"> 160Per/Kg</h3>\n                <p id=\"rate\">Rs 40 Saved</p>\n                <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                  <span style=\"float: right;\">\n                    <button id=\"btn\">Add</button>\n                  </span>\n                </div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/anjir.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Anjeer<span style=\"font-size:20px;float: right; color:red !important\">\n                  <ion-icon name=\"trash-outline\"></ion-icon>\n                </span></h2>\n                <h3 style=\"color:#69A03A;\"> 160Per/Kg</h3>\n                <p id=\"rate\">Rs 40 Saved</p>\n                <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                  <span style=\"float: right;\">\n                    <button id=\"btn\">Add</button>\n                  </span>\n                </div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/tomato.jpg\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Tomato<span style=\"font-size:20px;float: right; color:red !important\">\n                  <ion-icon name=\"trash-outline\"></ion-icon>\n                </span></h2>\n              <h3 style=\"color:#69A03A;\"> 160Per/Kg</h3>\n              <p id=\"rate\">Rs 40 Saved</p>\n                <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                  <span style=\"float: right;\">\n                    <button id=\"btn\">Add</button>\n                  </span>\n                </div>\n              </ion-label>\n            </ion-item>\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/bringle.png\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Bringle<span style=\"font-size:20px;float: right; color:red !important\">\n                  <ion-icon name=\"trash-outline\"></ion-icon>\n                </span></h2>\n                <h3 style=\"color:#69A03A;\"> 160Per/Kg</h3>\n                <p id=\"rate\">Rs 40 Saved</p>\n                <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                  <span style=\"float: right;\">\n                    <button id=\"btn\">Add</button>\n                  </span>\n                </div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/potato.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Poato<span style=\"font-size:20px;float: right; color:red !important\">\n                  <ion-icon name=\"trash-outline\"></ion-icon>\n                </span></h2>\n              <h3 style=\"color:#69A03A;\"> 160Per/Kg</h3>\n              <p id=\"rate\">Rs 40 Saved</p>\n                <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                  <span style=\"float: right;\">\n                    <button id=\"btn\">Add</button>\n                  </span>\n                </div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/apple.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Apple<span style=\"font-size:20px;float: right; color:red !important\">\n                  <ion-icon name=\"trash-outline\"></ion-icon>\n                </span></h2>\n                <h3 style=\"color:#69A03A;\"> 160Per/Kg</h3>\n                <p id=\"rate\">Rs 40 Saved</p>\n                <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                  <span style=\"float: right;\">\n                    <button id=\"btn\">Add</button>\n                  </span>\n                </div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/orange.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Orange<span style=\"font-size:20px;float: right; color:red !important\">\n                  <ion-icon name=\"trash-outline\"></ion-icon>\n                  </span></h2>\n                <h3 style=\"color:#69A03A;\"> 160Per/Kg</h3>\n                <p id=\"rate\">Rs 40 Saved</p>\n                <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                  <span style=\"float: right;\">\n                    <button id=\"btn\">Add</button>\n                  </span>\n                </div>\n              </ion-label>\n            </ion-item>\n          </ion-list>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n</ion-content>\n<ion-footer class=\"ion-no-border\">\n  <ion-row>\n    <ion-col size=\"7\">\n      <ion-text>\n        <h4 class=\"headingClass\">Total : <span style=\"color:red !important;\">$ 2308</span></h4>\n      </ion-text>\n    </ion-col>\n\n    <ion-col size=\"5\">\n      <buttoon class=\"btn\">Place Order</buttoon>\n    </ion-col>\n  </ion-row>\n</ion-footer>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_fruits_shopping-cart_shopping-cart_module_ts.js.map