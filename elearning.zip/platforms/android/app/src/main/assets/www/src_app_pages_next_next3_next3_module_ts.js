(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_next_next3_next3_module_ts"],{

/***/ 80443:
/*!**********************************************************!*\
  !*** ./src/app/pages/next/next3/next3-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Next3PageRoutingModule": () => (/* binding */ Next3PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _next3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./next3.page */ 87596);




const routes = [
    {
        path: '',
        component: _next3_page__WEBPACK_IMPORTED_MODULE_0__.Next3Page
    }
];
let Next3PageRoutingModule = class Next3PageRoutingModule {
};
Next3PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Next3PageRoutingModule);



/***/ }),

/***/ 33910:
/*!**************************************************!*\
  !*** ./src/app/pages/next/next3/next3.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Next3PageModule": () => (/* binding */ Next3PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _next3_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./next3-routing.module */ 80443);
/* harmony import */ var _next3_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./next3.page */ 87596);







let Next3PageModule = class Next3PageModule {
};
Next3PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _next3_routing_module__WEBPACK_IMPORTED_MODULE_0__.Next3PageRoutingModule
        ],
        declarations: [_next3_page__WEBPACK_IMPORTED_MODULE_1__.Next3Page]
    })
], Next3PageModule);



/***/ }),

/***/ 87596:
/*!************************************************!*\
  !*** ./src/app/pages/next/next3/next3.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Next3Page": () => (/* binding */ Next3Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_next3_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./next3.page.html */ 57176);
/* harmony import */ var _next3_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./next3.page.scss */ 33472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 29535);





let Next3Page = class Next3Page {
    constructor(_router) {
        this._router = _router;
        this.slideOpts = {
            slidesPerView: 1.5
        };
    }
    ngOnInit() {
        this.students = [
            {
                img: 'assets/1.jpg',
                name: 'Miss Priyanka'
            },
            {
                img: 'assets/2.jpg',
                name: 'Miss Yamini'
            },
            {
                img: 'assets/4.jpg',
                name: 'Miss Laxmi'
            },
            {
                img: 'assets/6.jpg',
                name: 'Miss Piyusha'
            },
            {
                img: 'assets/8.jpg',
                name: 'Miss Swara'
            }
        ];
    }
    goBack() {
        this._router.navigate(['/home1']);
    }
};
Next3Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
Next3Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-next3',
        template: _raw_loader_next3_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_next3_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Next3Page);



/***/ }),

/***/ 33472:
/*!**************************************************!*\
  !*** ./src/app/pages/next/next3/next3.page.scss ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".main_content_div {\n  width: 100%;\n}\n.main_content_div .back_div {\n  width: 100%;\n  height: 350px;\n  background: linear-gradient(to right, #667eea, #764ba2);\n  border-bottom-right-radius: 50%;\n  border-bottom-left-radius: 50%;\n  position: relative;\n}\n.main_content_div .back_div .back_btn {\n  font-size: 30px;\n  left: 16px;\n  top: 40px;\n  position: absolute;\n}\n.main_content_div .back_div .white_div {\n  height: 130px;\n  width: 130px;\n  background: white;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .back_div img {\n  width: 70px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .bottom_div {\n  padding: 20px;\n  padding-top: 100px;\n}\n.main_content_div .bottom_div .slide_div {\n  display: flex;\n  align-items: center;\n  text-align: left;\n}\n.main_content_div .bottom_div .slide_div .user_back {\n  height: 70px;\n  width: 70px;\n  min-width: 70px;\n  border-radius: 100%;\n  background-position: top;\n  z-index: 999;\n}\n.main_content_div .bottom_div .slide_div .bg_image {\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n.main_content_div .bottom_div .slide_div .content_div {\n  margin-left: -20px;\n  padding-left: 25px;\n  padding-right: 25px;\n  height: 50px;\n  background: #667eea;\n  color: white;\n  border-top-right-radius: 25px;\n  border-bottom-right-radius: 25px;\n  z-index: 0;\n  display: flex;\n  align-items: center;\n}\n.main_content_div .bottom_div .slide_div .content_div ion-label {\n  display: block;\n  font-size: 14px;\n}\n.main_content_div .bottom_div .btn_div {\n  margin-top: 50px;\n  text-align: center;\n}\n.main_content_div .bottom_div .btn_div ion-button {\n  color: #667eea;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5leHQzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJQTtFQUNJLFdBQUE7QUFISjtBQUlJO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSx1REFBQTtFQUNBLCtCQUFBO0VBQ0EsOEJBQUE7RUFDQSxrQkFBQTtBQUZSO0FBSVE7RUFDSSxlQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtBQUZaO0FBS1E7RUFDSSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsUUFBQTtFQUNBLGdDQUFBO0FBSFo7QUFNUTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7QUFKWjtBQVFJO0VBQ0ksYUFBQTtFQUNBLGtCQUFBO0FBTlI7QUFPUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBTFo7QUFPWTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0Esd0JBQUE7RUFDQSxZQUFBO0FBTGhCO0FBUVk7RUFDSSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7QUFOaEI7QUFTWTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSw2QkFBQTtFQUNBLGdDQUFBO0VBQ0EsVUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQVBoQjtBQVFnQjtFQUNJLGNBQUE7RUFDQSxlQUFBO0FBTnBCO0FBV1E7RUFDSSxnQkFBQTtFQUNBLGtCQUFBO0FBVFo7QUFVWTtFQUNJLGNBQUE7QUFSaEIiLCJmaWxlIjoibmV4dDMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcblxyXG59XHJcblxyXG4ubWFpbl9jb250ZW50X2RpdntcclxuICAgIHdpZHRoOjEwMCU7XHJcbiAgICAuYmFja19kaXZ7XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICBoZWlnaHQ6IDM1MHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzY2N2VlYSAsIzc2NGJhMik7XHJcbiAgICAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDUwJTtcclxuICAgICAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5cclxuICAgICAgICAuYmFja19idG57XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgICAgICAgICAgbGVmdDoxNnB4O1xyXG4gICAgICAgICAgICB0b3A6NDBweDtcclxuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLndoaXRlX2RpdntcclxuICAgICAgICAgICAgaGVpZ2h0OjEzMHB4O1xyXG4gICAgICAgICAgICB3aWR0aDoxMzBweDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgICAgICAgICBsZWZ0OjUwJTtcclxuICAgICAgICAgICAgdG9wOjUwJTtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGltZ3tcclxuICAgICAgICAgICAgd2lkdGg6IDcwcHg7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgICAgICAgICB0b3A6IDUwJTtcclxuICAgICAgICAgICAgbGVmdDogNTAlO1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuYm90dG9tX2RpdntcclxuICAgICAgICBwYWRkaW5nOjIwcHg7XHJcbiAgICAgICAgcGFkZGluZy10b3A6MTAwcHg7XHJcbiAgICAgICAgLnNsaWRlX2RpdntcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuXHJcbiAgICAgICAgICAgIC51c2VyX2JhY2t7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6NzBweDtcclxuICAgICAgICAgICAgICAgIHdpZHRoOjcwcHg7XHJcbiAgICAgICAgICAgICAgICBtaW4td2lkdGg6IDcwcHg7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogdG9wO1xyXG4gICAgICAgICAgICAgICAgei1pbmRleDogOTk5O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuYmdfaW1hZ2V7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLmNvbnRlbnRfZGl2e1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6LTIwcHg7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6MjVweDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDI1cHg7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6NTBweDtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IzY2N2VlYTtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAyNXB4O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDI1cHg7XHJcbiAgICAgICAgICAgICAgICB6LWluZGV4OiAwO1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTpmbGV4O1xyXG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgIGlvbi1sYWJlbHtcclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6MTRweDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmJ0bl9kaXZ7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6NTBweDtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IzY2N2VlYTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcbn0iXX0= */");

/***/ }),

/***/ 57176:
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/next/next3/next3.page.html ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"main_content_div\">\n    <div class=\"back_div\">\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"light\" class=\"back_btn\"></ion-icon>\n\n      <div class=\"white_div\">\n        <img src=\"../../../../assets/statistics.png\" />\n      </div>\n    </div>\n\n    <div class=\"bottom_div\">\n      <ion-slides [options]=\"slideOpts\">\n        <ion-slide *ngFor=\"let item of students\">\n          <div class=\"slide_div\">\n            <div class=\"user_back bg_image\" [style.backgroundImage]=\"'url( '+item.img+' )'\"></div>\n            <div class=\"content_div\">\n              <ion-label>{{item.name}}</ion-label>\n            </div>\n          </div>\n        </ion-slide>\n      </ion-slides>\n\n      <div class=\"btn_div\">\n        <ion-button (click)=\"goToSubjectDetails()\" fill=\"outline\" shape=\"round\">\n          Next\n        </ion-button>\n      </div>\n    </div>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_next_next3_next3_module_ts.js.map