(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_payment_payment6_payment6_module_ts"],{

/***/ 25806:
/*!*******************************************************************!*\
  !*** ./src/app/pages/payment/payment6/payment6-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Payment6PageRoutingModule": () => (/* binding */ Payment6PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _payment6_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment6.page */ 50906);




const routes = [
    {
        path: '',
        component: _payment6_page__WEBPACK_IMPORTED_MODULE_0__.Payment6Page
    }
];
let Payment6PageRoutingModule = class Payment6PageRoutingModule {
};
Payment6PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Payment6PageRoutingModule);



/***/ }),

/***/ 18527:
/*!***********************************************************!*\
  !*** ./src/app/pages/payment/payment6/payment6.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Payment6PageModule": () => (/* binding */ Payment6PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _payment6_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment6-routing.module */ 25806);
/* harmony import */ var _payment6_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment6.page */ 50906);







let Payment6PageModule = class Payment6PageModule {
};
Payment6PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _payment6_routing_module__WEBPACK_IMPORTED_MODULE_0__.Payment6PageRoutingModule
        ],
        declarations: [_payment6_page__WEBPACK_IMPORTED_MODULE_1__.Payment6Page]
    })
], Payment6PageModule);



/***/ }),

/***/ 50906:
/*!*********************************************************!*\
  !*** ./src/app/pages/payment/payment6/payment6.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Payment6Page": () => (/* binding */ Payment6Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_payment6_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./payment6.page.html */ 37868);
/* harmony import */ var _payment6_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment6.page.scss */ 68547);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let Payment6Page = class Payment6Page {
    constructor() { }
    ngOnInit() {
    }
    changeMethod(val) {
        this.id = val;
    }
};
Payment6Page.ctorParameters = () => [];
Payment6Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-payment6',
        template: _raw_loader_payment6_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_payment6_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Payment6Page);



/***/ }),

/***/ 68547:
/*!***********************************************************!*\
  !*** ./src/app/pages/payment/payment6/payment6.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-toolbar {\n  --background: linear-gradient(to right, #2F0743, #41295a );\n}\n\n.main_content_div {\n  width: 100%;\n  padding: 20px;\n}\n\n.main_content_div ion-label {\n  display: block;\n  margin-top: 20px;\n  color: gray;\n}\n\n.main_content_div .square_div {\n  background: whitesmoke;\n  width: 100%;\n  height: 100px;\n  position: relative;\n}\n\n.main_content_div .yellow {\n  background: linear-gradient(to right, #2F0743, #41295a);\n}\n\n.main_content_div .gray_img {\n  width: 50px;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n}\n\n.main_content_div ion-input, .main_content_div ion-datetime {\n  border: 1px solid lightgray;\n  border-radius: 5px;\n  --padding-start:8px;\n  margin-top: 15px;\n}\n\n.main_content_div .left_col {\n  padding-left: 0px;\n}\n\n.main_content_div .right_col {\n  padding-right: 0px;\n}\n\n.main_content_div ion-button {\n  --background:linear-gradient( to right, #2F0743, #41295a);\n  --border-radius:5px;\n  color: white;\n  margin-top: 30px;\n}\n\nion-footer ion-row {\n  background: linear-gradient(to right, #2F0743, #41295a);\n  color: white;\n}\n\nion-footer ion-row ion-col:last-child {\n  text-align: end;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBheW1lbnQ2LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDBEQUFBO0FBQ0o7O0FBRUE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtBQUNKOztBQUNJO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtBQUNSOztBQUVJO0VBQ0ksc0JBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0FBQVI7O0FBR0k7RUFDSSx1REFBQTtBQURSOztBQUlJO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7RUFDQSxnQ0FBQTtBQUZSOztBQUtJO0VBQ0ksMkJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFIUjs7QUFNSTtFQUNJLGlCQUFBO0FBSlI7O0FBT0k7RUFDSSxrQkFBQTtBQUxSOztBQVFJO0VBQ0kseURBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQU5SOztBQVdJO0VBQ0ksdURBQUE7RUFDQSxZQUFBO0FBUlI7O0FBVVk7RUFDSSxlQUFBO0FBUmhCIiwiZmlsZSI6InBheW1lbnQ2LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFye1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMyRjA3NDMsICM0MTI5NWEgKTtcclxufVxyXG5cclxuLm1haW5fY29udGVudF9kaXZ7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmc6MjBweDtcclxuXHJcbiAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgbWFyZ2luLXRvcDoyMHB4O1xyXG4gICAgICAgIGNvbG9yOmdyYXk7XHJcbiAgICB9XHJcblxyXG4gICAgLnNxdWFyZV9kaXZ7XHJcbiAgICAgICAgYmFja2dyb3VuZDp3aGl0ZXNtb2tlO1xyXG4gICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgaGVpZ2h0OjEwMHB4O1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIH1cclxuXHJcbiAgICAueWVsbG93e1xyXG4gICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzJGMDc0MywgIzQxMjk1YSApXHJcbiAgICB9XHJcblxyXG4gICAgLmdyYXlfaW1ne1xyXG4gICAgICAgIHdpZHRoOjUwcHg7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIGxlZnQ6NTAlO1xyXG4gICAgICAgIHRvcDo1MCU7XHJcbiAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcclxuICAgIH1cclxuXHJcbiAgICBpb24taW5wdXQsaW9uLWRhdGV0aW1le1xyXG4gICAgICAgIGJvcmRlcjoxcHggc29saWQgIGxpZ2h0Z3JheTtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OjhweDtcclxuICAgICAgICBtYXJnaW4tdG9wOjE1cHg7XHJcbiAgICB9XHJcblxyXG4gICAgLmxlZnRfY29se1xyXG4gICAgICAgIHBhZGRpbmctbGVmdDowcHg7XHJcbiAgICB9XHJcblxyXG4gICAgLnJpZ2h0X2NvbHtcclxuICAgICAgICBwYWRkaW5nLXJpZ2h0OjBweDtcclxuICAgIH1cclxuXHJcbiAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoIHRvIHJpZ2h0LCAjMkYwNzQzLCAjNDEyOTVhKTtcclxuICAgICAgICAtLWJvcmRlci1yYWRpdXM6NXB4O1xyXG4gICAgICAgIGNvbG9yOndoaXRlO1xyXG4gICAgICAgIG1hcmdpbi10b3A6MzBweDtcclxuICAgIH1cclxufVxyXG5cclxuaW9uLWZvb3RlcntcclxuICAgIGlvbi1yb3d7XHJcbiAgICAgICAgYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMyRjA3NDMsICM0MTI5NWEpO1xyXG4gICAgICAgIGNvbG9yOndoaXRlO1xyXG4gICAgICAgIGlvbi1jb2x7XHJcbiAgICAgICAgICAgICY6bGFzdC1jaGlsZHtcclxuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGVuZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */");

/***/ }),

/***/ 37868:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/payment/payment6/payment6.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot='start'>\n      <ion-back-button color=\"light\" defaultHref=\"/home1\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Payment</ion-title>\n  </ion-toolbar>\n  <ion-toolbar>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n    <ion-label>1. Select Your Payment Method</ion-label>\n    <ion-row style=\"margin-top:20px;\">\n      <ion-col size=\"4\">\n        <div class=\"square_div\" (click)=\"changeMethod(1)\" [class.yellow]=\"id ==1\">\n          <img class=\"gray_img\" *ngIf=\"id !=1\" src=\"../../../../assets/card2.png\" />\n          <img class=\"gray_img\" *ngIf=\"id ==1\" src=\"../../../../assets/card1.png\" />\n        </div>\n\n      </ion-col>\n\n\n      <ion-col size=\"4\">\n        <div class=\"square_div\" (click)=\"changeMethod(2)\" [class.yellow]=\"id ==2\">\n          <img class=\"gray_img\" *ngIf=\"id !=2\" src=\"../../../../assets/money2.png\" />\n          <img class=\"gray_img\" *ngIf=\"id ==2\" src=\"../../../../assets/money1.png\" />\n        </div>\n\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <div class=\"square_div\" (click)=\"changeMethod(3)\" [class.yellow]=\"id ==3\">\n          <img class=\"gray_img\" *ngIf=\"id !=3\" src=\"../../../../assets/paypal1.png\" />\n          <img class=\"gray_img\" *ngIf=\"id ==3\" src=\"../../../../assets/paypal2.png\" />\n        </div>\n\n      </ion-col>\n    </ion-row>\n\n    <ion-label>2. Enter Your Card Details</ion-label>\n    <ion-label>Card Number</ion-label>\n\n    <ion-input type=\"text\" placeholder=\"XXXX-XXXX-XXXX-1212\"></ion-input>\n\n    <ion-row>\n      <ion-col size=\"4\" class=\"left_col\">\n        <ion-datetime display-format=\"MM\" placeholder=\"MM\"></ion-datetime>\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <ion-datetime display-format=\"YYYY\" placeholder=\"YYYY\"></ion-datetime>\n      </ion-col>\n\n      <ion-col size=\"4\" class=\"right_col\">\n        <ion-input type=\"text\" placeholder=\"CVV\"></ion-input>\n      </ion-col>\n    </ion-row>\n\n    <ion-button expand=\"block\" fill=\"clear\" shape=\"round\">Confirm</ion-button>\n  </div>\n</ion-content>\n\n<ion-footer>\n  <ion-row>\n    <ion-col size=\"7\">\n      <ion-text>\n        <h4>Total : $100.10</h4>\n      </ion-text>\n    </ion-col>\n\n    <ion-col size=\"5\">\n      <ion-button color=\"light\">Go Back</ion-button>\n    </ion-col>\n  </ion-row>\n</ion-footer>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_payment_payment6_payment6_module_ts.js.map