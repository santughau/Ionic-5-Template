(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["main"],{

/***/ 98255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 98255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 70809:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 29535);



const routes = [
    {
        path: '',
        redirectTo: 'home1',
        pathMatch: 'full'
    },
    {
        path: 'folder/:id',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_folder_folder_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./folder/folder.module */ 35098)).then(m => m.FolderPageModule)
    },
    {
        path: 'home1',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_home1_home1_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home/home1/home1.module */ 20039)).then(m => m.Home1PageModule)
    },
    {
        path: 'home2',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_home2_home2_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home/home2/home2.module */ 56519)).then(m => m.Home2PageModule)
    },
    {
        path: 'home3',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_home3_home3_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home/home3/home3.module */ 92357)).then(m => m.Home3PageModule)
    },
    {
        path: 'home4',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_home4_home4_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home/home4/home4.module */ 49776)).then(m => m.Home4PageModule)
    },
    {
        path: 'home5',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_home5_home5_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home/home5/home5.module */ 9688)).then(m => m.Home5PageModule)
    },
    {
        path: 'home6',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_home6_home6_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home/home6/home6.module */ 6390)).then(m => m.Home6PageModule)
    },
    {
        path: 'next1',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_next_next1_next1_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/next/next1/next1.module */ 97311)).then(m => m.Next1PageModule)
    },
    {
        path: 'next3',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_next_next3_next3_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/next/next3/next3.module */ 33910)).then(m => m.Next3PageModule)
    },
    {
        path: 'next2',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_next_next2_next2_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/next/next2/next2.module */ 23524)).then(m => m.Next2PageModule)
    },
    {
        path: 'next4',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_next_next4_next4_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/next/next4/next4.module */ 72798)).then(m => m.Next4PageModule)
    },
    {
        path: 'next5',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_next_next5_next5_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/next/next5/next5.module */ 44465)).then(m => m.Next5PageModule)
    },
    {
        path: 'next6',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_next_next6_next6_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/next/next6/next6.module */ 10823)).then(m => m.Next6PageModule)
    },
    {
        path: 'subject1',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_subject_subject1_subject1_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/subject/subject1/subject1.module */ 36285)).then(m => m.Subject1PageModule)
    },
    {
        path: 'subject2',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_subject_subject2_subject2_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/subject/subject2/subject2.module */ 21751)).then(m => m.Subject2PageModule)
    },
    {
        path: 'subject3',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_subject_subject3_subject3_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/subject/subject3/subject3.module */ 51440)).then(m => m.Subject3PageModule)
    },
    {
        path: 'subject4',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_subject_subject4_subject4_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/subject/subject4/subject4.module */ 22555)).then(m => m.Subject4PageModule)
    },
    {
        path: 'subject5',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_subject_subject5_subject5_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/subject/subject5/subject5.module */ 96976)).then(m => m.Subject5PageModule)
    },
    {
        path: 'subject6',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_subject_subject6_subject6_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/subject/subject6/subject6.module */ 34186)).then(m => m.Subject6PageModule)
    },
    {
        path: 'list1',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_list_list1_list1_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/list/list1/list1.module */ 73508)).then(m => m.List1PageModule)
    },
    {
        path: 'list2',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_list_list2_list2_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/list/list2/list2.module */ 80785)).then(m => m.List2PageModule)
    },
    {
        path: 'list3',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_list_list3_list3_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/list/list3/list3.module */ 87593)).then(m => m.List3PageModule)
    },
    {
        path: 'list4',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_list_list4_list4_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/list/list4/list4.module */ 2530)).then(m => m.List4PageModule)
    },
    {
        path: 'list5',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_list_list5_list5_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/list/list5/list5.module */ 45233)).then(m => m.List5PageModule)
    },
    {
        path: 'list6',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_list_list6_list6_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/list/list6/list6.module */ 79577)).then(m => m.List6PageModule)
    },
    {
        path: 'payment1',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_payment_payment1_payment1_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/payment/payment1/payment1.module */ 81686)).then(m => m.Payment1PageModule)
    },
    {
        path: 'payment2',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_payment_payment2_payment2_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/payment/payment2/payment2.module */ 90579)).then(m => m.Payment2PageModule)
    },
    {
        path: 'payment3',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_payment_payment3_payment3_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/payment/payment3/payment3.module */ 78160)).then(m => m.Payment3PageModule)
    },
    {
        path: 'payment4',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_payment_payment4_payment4_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/payment/payment4/payment4.module */ 85364)).then(m => m.Payment4PageModule)
    },
    {
        path: 'payment5',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_payment_payment5_payment5_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/payment/payment5/payment5.module */ 5961)).then(m => m.Payment5PageModule)
    },
    {
        path: 'payment6',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_payment_payment6_payment6_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/payment/payment6/payment6.module */ 18527)).then(m => m.Payment6PageModule)
    },
    {
        path: 'profile1',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_profile1_profile1_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/profile/profile1/profile1.module */ 20540)).then(m => m.Profile1PageModule)
    },
    {
        path: 'profile2',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_profile2_profile2_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/profile/profile2/profile2.module */ 23121)).then(m => m.Profile2PageModule)
    },
    {
        path: 'profile3',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_profile3_profile3_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/profile/profile3/profile3.module */ 15719)).then(m => m.Profile3PageModule)
    },
    {
        path: 'profile4',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_profile4_profile4_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/profile/profile4/profile4.module */ 30105)).then(m => m.Profile4PageModule)
    },
    {
        path: 'profile6',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_profile6_profile6_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/profile/profile6/profile6.module */ 87146)).then(m => m.Profile6PageModule)
    },
    {
        path: 'profile5',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_profile5_profile5_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/profile/profile5/profile5.module */ 15324)).then(m => m.Profile5PageModule)
    },
    {
        path: 'demo',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_demo_demo_demo_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/demo/demo/demo.module */ 39340)).then(m => m.DemoPageModule)
    },
    {
        path: 'demo2',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_demo_demo2_demo2_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/demo/demo2/demo2.module */ 61503)).then(m => m.Demo2PageModule)
    },
    {
        path: 'demo3',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_demo3_demo3_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/demo3/demo3.module */ 21002)).then(m => m.Demo3PageModule)
    },
    {
        path: 'detail',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_fruits_detail_detail_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/fruits/detail/detail.module */ 54148)).then(m => m.DetailPageModule)
    },
    {
        path: 'my-orders',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_fruits_my-orders_my-orders_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/fruits/my-orders/my-orders.module */ 9505)).then(m => m.MyOrdersPageModule)
    },
    {
        path: 'favourites',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_fruits_favourites_favourites_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/fruits/favourites/favourites.module */ 25986)).then(m => m.FavouritesPageModule)
    },
    {
        path: 'shopping-cart',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_fruits_shopping-cart_shopping-cart_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/fruits/shopping-cart/shopping-cart.module */ 48310)).then(m => m.ShoppingCartPageModule)
    },
    {
        path: 'payment-card',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_fruits_payment-card_payment-card_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/fruits/payment-card/payment-card.module */ 54433)).then(m => m.PaymentCardPageModule)
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 20721:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./app.component.html */ 91106);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 43069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let AppComponent = class AppComponent {
    constructor() {
        this.appPages = [
            { title: 'Fruit App Details Page', url: '/detail', icon: 'heart' },
            { title: 'Fruit App Product List Page 1', url: '/my-orders', icon: 'heart' },
            { title: 'Fruit App Product List Page 2', url: '/favourites', icon: 'heart' },
            { title: 'Fruit App Add Product Page ', url: '/shopping-cart', icon: 'heart' },
            { title: 'Fruit App Add Card Page ', url: '/payment-card', icon: 'heart' },
            { title: 'Home 1', url: '/home1', icon: 'heart' },
            { title: 'Home 2', url: '/home2', icon: 'heart' },
            { title: 'Home 3', url: '/home3', icon: 'heart' },
            { title: 'Home 4', url: '/home4', icon: 'heart' },
            { title: 'Home 5', url: '/home5', icon: 'heart' },
            { title: 'Home 6', url: '/home6', icon: 'heart' },
            { title: 'Next page 1', url: '/next1', icon: 'heart' },
            { title: 'Next page 2', url: '/next2', icon: 'heart' },
            { title: 'Next page 3', url: '/next3', icon: 'heart' },
            { title: 'Next page 4', url: '/next4', icon: 'heart' },
            { title: 'Next page 5', url: '/next5', icon: 'heart' },
            { title: 'Next page 6', url: '/next6', icon: 'heart' },
            { title: 'Subject 1', url: '/subject1', icon: 'heart' },
            { title: 'Subject 2', url: '/subject2', icon: 'heart' },
            { title: 'Subject 3', url: '/subject3', icon: 'heart' },
            { title: 'Subject 4', url: '/subject4', icon: 'heart' },
            { title: 'Subject 5', url: '/subject5', icon: 'heart' },
            { title: 'Subject 6', url: '/subject6', icon: 'heart' },
            { title: 'List 1', url: '/list1', icon: 'heart' },
            { title: 'List 2', url: '/list2', icon: 'heart' },
            { title: 'List 3', url: '/list3', icon: 'heart' },
            { title: 'List 4', url: '/list4', icon: 'heart' },
            { title: 'List 5', url: '/list5', icon: 'heart' },
            { title: 'List 6', url: '/list6', icon: 'heart' },
            { title: 'Payement 1', url: '/payment1', icon: 'heart' },
            { title: 'Payement 2', url: '/payment2', icon: 'heart' },
            { title: 'Payement 3', url: '/payment3', icon: 'heart' },
            { title: 'Payement 4', url: '/payment4', icon: 'heart' },
            { title: 'Payement 5', url: '/payment5', icon: 'heart' },
            { title: 'Payement 6', url: '/payment6', icon: 'heart' },
            { title: 'Profile 1', url: '/profile1', icon: 'heart' },
            { title: 'Profile 2', url: '/profile2', icon: 'heart' },
            { title: 'Profile 3', url: '/profile3', icon: 'heart' },
            { title: 'Profile 4', url: '/profile4', icon: 'heart' },
            { title: 'Profile 5', url: '/profile5', icon: 'heart' },
            { title: 'Profile 6', url: '/profile6', icon: 'heart' },
            { title: 'Profile 7', url: '/demo3', icon: 'heart' },
        ];
    }
};
AppComponent.ctorParameters = () => [];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AppComponent);



/***/ }),

/***/ 50023:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ 93220);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 20721);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 70809);
/* harmony import */ var ngx_mask__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-mask */ 61688);








const maskConfig = {
    validation: false,
};
let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule, ngx_mask__WEBPACK_IMPORTED_MODULE_6__.NgxMaskModule.forRoot(maskConfig),],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicRouteStrategy }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 24766:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 8835:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 90476);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 50023);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 24766);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-action-sheet.entry.js": [
		95261,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		26,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		29009,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		27221,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		34694,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		41268,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-button_2.entry.js": [
		63645,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		62245,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		23482,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		4081,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		53315,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		64133,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		37542,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		21459,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		47618,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		90101,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		82210,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		47370,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		23652,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		28220,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		25500,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		84913,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-popover.entry.js": [
		15078,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		14857,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		48958,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		14383,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		97630,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		81297,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		35492,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		13752,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		7487,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		61778,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		82904,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		81609,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		31218,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		92849,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		4127,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		28400,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		14397,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		43391,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		66793,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		11695,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		4180,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 43069:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n\n.user_main_div {\n  padding-top: 50px;\n}\n\n.user_main_div .user_div {\n  height: 110px;\n  width: 100px;\n  border-radius: 5px;\n  border: 3px solid white;\n  display: block;\n  margin: auto;\n  background-position: top;\n}\n\n.user_main_div .username {\n  display: block;\n  margin-top: 20px;\n  font-weight: 600;\n  font-size: 18px;\n  text-align: center;\n  color: white;\n}\n\n.bg_image {\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n\n#inbox-list {\n  background: transparent;\n}\n\n#inbox-list ion-item {\n  --background:transparent;\n}\n\n#inbox-list ion-item ion-icon {\n  color: white;\n}\n\n#inbox-list ion-item ion-label {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDJFQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7QUFDRjs7QUFFQTs7RUFFRSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsMkRBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUVBLGdCQUFBO0FBQUY7O0FBR0E7RUFDRSxlQUFBO0VBRUEsbUJBQUE7RUFFQSxjQUFBO0VBRUEsZ0JBQUE7QUFIRjs7QUFNQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhGOztBQU1BO0VBQ0Usc0RBQUE7QUFIRjs7QUFNQTtFQUNFLCtCQUFBO0FBSEY7O0FBTUE7RUFDRSxjQUFBO0FBSEY7O0FBTUE7RUFDRSxnQkFBQTtBQUhGOztBQU1BO0VBQ0Usc0JBQUE7QUFIRjs7QUFNQTtFQUNFLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxpQkFBQTtFQUNBLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFIRjs7QUFNQTtFQUNFLCtCQUFBO0FBSEY7O0FBTUE7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQUhGOztBQU1BO0VBQ0Usa0JBQUE7QUFIRjs7QUFNQTs7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxrQkFBQTtBQUhGOztBQU1BO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBRUEsb0NBQUE7QUFKRjs7QUFPQTtFQUNFLGlDQUFBO0FBSkY7O0FBT0E7RUFDRSxpQkFBQTtBQUpGOztBQU1FO0VBQ0UsYUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSx3QkFBQTtBQUpKOztBQU9FO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBTEo7O0FBVUE7RUFDRSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7QUFQRjs7QUFVQTtFQUNFLHVCQUFBO0FBUEY7O0FBU0U7RUFDRSx3QkFBQTtBQVBKOztBQVNJO0VBQ0UsWUFBQTtBQVBOOztBQVVJO0VBQ0UsWUFBQTtBQVJOIiwiZmlsZSI6ImFwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1tZW51IGlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24taXRlbS1iYWNrZ3JvdW5kLCB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvciwgI2ZmZikpO1xufVxuXG5pb24tbWVudS5tZCBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1zdGFydDogOHB4O1xuICAtLXBhZGRpbmctZW5kOiA4cHg7XG4gIC0tcGFkZGluZy10b3A6IDIwcHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0IHtcbiAgcGFkZGluZzogMjBweCAwO1xufVxuXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zdGVwLTE1MCwgI2Q3ZDhkYSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBmb250LXdlaWdodDogNjAwO1xuXG4gIG1pbi1oZWlnaHQ6IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIGZvbnQtc2l6ZTogMTZweDtcblxuICBtYXJnaW4tYm90dG9tOiAxOHB4O1xuXG4gIGNvbG9yOiAjNzU3NTc1O1xuXG4gIG1pbi1oZWlnaHQ6IDI2cHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAtLXBhZGRpbmctZW5kOiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXJnYiksIDAuMTQpO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgY29sb3I6ICM2MTZlN2U7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCB7XG4gIHBhZGRpbmc6IDIwcHggMCAwIDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDE2cHg7XG4gIC0tbWluLWhlaWdodDogNTBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNHB4O1xuICBjb2xvcjogIzczODQ5YTtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIHBhZGRpbmctbGVmdDogMTZweDtcbiAgcGFkZGluZy1yaWdodDogMTZweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuXG5pb24tbm90ZSB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZm9udC1zaXplOiAxNnB4O1xuXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXNoYWRlKTtcbn1cblxuaW9uLWl0ZW0uc2VsZWN0ZWQge1xuICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbi51c2VyX21haW5fZGl2e1xuICBwYWRkaW5nLXRvcDo1MHB4O1xuXG4gIC51c2VyX2RpdntcbiAgICBoZWlnaHQ6MTEwcHg7XG4gICAgd2lkdGg6MTAwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIGJvcmRlcjozcHggc29saWQgd2hpdGU7XG4gICAgZGlzcGxheTpibG9jaztcbiAgICBtYXJnaW46YXV0bztcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiB0b3A7XG4gIH1cblxuICAudXNlcm5hbWV7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgbWFyZ2luLXRvcDoyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjp3aGl0ZTtcbiAgfVxufVxuXG5cbi5iZ19pbWFnZXtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG4jaW5ib3gtbGlzdHtcbiAgYmFja2dyb3VuZDp0cmFuc3BhcmVudDtcblxuICBpb24taXRlbXtcbiAgICAtLWJhY2tncm91bmQ6dHJhbnNwYXJlbnQ7XG5cbiAgICBpb24taWNvbntcbiAgICAgIGNvbG9yOndoaXRlOyAgICAgIFxuICAgIH1cblxuICAgIGlvbi1sYWJlbHtcbiAgICAgIGNvbG9yOndoaXRlOyBcbiAgICB9XG4gIH1cbn0iXX0= */");

/***/ }),

/***/ 91106:
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\n  <ion-split-pane contentId=\"main-content\">\n    <ion-menu contentId=\"main-content\" type=\"overlay\">\n      <ion-content style=\"--background:linear-gradient(to right, #b91d73, #f953c6)\">\n        <div class=\"user_main_div\">\n          <div class=\"user_div bg_image\" [style.backgroundImage]=\"'url(assets/11.jpg)'\"></div>\n          <ion-label class=\"username\">Yamini</ion-label>\n        </div>\n\n        <ion-list id=\"inbox-list\">\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\">\n            <ion-item routerDirection=\"root\" [routerLink]=\"[p.url]\" lines=\"none\" detail=\"false\"\n              routerLinkActive=\"selected\">\n              <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon>\n              <ion-label>{{ p.title }}</ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n\n\n      </ion-content>\n    </ion-menu>\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(8835)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map