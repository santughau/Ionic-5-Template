(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_fruits_favourites_favourites_module_ts"],{

/***/ 5530:
/*!**********************************************************************!*\
  !*** ./src/app/pages/fruits/favourites/favourites-routing.module.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FavouritesPageRoutingModule": () => (/* binding */ FavouritesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _favourites_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./favourites.page */ 37703);




const routes = [
    {
        path: '',
        component: _favourites_page__WEBPACK_IMPORTED_MODULE_0__.FavouritesPage
    }
];
let FavouritesPageRoutingModule = class FavouritesPageRoutingModule {
};
FavouritesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FavouritesPageRoutingModule);



/***/ }),

/***/ 25986:
/*!**************************************************************!*\
  !*** ./src/app/pages/fruits/favourites/favourites.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FavouritesPageModule": () => (/* binding */ FavouritesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _favourites_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./favourites-routing.module */ 5530);
/* harmony import */ var _favourites_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./favourites.page */ 37703);







let FavouritesPageModule = class FavouritesPageModule {
};
FavouritesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _favourites_routing_module__WEBPACK_IMPORTED_MODULE_0__.FavouritesPageRoutingModule
        ],
        declarations: [_favourites_page__WEBPACK_IMPORTED_MODULE_1__.FavouritesPage]
    })
], FavouritesPageModule);



/***/ }),

/***/ 37703:
/*!************************************************************!*\
  !*** ./src/app/pages/fruits/favourites/favourites.page.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FavouritesPage": () => (/* binding */ FavouritesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_favourites_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./favourites.page.html */ 21349);
/* harmony import */ var _favourites_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./favourites.page.scss */ 46808);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let FavouritesPage = class FavouritesPage {
    constructor() { }
    ngOnInit() {
    }
};
FavouritesPage.ctorParameters = () => [];
FavouritesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-favourites',
        template: _raw_loader_favourites_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_favourites_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], FavouritesPage);



/***/ }),

/***/ 46808:
/*!**************************************************************!*\
  !*** ./src/app/pages/fruits/favourites/favourites.page.scss ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".toolbar {\n  height: 84px;\n  --background:#69A03A;\n  color: #fff;\n  font-size: 20px;\n  line-height: 84px;\n}\n\n.container {\n  width: 100%;\n}\n\n.container ion-thumbnail {\n  width: 100px !important;\n  height: 100px !important;\n}\n\n.container ion-thumbnail img {\n  border-radius: 10px;\n}\n\n.container #rate {\n  color: #ccc;\n}\n\n.container #qty {\n  margin-top: 5px;\n}\n\n.container #qty .plus {\n  margin-left: 20px;\n  font-weight: 600;\n  padding: 5px;\n}\n\n.container #qty .minus {\n  font-weight: 600;\n  padding: 5px;\n  margin-right: 20px;\n}\n\n.container #qty #btn {\n  padding: 10px 20px;\n  color: #fff;\n  background: #69A03A;\n}\n\n.container ion-label ion-icon {\n  margin-right: 10px;\n  color: #69A03A;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZhdm91cml0ZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtFQUNBLG9CQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUNKOztBQUVBO0VBQ0ksV0FBQTtBQUNKOztBQUNJO0VBQ0ksdUJBQUE7RUFDQSx3QkFBQTtBQUNSOztBQUFRO0VBQ0ksbUJBQUE7QUFFWjs7QUFFSTtFQUNJLFdBQUE7QUFBUjs7QUFHSTtFQUNJLGVBQUE7QUFEUjs7QUFFUTtFQUNRLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0FBQWhCOztBQUlZO0VBRUksZ0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFIaEI7O0FBTVk7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtBQUpoQjs7QUFXUTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQVRaIiwiZmlsZSI6ImZhdm91cml0ZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXJ7XHJcbiAgICBoZWlnaHQ6ODRweDtcclxuICAgIC0tYmFja2dyb3VuZDojNjlBMDNBO1xyXG4gICAgY29sb3I6I2ZmZjtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGxpbmUtaGVpZ2h0Ojg0cHg7XHJcbn1cclxuXHJcbi5jb250YWluZXJ7XHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgXHJcbiAgICBpb24tdGh1bWJuYWlse1xyXG4gICAgICAgIHdpZHRoOjEwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgaGVpZ2h0OjEwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgaW1ne1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAjcmF0ZXtcclxuICAgICAgICBjb2xvcjojY2NjO1xyXG4gICAgfVxyXG5cclxuICAgICNxdHl7XHJcbiAgICAgICAgbWFyZ2luLXRvcDo1cHg7XHJcbiAgICAgICAgLnBsdXN7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDoyMHB4O1xyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6NXB4O1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAubWludXN7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOjVweDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDoyMHB4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAjYnRue1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzoxMHB4IDIwcHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojZmZmO1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDojNjlBMDNBXHJcbiAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuXHJcbiAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDoxMHB4O1xyXG4gICAgICAgICAgICBjb2xvcjojNjlBMDNBO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */");

/***/ }),

/***/ 21349:
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/fruits/favourites/favourites.page.html ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-back-button color=\"light\" defaultHref=\"home1\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Favourites</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content scrollY=\"true\">\n  <div class=\"container\">\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-list style=\"overflow-y: scroll !important; height: 100%;\">\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/brocolli.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Broccoli<span style=\"float: right; color:#69A03A\">\n                    160Per/Kg\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n                <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                  <span style=\"float: right;\">\n                    <button id=\"btn\">Add</button>\n                  </span></div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/onion.jpeg\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Onion<span style=\"float: right ;color:#69A03A\">\n                    160Per/Kg\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n              <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                <span style=\"float: right;\">\n                  <button id=\"btn\">Add</button>\n                </span>\n              </div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/anjir.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Anjeer<span style=\"float: right;color:#69A03A; \">\n                  160Per/Kg\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n              <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                <span style=\"float: right;\">\n                  <button id=\"btn\">Add</button>\n                </span>\n              </div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/tomato.jpg\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Tomato<span style=\"float: right;color:#69A03A;\">\n                  160Per/Kg\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n                <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                  <span style=\"float: right;\">\n                    <button id=\"btn\">Add</button>\n                  </span>\n                </div>\n              </ion-label>\n            </ion-item>\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/bringle.png\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Bringle<span style=\"float: right;color:#69A03A;\">\n                  160Per/Kg\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n                <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                  <span style=\"float: right;\">\n                    <button id=\"btn\">Add</button>\n                  </span>\n                </div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/potato.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Poato<span style=\"float: right;color:#69A03A;\">\n                    160Per/Kg\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n              <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                <span style=\"float: right;\">\n                  <button id=\"btn\">Add</button>\n                </span>\n              </div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/apple.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Apple<span style=\"float: right;color:#69A03A;\">\n                  160Per/Kg\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n              <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                <span style=\"float: right;\">\n                  <button id=\"btn\">Add</button>\n                </span>\n              </div>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/orange.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Orange<span style=\"float: right;color:#69A03A;\">\n                    160Per/Kg\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n              <div id=\"qty\"><span class=\"minus\"> - </span> 1 <span class=\"plus\"> + </span>\n                <span style=\"float: right;\">\n                  <button id=\"btn\">Add</button>\n                </span>\n              </div>\n              </ion-label>\n            </ion-item>\n          </ion-list>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_fruits_favourites_favourites_module_ts.js.map