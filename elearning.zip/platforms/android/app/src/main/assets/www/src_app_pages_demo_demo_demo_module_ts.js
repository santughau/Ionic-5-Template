(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_demo_demo_demo_module_ts"],{

/***/ 79261:
/*!********************************************************!*\
  !*** ./src/app/pages/demo/demo/demo-routing.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DemoPageRoutingModule": () => (/* binding */ DemoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _demo_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./demo.page */ 38033);




const routes = [
    {
        path: '',
        component: _demo_page__WEBPACK_IMPORTED_MODULE_0__.DemoPage
    }
];
let DemoPageRoutingModule = class DemoPageRoutingModule {
};
DemoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DemoPageRoutingModule);



/***/ }),

/***/ 39340:
/*!************************************************!*\
  !*** ./src/app/pages/demo/demo/demo.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DemoPageModule": () => (/* binding */ DemoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _demo_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./demo-routing.module */ 79261);
/* harmony import */ var _demo_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./demo.page */ 38033);
/* harmony import */ var ngx_mask__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-mask */ 61688);








const maskConfig = {
    validation: false,
};
let DemoPageModule = class DemoPageModule {
};
DemoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _demo_routing_module__WEBPACK_IMPORTED_MODULE_0__.DemoPageRoutingModule, ngx_mask__WEBPACK_IMPORTED_MODULE_7__.NgxMaskModule.forRoot(maskConfig)
        ],
        declarations: [_demo_page__WEBPACK_IMPORTED_MODULE_1__.DemoPage]
    })
], DemoPageModule);



/***/ }),

/***/ 38033:
/*!**********************************************!*\
  !*** ./src/app/pages/demo/demo/demo.page.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DemoPage": () => (/* binding */ DemoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_demo_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./demo.page.html */ 38925);
/* harmony import */ var _demo_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./demo.page.scss */ 73371);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let DemoPage = class DemoPage {
    constructor() { }
    ngOnInit() {
    }
};
DemoPage.ctorParameters = () => [];
DemoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-demo',
        template: _raw_loader_demo_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_demo_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DemoPage);



/***/ }),

/***/ 73371:
/*!************************************************!*\
  !*** ./src/app/pages/demo/demo/demo.page.scss ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("* {\n  margin: 0;\n  padding: 0;\n  box-sizing: border-box;\n}\n\nion-content {\n  --background:#f8f8f8;\n}\n\nion-content .menu_btn {\n  position: relative;\n  top: 40px;\n  left: 10px;\n}\n\n.payment {\n  background: #f8f8f8;\n  width: 100%;\n  margin: 80px auto;\n  height: 100%;\n  padding: 35px;\n  padding-top: 70px;\n  border-radius: 5px;\n  position: relative;\n}\n\n.payment h2 {\n  text-align: center;\n  letter-spacing: 2px;\n  margin-bottom: 40px;\n  color: #0d3c61;\n}\n\n.form .label {\n  display: block;\n  color: #555555;\n  margin-bottom: 6px;\n}\n\n.input {\n  padding: 13px 0px 13px 25px;\n  width: 100%;\n  text-align: center;\n  border: 2px solid #dddddd;\n  border-radius: 5px;\n  letter-spacing: 1px;\n  word-spacing: 3px;\n  outline: none;\n  font-size: 16px;\n  color: #555555;\n}\n\n.card-grp {\n  display: flex;\n  justify-content: space-between;\n}\n\n.card-item {\n  width: 48%;\n}\n\n.space {\n  margin-bottom: 20px;\n}\n\n.icon-relative {\n  position: relative;\n}\n\n.icon-relative .fas,\n.icon-relative .far {\n  position: absolute;\n  bottom: 12px;\n  left: 15px;\n  font-size: 20px;\n  color: #555555;\n}\n\n.btn {\n  margin-top: 40px;\n  background: #2196F3;\n  padding: 12px;\n  text-align: center;\n  color: #f8f8f8;\n  border-radius: 5px;\n  cursor: pointer;\n}\n\n.payment-logo {\n  position: absolute;\n  top: -50px;\n  left: 50%;\n  transform: translateX(-50%);\n  width: 100px;\n  height: 100px;\n  background: #f8f8f8;\n  border-radius: 50%;\n  box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);\n  text-align: center;\n  line-height: 85px;\n}\n\n.payment-logo:before {\n  content: \"\";\n  position: absolute;\n  top: 5px;\n  left: 5px;\n  width: 90px;\n  height: 90px;\n  background: #2196F3;\n  border-radius: 50%;\n}\n\n.payment-logo p {\n  position: relative;\n  color: #f8f8f8;\n  font-family: \"Baloo Bhaijaan\", cursive;\n  font-size: 58px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlbW8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsU0FBQTtFQUNBLFVBQUE7RUFDQSxzQkFBQTtBQUNGOztBQUVBO0VBQ0ksb0JBQUE7QUFDSjs7QUFBSTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7QUFFUjs7QUFHQTtFQUNFLG1CQUFBO0VBQ0QsV0FBQTtFQUNDLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFBRjs7QUFHQTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUFBRjs7QUFHQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFBRjs7QUFHQTtFQUNFLDJCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFBRjs7QUFHQTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtBQUFGOztBQUdBO0VBQ0UsVUFBQTtBQUFGOztBQUdBO0VBQ0UsbUJBQUE7QUFBRjs7QUFHQTtFQUNFLGtCQUFBO0FBQUY7O0FBR0E7O0VBRUUsa0JBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FBQUY7O0FBR0E7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUFGOztBQUlBO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtFQUNBLDJCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0NBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBREY7O0FBSUE7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQURGOztBQUlBO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0Esc0NBQUE7RUFDQSxlQUFBO0FBREYiLCJmaWxlIjoiZGVtby5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIqe1xyXG4gIG1hcmdpbjogMDtcclxuICBwYWRkaW5nOiAwO1xyXG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50e1xyXG4gICAgLS1iYWNrZ3JvdW5kOiNmOGY4Zjg7XHJcbiAgICAubWVudV9idG57XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHRvcDo0MHB4O1xyXG4gICAgICAgIGxlZnQ6MTBweDtcclxuICAgIH1cclxufVxyXG5cclxuXHJcbi5wYXltZW50e1xyXG4gIGJhY2tncm91bmQ6ICNmOGY4Zjg7XHJcbiB3aWR0aDogMTAwJTtcclxuICBtYXJnaW46IDgwcHggYXV0bztcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgcGFkZGluZzogMzVweDtcclxuICBwYWRkaW5nLXRvcDogNzBweDtcclxuICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG4ucGF5bWVudCBoMntcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbGV0dGVyLXNwYWNpbmc6IDJweDtcclxuICBtYXJnaW4tYm90dG9tOiA0MHB4O1xyXG4gIGNvbG9yOiAjMGQzYzYxO1xyXG59XHJcblxyXG4uZm9ybSAubGFiZWx7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgY29sb3I6ICM1NTU1NTU7XHJcbiAgbWFyZ2luLWJvdHRvbTogNnB4O1xyXG59XHJcblxyXG4uaW5wdXR7XHJcbiAgcGFkZGluZzogMTNweCAwcHggMTNweCAyNXB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBib3JkZXI6IDJweCBzb2xpZCAjZGRkZGRkO1xyXG4gIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICBsZXR0ZXItc3BhY2luZzogMXB4O1xyXG4gIHdvcmQtc3BhY2luZzogM3B4O1xyXG4gIG91dGxpbmU6IG5vbmU7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGNvbG9yOiAjNTU1NTU1O1xyXG59XHJcblxyXG4uY2FyZC1ncnB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbn1cclxuXHJcbi5jYXJkLWl0ZW17XHJcbiAgd2lkdGg6IDQ4JTtcclxufVxyXG5cclxuLnNwYWNle1xyXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbn1cclxuXHJcbi5pY29uLXJlbGF0aXZle1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLmljb24tcmVsYXRpdmUgLmZhcyxcclxuLmljb24tcmVsYXRpdmUgLmZhcntcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgYm90dG9tOiAxMnB4O1xyXG4gIGxlZnQ6IDE1cHg7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGNvbG9yOiAjNTU1NTU1O1xyXG59XHJcblxyXG4uYnRue1xyXG4gIG1hcmdpbi10b3A6IDQwcHg7XHJcbiAgYmFja2dyb3VuZDogIzIxOTZGMztcclxuICBwYWRkaW5nOiAxMnB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBjb2xvcjogI2Y4ZjhmODtcclxuICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG5cclxuLnBheW1lbnQtbG9nb3tcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAtNTBweDtcclxuICBsZWZ0OiA1MCU7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xyXG4gIHdpZHRoOiAxMDBweDtcclxuICBoZWlnaHQ6IDEwMHB4O1xyXG4gIGJhY2tncm91bmQ6ICNmOGY4Zjg7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIGJveC1zaGFkb3c6IDAgMCA1cHggcmdiYSgwLDAsMCwwLjIpO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBsaW5lLWhlaWdodDogODVweDtcclxufVxyXG5cclxuLnBheW1lbnQtbG9nbzpiZWZvcmV7XHJcbiAgY29udGVudDogXCJcIjtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiA1cHg7XHJcbiAgbGVmdDogNXB4O1xyXG4gIHdpZHRoOiA5MHB4O1xyXG4gIGhlaWdodDogOTBweDtcclxuICBiYWNrZ3JvdW5kOiAjMjE5NkYzO1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxufVxyXG5cclxuLnBheW1lbnQtbG9nbyBwe1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBjb2xvcjogI2Y4ZjhmODtcclxuICBmb250LWZhbWlseTogJ0JhbG9vIEJoYWlqYWFuJywgY3Vyc2l2ZTtcclxuICBmb250LXNpemU6IDU4cHg7XHJcbn1cclxuXHJcblxyXG4iXX0= */");

/***/ }),

/***/ 38925:
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/demo/demo/demo.page.html ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.4.2/css/all.css\">\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <div class=\"wrapper\">\n          <ion-buttons slot=\"start\" class=\"menu_btn\">\n          <ion-back-button mode=\"md\" defaultHref=\"/home\" color=\"primary\"></ion-back-button>\n          </ion-buttons>\n          <div class=\"payment\">\n            <div class=\"payment-logo\">\n              <p>p</p>\n            </div>\n        \n        \n            <h2>Payment Gateway</h2>\n            <div class=\"form\">\n              <div class=\"card space icon-relative\">\n                <label class=\"label\">Card holder:</label>\n                <input type=\"text\" class=\"input\" placeholder=\"JSWEBAPP\">\n                <i class=\"fas fa-user\"></i>\n              </div>\n              <div class=\"card space icon-relative\">\n                <label class=\"label\">Card number:</label>\n                <input type=\"text\" class=\"input\" mask=\"0000 0000 0000 0000\" placeholder=\"Card Number\">\n                <i class=\"far fa-credit-card\"></i>\n              </div>\n              <div class=\"card-grp space\">\n                <div class=\"card-item icon-relative\">\n                  <label class=\"label\">Expiry date:</label>\n                  <input type=\"text\" name=\"expiry-data\"  class=\"input\" mask=\"00 00\" placeholder=\"00 / 00\">\n                  <i class=\"far fa-calendar-alt\"></i>\n                </div>\n                <div class=\"card-item icon-relative\">\n                  <label class=\"label\">CVV:</label>\n                  <input type=\"text\" class=\"input\" mask=\"000\" placeholder=\"000\">\n                  <i class=\"fas fa-lock\"></i>\n                </div>\n              </div>\n        \n              <div class=\"btn\">\n                Pay\n              </div>\n        \n            </div>\n          </div>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_demo_demo_demo_module_ts.js.map