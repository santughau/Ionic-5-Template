(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_fruits_my-orders_my-orders_module_ts"],{

/***/ 43608:
/*!********************************************************************!*\
  !*** ./src/app/pages/fruits/my-orders/my-orders-routing.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyOrdersPageRoutingModule": () => (/* binding */ MyOrdersPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _my_orders_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./my-orders.page */ 31222);




const routes = [
    {
        path: '',
        component: _my_orders_page__WEBPACK_IMPORTED_MODULE_0__.MyOrdersPage
    }
];
let MyOrdersPageRoutingModule = class MyOrdersPageRoutingModule {
};
MyOrdersPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MyOrdersPageRoutingModule);



/***/ }),

/***/ 9505:
/*!************************************************************!*\
  !*** ./src/app/pages/fruits/my-orders/my-orders.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyOrdersPageModule": () => (/* binding */ MyOrdersPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _my_orders_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./my-orders-routing.module */ 43608);
/* harmony import */ var _my_orders_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./my-orders.page */ 31222);







let MyOrdersPageModule = class MyOrdersPageModule {
};
MyOrdersPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _my_orders_routing_module__WEBPACK_IMPORTED_MODULE_0__.MyOrdersPageRoutingModule
        ],
        declarations: [_my_orders_page__WEBPACK_IMPORTED_MODULE_1__.MyOrdersPage]
    })
], MyOrdersPageModule);



/***/ }),

/***/ 31222:
/*!**********************************************************!*\
  !*** ./src/app/pages/fruits/my-orders/my-orders.page.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyOrdersPage": () => (/* binding */ MyOrdersPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_my_orders_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./my-orders.page.html */ 22590);
/* harmony import */ var _my_orders_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./my-orders.page.scss */ 44126);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let MyOrdersPage = class MyOrdersPage {
    constructor() { }
    ngOnInit() {
    }
};
MyOrdersPage.ctorParameters = () => [];
MyOrdersPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-my-orders',
        template: _raw_loader_my_orders_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_my_orders_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MyOrdersPage);



/***/ }),

/***/ 44126:
/*!************************************************************!*\
  !*** ./src/app/pages/fruits/my-orders/my-orders.page.scss ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".toolbar {\n  height: 84px;\n  --background:#69A03A;\n  color: #fff;\n  font-size: 20px;\n  line-height: 84px;\n}\n\n.container {\n  width: 100%;\n}\n\n.container ion-thumbnail {\n  width: 100px !important;\n  height: 100px !important;\n}\n\n.container ion-thumbnail img {\n  border-radius: 10px;\n}\n\n.container #rate {\n  color: #ccc;\n}\n\n.container .plus {\n  margin-left: 20px;\n  font-weight: 600;\n  padding: 5px;\n}\n\n.container .minus {\n  font-weight: 600;\n  padding: 5px;\n  margin-right: 20px;\n}\n\n.container ion-label ion-icon {\n  margin-right: 10px;\n  color: #69A03A;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm15LW9yZGVycy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0Esb0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxXQUFBO0FBQ0o7O0FBQUk7RUFDSSx1QkFBQTtFQUNBLHdCQUFBO0FBRVI7O0FBRFE7RUFDSSxtQkFBQTtBQUdaOztBQUNJO0VBQ0ksV0FBQTtBQUNSOztBQUNJO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUFDUjs7QUFFSTtFQUVJLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBRFI7O0FBS1E7RUFDSSxrQkFBQTtFQUNBLGNBQUE7QUFIWiIsImZpbGUiOiJteS1vcmRlcnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXJ7XHJcbiAgICBoZWlnaHQ6ODRweDtcclxuICAgIC0tYmFja2dyb3VuZDojNjlBMDNBO1xyXG4gICAgY29sb3I6I2ZmZjtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGxpbmUtaGVpZ2h0Ojg0cHg7XHJcbn1cclxuXHJcbi5jb250YWluZXJ7XHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgaW9uLXRodW1ibmFpbHtcclxuICAgICAgICB3aWR0aDoxMDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIGhlaWdodDoxMDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIGltZ3tcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgI3JhdGV7XHJcbiAgICAgICAgY29sb3I6I2NjYztcclxuICAgIH1cclxuICAgIC5wbHVze1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OjIwcHg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICBwYWRkaW5nOjVweDtcclxuICAgICAgICBcclxuICAgIH1cclxuICAgIC5taW51c3tcclxuICAgICAgICBcclxuICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgIHBhZGRpbmc6NXB4O1xyXG4gICAgICAgIG1hcmdpbi1yaWdodDoyMHB4O1xyXG4gICAgfVxyXG5cclxuICAgIGlvbi1sYWJlbHtcclxuICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OjEwcHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiM2OUEwM0E7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */");

/***/ }),

/***/ 22590:
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/fruits/my-orders/my-orders.page.html ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-back-button color=\"light\" defaultHref=\"home1\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Details</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content scrollY=\"true\">\n  <div class=\"container\">\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-list style=\"overflow-y: scroll !important; height: 100%;\">\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/brocolli.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Broccoli<span style=\"float: right\">\n                    <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n                <p>Delivered On 23 Aug 1980</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/onion.jpeg\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Onion<span style=\"float: right\">\n                    <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n                <p>Delivered On 23 Aug 1980</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/anjir.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Anjeer<span style=\"float: right\">\n                    <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n                <p>Delivered On 23 Aug 1980</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/tomato.jpg\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Tomato<span style=\"float: right\">\n                    <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n                <p>Delivered On 23 Aug 1980</p>\n              </ion-label>\n            </ion-item>\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/bringle.png\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Bringle<span style=\"float: right\">\n                    <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n                <p>Delivered On 23 Aug 1980</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/potato.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Poato<span style=\"float: right\">\n                    <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n                <p>Delivered On 23 Aug 1980</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/apple.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Apple<span style=\"float: right\">\n                    <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n                <p>Delivered On 23 Aug 1980</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\">\n                <img src=\"../../../../assets/orange.jfif\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Orange<span style=\"float: right\">\n                    <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n                  </span></h2>\n                <h3>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                  <ion-icon name=\"star-outline\"></ion-icon>\n                </h3>\n                <p id=\"rate\">Rate This Product</p>\n                <p>Delivered On 23 Aug 1980</p>\n              </ion-label>\n            </ion-item>\n          </ion-list>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_fruits_my-orders_my-orders_module_ts.js.map