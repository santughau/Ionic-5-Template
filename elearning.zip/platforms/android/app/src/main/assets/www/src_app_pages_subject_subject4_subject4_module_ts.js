(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_subject_subject4_subject4_module_ts"],{

/***/ 64986:
/*!*******************************************************************!*\
  !*** ./src/app/pages/subject/subject4/subject4-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject4PageRoutingModule": () => (/* binding */ Subject4PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _subject4_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject4.page */ 20478);




const routes = [
    {
        path: '',
        component: _subject4_page__WEBPACK_IMPORTED_MODULE_0__.Subject4Page
    }
];
let Subject4PageRoutingModule = class Subject4PageRoutingModule {
};
Subject4PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Subject4PageRoutingModule);



/***/ }),

/***/ 22555:
/*!***********************************************************!*\
  !*** ./src/app/pages/subject/subject4/subject4.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject4PageModule": () => (/* binding */ Subject4PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _subject4_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject4-routing.module */ 64986);
/* harmony import */ var _subject4_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject4.page */ 20478);







let Subject4PageModule = class Subject4PageModule {
};
Subject4PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _subject4_routing_module__WEBPACK_IMPORTED_MODULE_0__.Subject4PageRoutingModule
        ],
        declarations: [_subject4_page__WEBPACK_IMPORTED_MODULE_1__.Subject4Page]
    })
], Subject4PageModule);



/***/ }),

/***/ 20478:
/*!*********************************************************!*\
  !*** ./src/app/pages/subject/subject4/subject4.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject4Page": () => (/* binding */ Subject4Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_subject4_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./subject4.page.html */ 51978);
/* harmony import */ var _subject4_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject4.page.scss */ 2953);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let Subject4Page = class Subject4Page {
    constructor() {
        this.segId = 'Chapters';
    }
    ngOnInit() {
        this.chapters = [
            {
                img: 'assets/light.jpg',
                name: 'Theory of Light',
                per: 90
            },
            {
                img: 'assets/water.jpg',
                name: 'Theory of Water',
                per: 40
            },
            {
                img: 'assets/motion.jpg',
                name: 'Theory of Motion',
                per: 50
            },
            {
                img: 'assets/sound.jpg',
                name: 'Theory of Sound',
                per: 65
            },
            {
                img: 'assets/sky.jpg',
                name: 'Theory of Sky',
                per: 75
            },
            {
                img: 'assets/energy.jpg',
                name: 'Theory of Energy',
                per: 45
            },
        ];
    }
    segmentChanged(eve) {
        this.segId = eve.details.value;
    }
};
Subject4Page.ctorParameters = () => [];
Subject4Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-subject4',
        template: _raw_loader_subject4_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_subject4_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Subject4Page);



/***/ }),

/***/ 2953:
/*!***********************************************************!*\
  !*** ./src/app/pages/subject/subject4/subject4.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".grad_back {\n  width: 100%;\n  height: 150px;\n  background: linear-gradient(to right, #243949, #517fa4);\n  border-bottom-left-radius: 50px;\n  position: relative;\n}\n.grad_back .subject {\n  color: white;\n  font-weight: 600;\n  font-size: 24px;\n  position: absolute;\n  left: 150px;\n  bottom: 16px;\n}\n.grad_back .btn_flex {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  height: 50px;\n  align-items: center;\n  padding-top: 40px;\n}\n.grad_back ion-icon {\n  font-size: 20px;\n  color: white;\n}\n.main_content_div {\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .card_div {\n  padding: 10px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 10px;\n  margin-bottom: 15px;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  position: relative;\n}\n.main_content_div .card_div .download {\n  width: 18px;\n  position: absolute;\n  right: 10px;\n  top: 10px;\n  z-index: 99999;\n}\n.main_content_div .card_div .round_image {\n  height: 50px;\n  width: 50px;\n  border-radius: 50%;\n  min-width: 50px;\n}\n.main_content_div .card_div .content_div {\n  width: 100%;\n  padding-left: 10px;\n  position: relative;\n}\n.main_content_div .card_div .content_div .title_lbl {\n  font-size: 16px;\n  font-weight: 600;\n  color: #243949;\n}\n.main_content_div .card_div .content_div .small_lbl {\n  font-size: 12px;\n  color: gray;\n  margin-top: 5px;\n  margin-bottom: 5px;\n}\n.main_content_div .card_div .content_div .abs_lbl {\n  position: absolute;\n  right: 0;\n  bottom: 0;\n  font-size: 12px;\n  color: #243949;\n}\nion-segment-button {\n  --indicator-color:linear-gradient( to right, #243949 ,#517fa4) ;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1YmplY3Q0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdURBQUE7RUFFQSwrQkFBQTtFQUNBLGtCQUFBO0FBQUo7QUFFSTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBQVI7QUFHSTtFQUNHLFdBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQURQO0FBSUk7RUFDRyxlQUFBO0VBQ0EsWUFBQTtBQUZQO0FBTUE7RUFDSSxhQUFBO0FBSEo7QUFLSTtFQUNJLGNBQUE7QUFIUjtBQU1JO0VBQ0ksYUFBQTtFQUNBLDBDQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFKUjtBQUtRO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxjQUFBO0FBSFo7QUFLUTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBSFo7QUFLUTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBSFo7QUFJWTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFGaEI7QUFLWTtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBSGhCO0FBS1k7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFIaEI7QUFZQTtFQUNJLCtEQUFBO0FBVEoiLCJmaWxlIjoic3ViamVjdDQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmdyYWRfYmFja3tcclxuICAgIHdpZHRoOjEwMCU7XHJcbiAgICBoZWlnaHQ6MTUwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoIHRvIHJpZ2h0LCAjMjQzOTQ5ICwjNTE3ZmE0KTtcclxuICAgIFxyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNTBweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICAuc3ViamVjdHtcclxuICAgICAgICBjb2xvcjp3aGl0ZTtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgICAgICBsZWZ0OjE1MHB4O1xyXG4gICAgICAgIGJvdHRvbToxNnB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5idG5fZmxleHtcclxuICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICBkaXNwbGF5OiBmbGV4OyBcclxuICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgIGhlaWdodDogNTBweDtcclxuICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICBwYWRkaW5nLXRvcDogNDBweDtcclxuICAgIH1cclxuXHJcbiAgICBpb24taWNvbntcclxuICAgICAgIGZvbnQtc2l6ZTogMjBweDsgXHJcbiAgICAgICBjb2xvcjp3aGl0ZTtcclxuICAgIH1cclxufVxyXG5cclxuLm1haW5fY29udGVudF9kaXZ7XHJcbiAgICBwYWRkaW5nOjE2cHg7XHJcblxyXG4gICAgaW9uLWxhYmVse1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgfVxyXG5cclxuICAgIC5jYXJkX2RpdntcclxuICAgICAgICBwYWRkaW5nOjEwcHg7XHJcbiAgICAgICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLDAsMCwwLjIpO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuICAgICAgICAuZG93bmxvYWR7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxOHB4O1xyXG4gICAgICAgICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgICAgICAgICAgcmlnaHQ6IDEwcHg7XHJcbiAgICAgICAgICAgIHRvcDoxMHB4O1xyXG4gICAgICAgICAgICB6LWluZGV4OiA5OTk5OTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnJvdW5kX2ltYWdle1xyXG4gICAgICAgICAgICBoZWlnaHQ6NTBweDtcclxuICAgICAgICAgICAgd2lkdGg6IDUwcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6NTAlO1xyXG4gICAgICAgICAgICBtaW4td2lkdGg6IDUwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5jb250ZW50X2RpdntcclxuICAgICAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OjEwcHg7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICAgICAgLnRpdGxlX2xibHtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojMjQzOTQ5O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuc21hbGxfbGJse1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6Z3JheTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuYWJzX2xibHtcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICAgICAgICBib3R0b206IDA7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojMjQzOTQ5XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5cclxuXHJcbmlvbi1zZWdtZW50LWJ1dHRvbntcclxuICAgIC0taW5kaWNhdG9yLWNvbG9yOmxpbmVhci1ncmFkaWVudCggdG8gcmlnaHQsICMyNDM5NDkgLCM1MTdmYTQpXHJcbn0iXX0= */");

/***/ }),

/***/ 51978:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/subject/subject4/subject4.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <div class=\"grad_back\">\n    <div class=\"btn_flex\">\n      <div>\n        <ion-buttons slot=\"start\">\n          <ion-back-button defaultHref=\"/home1\" color=\"light\"></ion-back-button>\n        </ion-buttons>\n      </div>\n\n      <div>\n        <ion-button fill=\"clear\" size=\"small\">\n          <ion-icon name=\"search-outline\"></ion-icon>\n        </ion-button>\n\n        <ion-button fill=\"clear\" size=\"small\">\n          <ion-icon name=\"notifications-outline\"></ion-icon>\n        </ion-button>\n      </div>\n    </div>\n    <ion-label class=\"subject\">Select Chapter</ion-label>\n  </div>\n\n  <ion-segment value=\"Chapters\" mode=\"md\" (ionChange)=\"segmentChanged($event)\">\n    <ion-segment-button value=\"Chapters\">\n      <ion-label>Chapters</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"Tests\">\n      <ion-label>Tests</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n    <span *ngIf=\"segId == 'Chapters'\">\n      <div class=\"card_div\" *ngFor=\"let item of chapters\">\n        <img src=\"../../../../assets/download.png\" class=\"download\" />\n\n        <div class=\"round_image bg_image\" [style.backgroundImage]=\"'url( ' + item.img+')'\">\n        </div>\n\n        <div class=\"content_div\">\n          <ion-label class=\"title_lbl\">{{item.name}}</ion-label>\n          <ion-label class=\"small_lbl\">{{item.name}}</ion-label>\n          <ion-progress-bar value=\"{{item.per/100}}\"></ion-progress-bar>\n          <ion-label class=\"small_lbl\">Download Notes Of This Chapter</ion-label>\n          <ion-label class=\"abs_lbl\">{{item.per}}</ion-label>\n        </div>\n      </div>\n    </span>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_subject_subject4_subject4_module_ts.js.map