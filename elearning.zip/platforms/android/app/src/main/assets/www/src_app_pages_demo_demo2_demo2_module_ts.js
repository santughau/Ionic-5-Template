(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_demo_demo2_demo2_module_ts"],{

/***/ 4929:
/*!**********************************************************!*\
  !*** ./src/app/pages/demo/demo2/demo2-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Demo2PageRoutingModule": () => (/* binding */ Demo2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _demo2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./demo2.page */ 94840);




const routes = [
    {
        path: '',
        component: _demo2_page__WEBPACK_IMPORTED_MODULE_0__.Demo2Page
    }
];
let Demo2PageRoutingModule = class Demo2PageRoutingModule {
};
Demo2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Demo2PageRoutingModule);



/***/ }),

/***/ 61503:
/*!**************************************************!*\
  !*** ./src/app/pages/demo/demo2/demo2.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Demo2PageModule": () => (/* binding */ Demo2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _demo2_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./demo2-routing.module */ 4929);
/* harmony import */ var _demo2_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./demo2.page */ 94840);







let Demo2PageModule = class Demo2PageModule {
};
Demo2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _demo2_routing_module__WEBPACK_IMPORTED_MODULE_0__.Demo2PageRoutingModule
        ],
        declarations: [_demo2_page__WEBPACK_IMPORTED_MODULE_1__.Demo2Page]
    })
], Demo2PageModule);



/***/ }),

/***/ 94840:
/*!************************************************!*\
  !*** ./src/app/pages/demo/demo2/demo2.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Demo2Page": () => (/* binding */ Demo2Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_demo2_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./demo2.page.html */ 82984);
/* harmony import */ var _demo2_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./demo2.page.scss */ 81109);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let Demo2Page = class Demo2Page {
    constructor() { }
    ngOnInit() {
    }
};
Demo2Page.ctorParameters = () => [];
Demo2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-demo2',
        template: _raw_loader_demo2_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_demo2_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Demo2Page);



/***/ }),

/***/ 81109:
/*!**************************************************!*\
  !*** ./src/app/pages/demo/demo2/demo2.page.scss ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background:linear-gradient( to right, #757677 , #d4d6d6);\n}\nion-content .menu_btn {\n  position: relative;\n  top: 40px;\n  left: 10px;\n}\n.container {\n  width: 90%;\n  height: 100vh;\n  margin: 0px 20px;\n}\n.card {\n  border-radius: 25px;\n}\n.card-head {\n  position: relative;\n  height: 300px;\n  background: #fa782e;\n  border-radius: 25px 25px 0 0;\n}\n.card-logo {\n  width: 55px;\n  margin: 20px;\n}\n.product-img {\n  position: absolute;\n  left: 0;\n  margin-top: -16px;\n  margin-left: 50px;\n}\n.product-detail {\n  padding: 0 20px;\n  font-size: 11px;\n  color: #fff;\n}\n.product-detail h2 {\n  font-size: 18px;\n  font-weight: 500;\n  letter-spacing: 2px;\n  padding-bottom: 10px;\n  text-transform: uppercase;\n}\n.back-text {\n  display: inline-block;\n  font-size: 125px;\n  font-weight: 900;\n  margin-left: -7px;\n  margin-top: -12px;\n  opacity: 0.1;\n}\n.card-body {\n  height: 355px;\n  background: white;\n  border: 2px solid #fa782e;\n  border-radius: 0 0 25px 25px;\n}\n.product-title {\n  padding: 20px 20px 5px 20px;\n  display: block;\n  font-size: 17px;\n  font-weight: 500;\n  letter-spacing: 1px;\n  text-transform: uppercase;\n}\n.product-title b {\n  font-weight: 900;\n  letter-spacing: 0px;\n}\n.badge {\n  position: relative;\n  font-size: 10px;\n  font-weight: 300;\n  color: #fff;\n  background: #11e95b;\n  padding: 2px 5px;\n  border-radius: 4px;\n  top: -2px;\n  margin-left: 5px;\n}\n.product-caption {\n  display: block;\n  padding: 0 20px;\n  font-size: 10px;\n  font-weight: 400;\n  text-transform: uppercase;\n}\n.product-rating {\n  padding: 0 20px;\n  font-size: 11px;\n}\n.product-rating i.grey {\n  color: #acacab;\n}\n.product-size h4 {\n  font-size: 11px;\n  padding: 0 21px;\n  margin-top: 15px;\n  padding-bottom: 10px;\n  text-transform: uppercase;\n}\n.ul-size {\n  margin-left: 15px;\n}\n.ul-size li {\n  list-style: none;\n  float: left;\n  margin-right: 20px;\n}\n.ul-size li a {\n  display: inline-block;\n  text-decoration: none;\n  font-size: 11px;\n  width: 22px;\n  height: 22px;\n  border-radius: 100%;\n  text-align: center;\n  line-height: 23px;\n  color: #000;\n}\n.ul-size li a.active {\n  background: #f35e3d;\n  color: #fff;\n}\n.product-size:before,\n.product-size:after {\n  content: \"\";\n  display: block;\n  clear: both;\n}\n.product-color h4 {\n  font-size: 11px;\n  padding: 0 21px;\n  margin-top: 20px;\n  padding-bottom: 20px;\n  text-transform: uppercase;\n}\n.ul-color {\n  margin-left: 27px;\n}\n.ul-color li {\n  list-style: none;\n  float: left;\n  margin-right: 20px;\n}\n.ul-color li a {\n  display: inline-block;\n  width: 16px;\n  height: 16px;\n  border-radius: 100%;\n}\n.ul-color li a.orange {\n  background: #f35e3d;\n}\n.ul-color li a.green {\n  background: #11e95b;\n}\n.ul-color li a.yellow {\n  background: #ffd414;\n}\n.ul-color li a.active:after {\n  position: absolute;\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #f35e3d;\n  width: 24px;\n  height: 24px;\n  border-radius: 100%;\n  margin-left: -5px;\n  margin-top: -5px;\n}\n.product-price {\n  position: absolute;\n  background: #11e95b;\n  padding: 7px 20px;\n  text-align: center;\n  display: inline-block;\n  font-size: 24px;\n  font-weight: 200;\n  color: #fff;\n  border-radius: 7px;\n  margin-top: -13px;\n  margin-left: -5px;\n  box-shadow: -10px 20px 15px -10px rgba(17, 233, 91, 0.3);\n}\n.product-price b {\n  margin-left: 5px;\n}\n.yt {\n  position: fixed;\n  padding: 7px 10px 3px 10px;\n  top: 5px;\n  right: 5px;\n  background: rgba(0, 0, 0, 0.1);\n}\n.yt:hover {\n  background: rgba(0, 0, 0, 0.2);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlbW8yLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDBEQUFBO0FBQ0o7QUFBSTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7QUFFUjtBQUVBO0VBQ0UsVUFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtBQUNGO0FBR0E7RUFDRSxtQkFBQTtBQUFGO0FBSUE7RUFDRSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDRCQUFBO0FBREY7QUFJQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBREY7QUFJQTtFQUNFLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7QUFERjtBQUlBO0VBQ0UsZUFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0FBREY7QUFLQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esb0JBQUE7RUFDQSx5QkFBQTtBQUZGO0FBS0E7RUFDRSxxQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtBQUZGO0FBS0E7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLDRCQUFBO0FBRkY7QUFLQTtFQUNFLDJCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7QUFGRjtBQUtBO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtBQUZGO0FBS0E7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7QUFGRjtBQUtBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtBQUZGO0FBS0E7RUFDRSxlQUFBO0VBQ0EsZUFBQTtBQUZGO0FBS0E7RUFDRSxjQUFBO0FBRkY7QUFLQTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtFQUNBLHlCQUFBO0FBRkY7QUFLQTtFQUNFLGlCQUFBO0FBRkY7QUFLQTtFQUNFLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FBRkY7QUFLQTtFQUNFLHFCQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0FBRkY7QUFLQTtFQUNFLG1CQUFBO0VBQ0EsV0FBQTtBQUZGO0FBS0E7O0VBRUUsV0FBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0FBRkY7QUFLQTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtFQUNBLHlCQUFBO0FBRkY7QUFLQTtFQUNFLGlCQUFBO0FBRkY7QUFLQTtFQUNFLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FBRkY7QUFLQTtFQUNFLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQUZGO0FBS0E7RUFDRSxtQkFBQTtBQUZGO0FBS0E7RUFDRSxtQkFBQTtBQUZGO0FBS0E7RUFDRSxtQkFBQTtBQUZGO0FBS0E7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFGRjtBQUtBO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSx3REFBQTtBQUZGO0FBS0E7RUFDRSxnQkFBQTtBQUZGO0FBT0E7RUFFRSxlQUFBO0VBQ0EsMEJBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtFQUNBLDhCQUFBO0FBTEY7QUFRQTtFQUVFLDhCQUFBO0FBTkYiLCJmaWxlIjoiZGVtbzIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAtLWJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCAgdG8gcmlnaHQsICM3NTc2NzcgLCAjZDRkNmQ2KTtcclxuICAgIC5tZW51X2J0bntcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOjQwcHg7XHJcbiAgICAgICAgbGVmdDoxMHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG4uY29udGFpbmVyIHtcclxuICB3aWR0aDogOTAlO1xyXG4gIGhlaWdodDogMTAwdmg7XHJcbiAgbWFyZ2luOjBweCAyMHB4O1xyXG4gIFxyXG59XHJcblxyXG4uY2FyZCB7XHJcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuIFxyXG59XHJcblxyXG4uY2FyZC1oZWFkIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgaGVpZ2h0OiAzMDBweDtcclxuICBiYWNrZ3JvdW5kOiAjZmE3ODJlOyBcclxuICBib3JkZXItcmFkaXVzOiAyNXB4IDI1cHggMCAwO1xyXG59XHJcblxyXG4uY2FyZC1sb2dvIHtcclxuICB3aWR0aDogNTVweDtcclxuICBtYXJnaW46IDIwcHg7XHJcbn1cclxuXHJcbi5wcm9kdWN0LWltZyB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGxlZnQ6IDA7XHJcbiAgbWFyZ2luLXRvcDogLTE2cHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDUwcHg7XHJcbn1cclxuXHJcbi5wcm9kdWN0LWRldGFpbCB7XHJcbiAgcGFkZGluZzogMCAyMHB4O1xyXG4gIGZvbnQtc2l6ZTogMTFweDtcclxuICBjb2xvcjogI2ZmZjtcclxuICBcclxufVxyXG5cclxuLnByb2R1Y3QtZGV0YWlsIGgyIHtcclxuICBmb250LXNpemU6IDE4cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBsZXR0ZXItc3BhY2luZzogMnB4O1xyXG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbn1cclxuXHJcbi5iYWNrLXRleHQge1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBmb250LXNpemU6IDEyNXB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA5MDA7XHJcbiAgbWFyZ2luLWxlZnQ6IC03cHg7XHJcbiAgbWFyZ2luLXRvcDogLTEycHg7XHJcbiAgb3BhY2l0eTogMC4xO1xyXG59XHJcblxyXG4uY2FyZC1ib2R5IHtcclxuICBoZWlnaHQ6IDM1NXB4O1xyXG4gIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gIGJvcmRlcjoycHggc29saWQgI2ZhNzgyZTtcclxuICBib3JkZXItcmFkaXVzOiAwIDAgMjVweCAyNXB4O1xyXG59XHJcblxyXG4ucHJvZHVjdC10aXRsZSB7XHJcbiAgcGFkZGluZzogMjBweCAyMHB4IDVweCAyMHB4O1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIGZvbnQtc2l6ZTogMTdweDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxufVxyXG5cclxuLnByb2R1Y3QtdGl0bGUgYiB7XHJcbiAgZm9udC13ZWlnaHQ6IDkwMDtcclxuICBsZXR0ZXItc3BhY2luZzogMHB4O1xyXG59XHJcblxyXG4uYmFkZ2Uge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBmb250LXNpemU6IDEwcHg7XHJcbiAgZm9udC13ZWlnaHQ6IDMwMDtcclxuICBjb2xvcjogI2ZmZjtcclxuICBiYWNrZ3JvdW5kOiAjMTFlOTViO1xyXG4gIHBhZGRpbmc6IDJweCA1cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIHRvcDogLTJweDtcclxuICBtYXJnaW4tbGVmdDogNXB4O1xyXG59XHJcblxyXG4ucHJvZHVjdC1jYXB0aW9uIHtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBwYWRkaW5nOiAwIDIwcHg7XHJcbiAgZm9udC1zaXplOiAxMHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxufVxyXG5cclxuLnByb2R1Y3QtcmF0aW5nIHtcclxuICBwYWRkaW5nOiAwIDIwcHg7XHJcbiAgZm9udC1zaXplOiAxMXB4O1xyXG59XHJcblxyXG4ucHJvZHVjdC1yYXRpbmcgaS5ncmV5IHtcclxuICBjb2xvcjogI2FjYWNhYjtcclxufVxyXG5cclxuLnByb2R1Y3Qtc2l6ZSBoNCB7XHJcbiAgZm9udC1zaXplOiAxMXB4O1xyXG4gIHBhZGRpbmc6IDAgMjFweDtcclxuICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbn1cclxuXHJcbi51bC1zaXplIHtcclxuICBtYXJnaW4tbGVmdDogMTVweDtcclxufVxyXG5cclxuLnVsLXNpemUgbGkge1xyXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XHJcbiAgZmxvYXQ6IGxlZnQ7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xyXG59XHJcblxyXG4udWwtc2l6ZSBsaSBhIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gIGZvbnQtc2l6ZTogMTFweDtcclxuICB3aWR0aDogMjJweDtcclxuICBoZWlnaHQ6IDIycHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbGluZS1oZWlnaHQ6IDIzcHg7XHJcbiAgY29sb3I6ICMwMDA7XHJcbn1cclxuXHJcbi51bC1zaXplIGxpIGEuYWN0aXZlIHtcclxuICBiYWNrZ3JvdW5kOiAjZjM1ZTNkO1xyXG4gIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG4ucHJvZHVjdC1zaXplOmJlZm9yZSxcclxuLnByb2R1Y3Qtc2l6ZTphZnRlciB7XHJcbiAgY29udGVudDogJyc7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgY2xlYXI6IGJvdGg7XHJcbn1cclxuXHJcbi5wcm9kdWN0LWNvbG9yIGg0IHtcclxuICBmb250LXNpemU6IDExcHg7XHJcbiAgcGFkZGluZzogMCAyMXB4O1xyXG4gIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDIwcHg7XHJcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxufVxyXG5cclxuLnVsLWNvbG9yIHtcclxuICBtYXJnaW4tbGVmdDogMjdweDtcclxufVxyXG5cclxuLnVsLWNvbG9yIGxpIHtcclxuICBsaXN0LXN0eWxlOiBub25lO1xyXG4gIGZsb2F0OiBsZWZ0O1xyXG4gIG1hcmdpbi1yaWdodDogMjBweDtcclxufVxyXG5cclxuLnVsLWNvbG9yIGxpIGEge1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICB3aWR0aDogMTZweDtcclxuICBoZWlnaHQ6IDE2cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcclxufVxyXG5cclxuLnVsLWNvbG9yIGxpIGEub3JhbmdlIHtcclxuICBiYWNrZ3JvdW5kOiAjZjM1ZTNkO1xyXG59XHJcblxyXG4udWwtY29sb3IgbGkgYS5ncmVlbiB7XHJcbiAgYmFja2dyb3VuZDogIzExZTk1YjtcclxufVxyXG5cclxuLnVsLWNvbG9yIGxpIGEueWVsbG93IHtcclxuICBiYWNrZ3JvdW5kOiAjZmZkNDE0O1xyXG59XHJcblxyXG4udWwtY29sb3IgbGkgYS5hY3RpdmU6YWZ0ZXIge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBjb250ZW50OiAnJztcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2YzNWUzZDtcclxuICB3aWR0aDogMjRweDtcclxuICBoZWlnaHQ6IDI0cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcclxuICBtYXJnaW4tbGVmdDogLTVweDtcclxuICBtYXJnaW4tdG9wOiAtNXB4O1xyXG59XHJcblxyXG4ucHJvZHVjdC1wcmljZSB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGJhY2tncm91bmQ6ICMxMWU5NWI7XHJcbiAgcGFkZGluZzogN3B4IDIwcHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBmb250LXNpemU6IDI0cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDIwMDtcclxuICBjb2xvcjogI2ZmZjtcclxuICBib3JkZXItcmFkaXVzOiA3cHg7XHJcbiAgbWFyZ2luLXRvcDogLTEzcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IC01cHg7XHJcbiAgYm94LXNoYWRvdzogLTEwcHggMjBweCAxNXB4IC0xMHB4IHJnYmEoMTcsIDIzMywgOTEsIDAuMyk7XHJcbn1cclxuXHJcbi5wcm9kdWN0LXByaWNlIGIge1xyXG4gIG1hcmdpbi1sZWZ0OiA1cHg7XHJcbn1cclxuXHJcblxyXG5cclxuLnl0XHJcbntcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgcGFkZGluZzo3cHggMTBweCAzcHggMTBweDtcclxuICB0b3A6IDVweDtcclxuICByaWdodDogNXB4O1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoMCwwLDAsMC4xKTtcclxufVxyXG5cclxuLnl0OmhvdmVyXHJcbntcclxuICBiYWNrZ3JvdW5kOiByZ2JhKDAsMCwwLDAuMik7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 82984:
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/demo/demo2/demo2.page.html ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n      <ion-buttons slot=\"start\" class=\"menu_btn\">\n        <ion-menu-button color=\"danger\"></ion-menu-button>\n      </ion-buttons>\n      <div class=\"container\">\n        \n        <div class=\"card\">\n         \n          <div class=\"card-head\">\n            <img src=\"https://s5.postimg.cc/wy79025cz/nike_Logo_White.png\" alt=\"logo\" class=\"card-logo\">\n            <img src=\"https://s5.postimg.cc/j9r8yf9gn/sws1.png\" alt=\"Shoe\" class=\"product-img\">\n            <div class=\"product-detail\">\n              <h2>Hartbeespoort</h2> Support and Nike Zoom Air come together for a more supportive feel with high-speed\n              responsiveness\n            </div>\n            <span class=\"back-text\">\n              FAS\n            </span>\n          </div>\n          <div class=\"card-body\">\n            <div class=\"product-desc\">\n              <span class=\"product-title\">\n                Hartbee<b>spoort</b>\n                <span class=\"badge\">\n                  New\n                </span>\n              </span>\n              <span class=\"product-caption\">\n                Basket Ball Collection\n              </span>\n              <span class=\"product-rating\">\n                <i class=\"fa fa-star\"></i>\n                <i class=\"fa fa-star\"></i>\n                <i class=\"fa fa-star\"></i>\n                <i class=\"fa fa-star\"></i>\n                <i class=\"fa fa-star grey\"></i>\n              </span>\n            </div>\n            <div class=\"product-properties\">\n              <span class=\"product-size\">\n                <h4>Size</h4>\n                <ul class=\"ul-size\">\n                  <li><a href=\"#\">7</a></li>\n                  <li><a href=\"#\">8</a></li>\n                  <li><a href=\"#\">9</a></li>\n                  <li><a href=\"#\" class=\"active\">10</a></li>\n                  <li><a href=\"#\">11</a></li>\n                </ul>\n              </span>\n              <span class=\"product-color\">\n                <h4>Colour</h4>\n                <ul class=\"ul-color\">\n                  <li><a href=\"#\" class=\"orange active\"></a></li>\n                  <li><a href=\"#\" class=\"green\"></a></li>\n                  <li><a href=\"#\" class=\"yellow\"></a></li>\n                </ul>\n              </span>\n              <span class=\"product-price\">\n                USD<b>23,453</b>\n              </span>\n            </div>\n          </div>\n        </div>\n      </div>\n   ");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_demo_demo2_demo2_module_ts.js.map