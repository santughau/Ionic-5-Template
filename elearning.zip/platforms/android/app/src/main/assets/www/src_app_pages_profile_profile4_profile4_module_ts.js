(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_profile_profile4_profile4_module_ts"],{

/***/ 27456:
/*!*******************************************************************!*\
  !*** ./src/app/pages/profile/profile4/profile4-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Profile4PageRoutingModule": () => (/* binding */ Profile4PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _profile4_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile4.page */ 84181);




const routes = [
    {
        path: '',
        component: _profile4_page__WEBPACK_IMPORTED_MODULE_0__.Profile4Page
    }
];
let Profile4PageRoutingModule = class Profile4PageRoutingModule {
};
Profile4PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Profile4PageRoutingModule);



/***/ }),

/***/ 30105:
/*!***********************************************************!*\
  !*** ./src/app/pages/profile/profile4/profile4.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Profile4PageModule": () => (/* binding */ Profile4PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _profile4_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile4-routing.module */ 27456);
/* harmony import */ var _profile4_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile4.page */ 84181);







let Profile4PageModule = class Profile4PageModule {
};
Profile4PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _profile4_routing_module__WEBPACK_IMPORTED_MODULE_0__.Profile4PageRoutingModule
        ],
        declarations: [_profile4_page__WEBPACK_IMPORTED_MODULE_1__.Profile4Page]
    })
], Profile4PageModule);



/***/ }),

/***/ 84181:
/*!*********************************************************!*\
  !*** ./src/app/pages/profile/profile4/profile4.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Profile4Page": () => (/* binding */ Profile4Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_profile4_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./profile4.page.html */ 48689);
/* harmony import */ var _profile4_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile4.page.scss */ 79133);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let Profile4Page = class Profile4Page {
    constructor() { }
    ngOnInit() {
    }
};
Profile4Page.ctorParameters = () => [];
Profile4Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-profile4',
        template: _raw_loader_profile4_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_profile4_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Profile4Page);



/***/ }),

/***/ 79133:
/*!***********************************************************!*\
  !*** ./src/app/pages/profile/profile4/profile4.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".main_content_div {\n  width: 100%;\n}\n.main_content_div .menu_btn {\n  position: absolute;\n  top: 40px;\n  left: 10;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .user_div {\n  padding: 20px;\n  width: 100%;\n  height: 260px;\n  background: linear-gradient(to right, #243949, #517fa4);\n  display: flex;\n  justify-content: space-between;\n  padding-top: 40px;\n}\n.main_content_div .user_div .first_div {\n  padding-top: 70px;\n}\n.main_content_div .user_div .first_div .username {\n  font-size: 18px;\n  color: white;\n  font-weight: 600;\n}\n.main_content_div .user_div .user_back {\n  height: 100px;\n  width: 80px;\n  border: 3px solid white;\n  background-position: top;\n  background-size: cover;\n  background-repeat: no-repeat;\n  border-radius: 7px;\n}\n.main_content_div .content_div {\n  background: white;\n  width: 100%;\n  border-top-left-radius: 75px;\n  border-top-right-radius: 75px;\n  margin-top: -90px;\n  padding: 20px;\n  padding-top: 30px;\n}\n.main_content_div .content_div .test_detail {\n  width: 100%;\n  border-radius: 5px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n  padding: 10px;\n}\n.main_content_div .content_div .test_detail ion-grid {\n  padding: 0;\n}\n.main_content_div .content_div .test_detail ion-grid ion-col {\n  padding: 10px;\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div {\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div .round_div {\n  height: 40px;\n  width: 40px;\n  border-radius: 100%;\n  background: #243949;\n  position: relative;\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div .round_div img {\n  width: 30px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div .details {\n  padding-left: 5px;\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div .details .bold_lbl {\n  font-weight: 600;\n  font-size: 14px;\n}\n.main_content_div .content_div .test_detail ion-grid .flex_div .details .small_lbl {\n  font-size: 12px;\n}\n.main_content_div .content_div .list_div {\n  display: flex;\n  justify-content: space-between;\n  border-radius: 5px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n  margin-top: 20px;\n  padding: 15px;\n}\n.main_content_div .content_div .list_div ion-icon {\n  font-size: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2ZpbGU0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUFDSjtBQUFJO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0VBQ0EsUUFBQTtBQUVSO0FBQ0k7RUFDSSxjQUFBO0FBQ1I7QUFDSTtFQUNJLGFBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLHVEQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsaUJBQUE7QUFDUjtBQUNRO0VBQ0EsaUJBQUE7QUFDUjtBQUFZO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUVoQjtBQUNJO0VBQ0ksYUFBQTtFQUNBLFdBQUE7RUFDQSx1QkFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7RUFDQSw0QkFBQTtFQUNBLGtCQUFBO0FBQ1I7QUFFSTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtBQUFKO0FBQ0k7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtFQUNBLGFBQUE7QUFDUjtBQUFRO0VBQ0ksVUFBQTtBQUVaO0FBRFk7RUFDSSxhQUFBO0FBR2hCO0FBRFk7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQUdoQjtBQUZnQjtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBSXBCO0FBSG9CO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtBQUt4QjtBQUZnQjtFQUNJLGlCQUFBO0FBSXBCO0FBSG9CO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0FBS3hCO0FBRm9CO0VBQ0ksZUFBQTtBQUl4QjtBQUdJO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtBQURSO0FBR1E7RUFDSSxlQUFBO0FBRFoiLCJmaWxlIjoicHJvZmlsZTQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW5fY29udGVudF9kaXZ7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIC5tZW51X2J0bntcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgdG9wOjQwcHg7XHJcbiAgICAgICAgbGVmdDoxMDtcclxuICAgIH1cclxuXHJcbiAgICBpb24tbGFiZWwge1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgfVxyXG4gICAgLnVzZXJfZGl2e1xyXG4gICAgICAgIHBhZGRpbmc6IDIwcHg7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgaGVpZ2h0OiAyNjBweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCggdG8gcmlnaHQsICMyNDM5NDkgLCM1MTdmYTQgKTtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDpzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIHBhZGRpbmctdG9wOjQwcHg7XHJcbiAgICBcclxuICAgICAgICAuZmlyc3RfZGl2e1xyXG4gICAgICAgIHBhZGRpbmctdG9wOjcwcHg7XHJcbiAgICAgICAgICAgIC51c2VybmFtZXtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAudXNlcl9iYWNre1xyXG4gICAgICAgIGhlaWdodDoxMDBweDtcclxuICAgICAgICB3aWR0aDogODBweDtcclxuICAgICAgICBib3JkZXI6M3B4IHNvbGlkIHdoaXRlO1xyXG4gICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IHRvcDtcclxuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czo3cHggO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5jb250ZW50X2RpdntcclxuICAgIGJhY2tncm91bmQ6d2hpdGU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6NzVweDtcclxuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOjc1cHg7XHJcbiAgICBtYXJnaW4tdG9wOi05MHB4O1xyXG4gICAgcGFkZGluZzoyMHB4O1xyXG4gICAgcGFkZGluZy10b3A6MzBweDtcclxuICAgIC50ZXN0X2RldGFpbHtcclxuICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsMCwwLDAuMyk7XHJcbiAgICAgICAgcGFkZGluZzoxMHB4O1xyXG4gICAgICAgIGlvbi1ncmlke1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICBpb24tY29se1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzoxMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5mbGV4X2RpdntcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6ZmxleDtcclxuICAgICAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOnJvdztcclxuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAucm91bmRfZGl2e1xyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDo0MHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOjQwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czoxMDAlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IzI0Mzk0OTtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuICAgICAgICAgICAgICAgICAgICBpbWd7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOjMwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b3A6NTAlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OjUwJTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAuZGV0YWlsc3tcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDVweDtcclxuICAgICAgICAgICAgICAgICAgICAuYm9sZF9sYmx7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZToxNHB4O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLnNtYWxsX2xibHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAubGlzdF9kaXZ7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6c3BhY2UtYmV0d2VlbjtcclxuICAgICAgICBib3JkZXItcmFkaXVzOjVweDtcclxuICAgICAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsMCwwLDAuMyk7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAgICAgICBwYWRkaW5nOjE1cHg7XHJcblxyXG4gICAgICAgIGlvbi1pY29ue1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbn1cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ 48689:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile4/profile4.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"main_content_div\">\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n\n    <div class=\"user_div\">\n      <div class=\"first_div\">\n        <ion-label class=\"username\">Yamini</ion-label>\n      </div>\n      <div class=\"user_back\" [style.backgroundImage]=\"'url(assets/14.jpg)'\"></div>\n    </div>\n\n    <div class=\"content_div\">\n      <div class=\"test_detail\">\n        <ion-grid fixed>\n          <ion-row>\n            <ion-col size=\"6\">\n              <div class=\"flex_div\">\n                <div class=\"round_div\">\n                  <img src=\"../../../../assets/idea.png\">\n                </div>\n\n                <div class=\"details\">\n                  <ion-label class=\"bold_lbl\">100</ion-label>\n                  <ion-label class=\"small_lbl\">Attempt</ion-label>\n                </div>\n              </div>\n            </ion-col>\n            <ion-col size=\"6\">\n              <div class=\"flex_div\">\n                <div class=\"round_div\">\n                  <img src=\"../../../../assets/clock.png\">\n                </div>\n\n                <div class=\"details\">\n                  <ion-label class=\"bold_lbl\">2Hr 10 Min</ion-label>\n                  <ion-label class=\"small_lbl\">Time</ion-label>\n                </div>\n              </div>\n            </ion-col>\n            <ion-col size=\"6\">\n              <div class=\"flex_div\">\n                <div class=\"round_div\">\n                  <img src=\"../../../../assets/speed.png\">\n                </div>\n\n                <div class=\"details\">\n                  <ion-label class=\"bold_lbl\">70Q/Hr</ion-label>\n                  <ion-label class=\"small_lbl\">Speed</ion-label>\n                </div>\n              </div>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </div>\n\n      <div class=\"list_div\">\n        <ion-label>Edit Profile</ion-label>\n        <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n      </div>\n\n      <div class=\"list_div\">\n        <ion-label>Test List</ion-label>\n        <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n      </div>\n\n      <div class=\"list_div\">\n        <ion-label>Faviourite Books</ion-label>\n        <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n      </div>\n\n      <div class=\"list_div\">\n        <ion-label>Log Out</ion-label>\n        <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n      </div>\n    </div>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_profile4_profile4_module_ts.js.map