(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_subject_subject1_subject1_module_ts"],{

/***/ 48324:
/*!*******************************************************************!*\
  !*** ./src/app/pages/subject/subject1/subject1-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject1PageRoutingModule": () => (/* binding */ Subject1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _subject1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject1.page */ 66923);




const routes = [
    {
        path: '',
        component: _subject1_page__WEBPACK_IMPORTED_MODULE_0__.Subject1Page
    }
];
let Subject1PageRoutingModule = class Subject1PageRoutingModule {
};
Subject1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Subject1PageRoutingModule);



/***/ }),

/***/ 36285:
/*!***********************************************************!*\
  !*** ./src/app/pages/subject/subject1/subject1.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject1PageModule": () => (/* binding */ Subject1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _subject1_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject1-routing.module */ 48324);
/* harmony import */ var _subject1_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject1.page */ 66923);







let Subject1PageModule = class Subject1PageModule {
};
Subject1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _subject1_routing_module__WEBPACK_IMPORTED_MODULE_0__.Subject1PageRoutingModule
        ],
        declarations: [_subject1_page__WEBPACK_IMPORTED_MODULE_1__.Subject1Page]
    })
], Subject1PageModule);



/***/ }),

/***/ 66923:
/*!*********************************************************!*\
  !*** ./src/app/pages/subject/subject1/subject1.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Subject1Page": () => (/* binding */ Subject1Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_subject1_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./subject1.page.html */ 885);
/* harmony import */ var _subject1_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject1.page.scss */ 20359);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let Subject1Page = class Subject1Page {
    constructor() {
        this.segId = 'Chapters';
    }
    ngOnInit() {
        this.chapters = [
            {
                img: 'assets/light.jpg',
                name: 'Theory of Light',
                per: 90
            },
            {
                img: 'assets/water.jpg',
                name: 'Theory of Water',
                per: 40
            },
            {
                img: 'assets/motion.jpg',
                name: 'Theory of Motion',
                per: 50
            },
            {
                img: 'assets/sound.jpg',
                name: 'Theory of Sound',
                per: 65
            },
            {
                img: 'assets/sky.jpg',
                name: 'Theory of Sky',
                per: 75
            },
            {
                img: 'assets/energy.jpg',
                name: 'Theory of Energy',
                per: 45
            },
        ];
    }
    segmentChanged(eve) {
        this.segId = eve.details.value;
    }
};
Subject1Page.ctorParameters = () => [];
Subject1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-subject1',
        template: _raw_loader_subject1_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_subject1_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Subject1Page);



/***/ }),

/***/ 20359:
/*!***********************************************************!*\
  !*** ./src/app/pages/subject/subject1/subject1.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".grad_back {\n  width: 100%;\n  height: 150px;\n  background: linear-gradient(to right, #b91d73, #f953c6);\n  border-bottom-right-radius: 50px;\n  position: relative;\n}\n.grad_back .subject {\n  color: white;\n  font-weight: 600;\n  font-size: 24px;\n  position: absolute;\n  left: 16px;\n  bottom: 16px;\n}\n.grad_back .btn_flex {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  height: 50px;\n  align-items: center;\n  padding-top: 40px;\n}\n.grad_back ion-icon {\n  font-size: 20px;\n  color: white;\n}\n.main_content_div {\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .card_div {\n  padding: 10px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 10px;\n  margin-bottom: 15px;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  position: relative;\n}\n.main_content_div .card_div .download {\n  width: 18px;\n  position: absolute;\n  right: 10px;\n  top: 10px;\n  z-index: 99999;\n}\n.main_content_div .card_div .round_image {\n  height: 50px;\n  width: 50px;\n  border-radius: 50%;\n  min-width: 50px;\n}\n.main_content_div .card_div .content_div {\n  width: 100%;\n  padding-left: 10px;\n  position: relative;\n}\n.main_content_div .card_div .content_div .title_lbl {\n  font-size: 16px;\n  font-weight: 600;\n  color: #b91d73;\n}\n.main_content_div .card_div .content_div .small_lbl {\n  font-size: 12px;\n  color: gray;\n  margin-top: 5px;\n  margin-bottom: 5px;\n}\n.main_content_div .card_div .content_div .abs_lbl {\n  position: absolute;\n  right: 0;\n  bottom: 0;\n  font-size: 12px;\n  color: #b91d73;\n}\nion-segment-button {\n  --indicator-color:linear-gradient(to right , #b91d73, #f953c6) ;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1YmplY3QxLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdURBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0FBQ0o7QUFDSTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FBQ1I7QUFFSTtFQUNHLFdBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQUFQO0FBR0k7RUFDRyxlQUFBO0VBQ0EsWUFBQTtBQURQO0FBS0E7RUFDSSxhQUFBO0FBRko7QUFJSTtFQUNJLGNBQUE7QUFGUjtBQUtJO0VBQ0ksYUFBQTtFQUNBLDBDQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFIUjtBQUlRO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxjQUFBO0FBRlo7QUFJUTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBRlo7QUFJUTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBRlo7QUFHWTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFEaEI7QUFJWTtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBRmhCO0FBSVk7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFGaEI7QUFXQTtFQUNJLCtEQUFBO0FBUkoiLCJmaWxlIjoic3ViamVjdDEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmdyYWRfYmFja3tcclxuICAgIHdpZHRoOjEwMCU7XHJcbiAgICBoZWlnaHQ6MTUwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQgLCAjYjkxZDczLCAjZjk1M2M2KTtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1MHB4O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5cclxuICAgIC5zdWJqZWN0e1xyXG4gICAgICAgIGNvbG9yOndoaXRlO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgICAgIGxlZnQ6MTZweDtcclxuICAgICAgICBib3R0b206MTZweDtcclxuICAgIH1cclxuXHJcbiAgICAuYnRuX2ZsZXh7XHJcbiAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgZGlzcGxheTogZmxleDsgXHJcbiAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgcGFkZGluZy10b3A6IDQwcHg7XHJcbiAgICB9XHJcblxyXG4gICAgaW9uLWljb257XHJcbiAgICAgICBmb250LXNpemU6IDIwcHg7IFxyXG4gICAgICAgY29sb3I6d2hpdGU7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5tYWluX2NvbnRlbnRfZGl2e1xyXG4gICAgcGFkZGluZzoxNnB4O1xyXG5cclxuICAgIGlvbi1sYWJlbHtcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIH1cclxuXHJcbiAgICAuY2FyZF9kaXZ7XHJcbiAgICAgICAgcGFkZGluZzoxMHB4O1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwwLDAsMC4yKTtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgcG9zaXRpb246cmVsYXRpdmU7XHJcbiAgICAgICAgLmRvd25sb2Fke1xyXG4gICAgICAgICAgICB3aWR0aDogMThweDtcclxuICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHJpZ2h0OiAxMHB4O1xyXG4gICAgICAgICAgICB0b3A6MTBweDtcclxuICAgICAgICAgICAgei1pbmRleDogOTk5OTk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5yb3VuZF9pbWFnZXtcclxuICAgICAgICAgICAgaGVpZ2h0OjUwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOjUwJTtcclxuICAgICAgICAgICAgbWluLXdpZHRoOiA1MHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAuY29udGVudF9kaXZ7XHJcbiAgICAgICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDoxMHB4O1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICAgIC50aXRsZV9sYmx7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6I2I5MWQ3MztcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLnNtYWxsX2xibHtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOmdyYXk7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLmFic19sYmx7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgIHJpZ2h0OiAwO1xyXG4gICAgICAgICAgICAgICAgYm90dG9tOiAwO1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6I2I5MWQ3M1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuXHJcblxyXG5pb24tc2VnbWVudC1idXR0b257XHJcbiAgICAtLWluZGljYXRvci1jb2xvcjpsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQgLCAjYjkxZDczLCAjZjk1M2M2KVxyXG59Il19 */");

/***/ }),

/***/ 885:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/subject/subject1/subject1.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <div class=\"grad_back\">\n    <div class=\"btn_flex\">\n      <div>\n        <ion-buttons slot=\"start\">\n          <ion-back-button defaultHref=\"/home1\" color=\"light\"></ion-back-button>\n        </ion-buttons>\n      </div>\n\n      <div>\n        <ion-button fill=\"clear\" size=\"small\">\n          <ion-icon name=\"search-outline\"></ion-icon>\n        </ion-button>\n\n        <ion-button fill=\"clear\" size=\"small\">\n          <ion-icon name=\"notifications-outline\"></ion-icon>\n        </ion-button>\n      </div>\n    </div>\n    <ion-label class=\"subject\">Select Chapter</ion-label>\n  </div>\n\n  <ion-segment value=\"Chapters\" mode=\"md\" (ionChange)=\"segmentChanged($event)\">\n    <ion-segment-button value=\"Chapters\">\n      <ion-label>Chapters</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"Tests\">\n      <ion-label>Tests</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n    <span *ngIf=\"segId == 'Chapters'\">\n      <div class=\"card_div\" *ngFor=\"let item of chapters\">\n        <img src=\"../../../../assets/download.png\" class=\"download\" />\n\n        <div class=\"round_image bg_image\" \n        [style.backgroundImage]=\"'url( ' + item.img+')'\">\n        </div>\n\n        <div class=\"content_div\">\n          <ion-label class=\"title_lbl\">{{item.name}}</ion-label>\n          <ion-label class=\"small_lbl\">{{item.name}}</ion-label>\n          <ion-progress-bar value=\"{{item.per/100}}\"></ion-progress-bar>\n          <ion-label class=\"small_lbl\">Download Notes Of This Chapter</ion-label>\n          <ion-label class=\"abs_lbl\">{{item.per}}</ion-label>\n        </div>\n      </div>\n    </span>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_subject_subject1_subject1_module_ts.js.map