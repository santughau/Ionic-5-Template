(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_home_home5_home5_module_ts"],{

/***/ 69053:
/*!**********************************************************!*\
  !*** ./src/app/pages/home/home5/home5-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home5PageRoutingModule": () => (/* binding */ Home5PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _home5_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home5.page */ 61131);




const routes = [
    {
        path: '',
        component: _home5_page__WEBPACK_IMPORTED_MODULE_0__.Home5Page
    }
];
let Home5PageRoutingModule = class Home5PageRoutingModule {
};
Home5PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Home5PageRoutingModule);



/***/ }),

/***/ 9688:
/*!**************************************************!*\
  !*** ./src/app/pages/home/home5/home5.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home5PageModule": () => (/* binding */ Home5PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _home5_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home5-routing.module */ 69053);
/* harmony import */ var _home5_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home5.page */ 61131);







let Home5PageModule = class Home5PageModule {
};
Home5PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home5_routing_module__WEBPACK_IMPORTED_MODULE_0__.Home5PageRoutingModule
        ],
        declarations: [_home5_page__WEBPACK_IMPORTED_MODULE_1__.Home5Page]
    })
], Home5PageModule);



/***/ }),

/***/ 61131:
/*!************************************************!*\
  !*** ./src/app/pages/home/home5/home5.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home5Page": () => (/* binding */ Home5Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_home5_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./home5.page.html */ 2645);
/* harmony import */ var _home5_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home5.page.scss */ 93697);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 29535);





let Home5Page = class Home5Page {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
        this.subjects = [
            {
                img: 'assets/english.png',
                name: 'English'
            },
            {
                img: 'assets/chemistry.png',
                name: 'Chemistry'
            },
            {
                img: 'assets/statistics.png',
                name: 'Statistics'
            },
            {
                img: 'assets/maths.png',
                name: 'Mathamatics'
            },
            {
                img: 'assets/physics.png',
                name: 'Physics'
            },
            {
                img: 'assets/social.png',
                name: 'Social Science'
            },
        ];
    }
    goToSubject() {
    }
};
Home5Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
Home5Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-home5',
        template: _raw_loader_home5_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_home5_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Home5Page);



/***/ }),

/***/ 93697:
/*!**************************************************!*\
  !*** ./src/app/pages/home/home5/home5.page.scss ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background:linear-gradient( to right, #f46b45 , #eea849);\n}\n\n.main_content_div {\n  width: 100%;\n}\n\n.main_content_div .menu_btn {\n  position: absolute;\n  top: 40px;\n  left: 10px;\n}\n\n.main_content_div ion-label {\n  display: block;\n  color: #f46b45;\n  text-align: center;\n}\n\n.main_content_div .user_div {\n  padding: 20px;\n  width: 100%;\n  height: 260px;\n  background: linear-gradient(to right, #f46b45, #eea849);\n  display: flex;\n  padding-top: 40px;\n  justify-content: space-between;\n}\n\n.main_content_div .user_div .first_div {\n  padding-top: 35px;\n}\n\n.main_content_div .user_div .first_div .welcome {\n  font-size: 18px;\n  color: white;\n  font-weight: 500;\n}\n\n.main_content_div .user_div .first_div .username {\n  font-size: 24px;\n  color: white;\n  font-weight: 600;\n}\n\n.main_content_div .user_div .user_back {\n  height: 100px;\n  width: 80px;\n  border: 3px solid white;\n  background-position: top;\n  background-size: cover;\n  background-repeat: no-repeat;\n  border-radius: 7px;\n}\n\n.main_content_div .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 75px;\n  border-top-left-radius: 75px;\n  margin-top: -90px;\n  padding: 20px;\n  padding-top: 30px;\n}\n\n.main_content_div .content_div .hello_lbl {\n  font-weight: 600;\n  font-size: 18px;\n  margin-bottom: 10px;\n  padding-left: 5px;\n  margin-top: 10px;\n}\n\n.main_content_div .content_div ion-grid {\n  padding: 0px;\n}\n\n.main_content_div .content_div .col_div {\n  background: linear-gradient(to right, #f46b45, #eea849);\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-top-left-radius: 50px;\n  border-bottom-right-radius: 50px;\n}\n\n.main_content_div .content_div .col_div img {\n  width: 70px;\n}\n\n.main_content_div .content_div .col_div ion-label {\n  color: white;\n  margin-top: 5px;\n}\n\n.animated {\n  animation-duration: 10s;\n  animation-fill-mode: both;\n}\n\n.bounceInUp {\n  animation-name: bounceInUp;\n}\n\n@keyframes bounceInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translateY(-30px);\n  }\n  80% {\n    -webkit-transform: translateY(10px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWU1LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDBEQUFBO0FBQ0o7O0FBRUE7RUFDSyxXQUFBO0FBQ0w7O0FBQ0k7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FBQ1I7O0FBRUk7RUFDSSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBQVI7O0FBR0k7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSx1REFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLDhCQUFBO0FBRFI7O0FBR1E7RUFDSSxpQkFBQTtBQURaOztBQUdZO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQURoQjs7QUFHWTtFQUNJLGVBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFEaEI7O0FBS1E7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLHVCQUFBO0VBQ0Esd0JBQUE7RUFDQSxzQkFBQTtFQUNBLDRCQUFBO0VBQ0Esa0JBQUE7QUFIWjs7QUFPSTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtBQUxSOztBQU9RO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBTFo7O0FBUVM7RUFDRyxZQUFBO0FBTlo7O0FBU1E7RUFDSyx1REFBQTtFQUNELGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSwwQ0FBQTtFQUNBLDRCQUFBO0VBQ0EsZ0NBQUE7QUFQWjs7QUFRWTtFQUNJLFdBQUE7QUFOaEI7O0FBU1k7RUFDSSxZQUFBO0VBQ0EsZUFBQTtBQVBoQjs7QUFnQkE7RUFFSSx1QkFBQTtFQUVBLHlCQUFBO0FBYko7O0FBbUNBO0VBRUksMEJBQUE7QUFoQko7O0FBbUJBO0VBQ0k7SUFDSSxVQUFBO0lBQ0EscUNBQUE7RUFoQk47RUFrQkU7SUFDSSxVQUFBO0lBQ0Esb0NBQUE7RUFoQk47RUFrQkU7SUFFSSxtQ0FBQTtFQWpCTjtFQW9CRTtJQUVJLGdDQUFBO0VBbkJOO0FBQ0YiLCJmaWxlIjoiaG9tZTUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAtLWJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCB0byByaWdodCwgI2Y0NmI0NSAsICNlZWE4NDkpO1xyXG59XHJcblxyXG4ubWFpbl9jb250ZW50X2RpdntcclxuICAgICB3aWR0aDogMTAwJTtcclxuICAgIFxyXG4gICAgLm1lbnVfYnRue1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB0b3A6IDQwcHg7XHJcbiAgICAgICAgbGVmdDogMTBweDtcclxuICAgIH1cclxuXHJcbiAgICBpb24tbGFiZWwge1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgIGNvbG9yOiNmNDZiNDU7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgfVxyXG5cclxuICAgIC51c2VyX2RpdntcclxuICAgICAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGhlaWdodDogMjYwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KCB0byByaWdodCwgI2Y0NmI0NSAsICNlZWE4NDkpO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgcGFkZGluZy10b3A6IDQwcHg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cclxuICAgICAgICAuZmlyc3RfZGl2e1xyXG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogMzVweDtcclxuXHJcbiAgICAgICAgICAgIC53ZWxjb21le1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAudXNlcm5hbWV7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAudXNlcl9iYWNre1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgICAgICAgICB3aWR0aDogODBweDtcclxuICAgICAgICAgICAgYm9yZGVyOiAzcHggc29saWQgd2hpdGU7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IHRvcDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogN3B4IDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLmNvbnRlbnRfZGl2e1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA3NXB4O1xyXG4gICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDc1cHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDotOTBweDtcclxuICAgICAgICBwYWRkaW5nOjIwcHg7XHJcbiAgICAgICAgcGFkZGluZy10b3A6MzBweDtcclxuXHJcbiAgICAgICAgLmhlbGxvX2xibHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDVweDtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICBpb24tZ3JpZHtcclxuICAgICAgICAgICAgcGFkZGluZzogMHB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmNvbF9kaXZ7XHJcbiAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoIHRvIHJpZ2h0LCAjZjQ2YjQ1ICwgI2VlYTg0OSk7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTUwcHg7XHJcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwwLDAsMC4yKTtcclxuICAgICAgICAgICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNTBweDtcclxuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDUwcHg7XHJcbiAgICAgICAgICAgIGltZ3tcclxuICAgICAgICAgICAgICAgIHdpZHRoOiA3MHB4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBcclxuXHJcbiAgICB9XHJcbn1cclxuXHJcbi5hbmltYXRlZHtcclxuICAgIC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOjEwcztcclxuICAgIGFuaW1hdGlvbi1kdXJhdGlvbiA6MTBzO1xyXG4gICAgLXdlYmtpdC1hbmltYXRpb24tZmlsbC1tb2RlOiBib3RoO1xyXG4gICAgYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcclxufVxyXG5cclxuQC13ZWJraXQta2V5ZnJhbWVzIGJvdW5jZUluVXB7XHJcbiAgICAwJXtcclxuICAgICAgICBvcGFjaXR5OjA7XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoMjAwMHB4KTtcclxuICAgIH1cclxuICAgIDYwJXtcclxuICAgICAgICBvcGFjaXR5OjE7XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoLTMwcHgpO1xyXG4gICAgfVxyXG4gICAgODAle1xyXG4gICAgICAgXHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoMTBweCk7XHJcbiAgICB9XHJcblxyXG4gICAgMTAwJXtcclxuICAgICAgXHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoMCk7XHJcbiAgICB9XHJcbn1cclxuLmJvdW5jZUluVXB7XHJcbiAgICAtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBib3VuY2VJblVwO1xyXG4gICAgYW5pbWF0aW9uLW5hbWU6IGJvdW5jZUluVXA7XHJcbn1cclxuXHJcbkBrZXlmcmFtZXMgYm91bmNlSW5VcHtcclxuICAgIDAle1xyXG4gICAgICAgIG9wYWNpdHk6MDtcclxuICAgICAgICAtd2Via2l0LXRyYW5zZm9ybSA6dHJhbnNsYXRlWSgyMDAwcHgpO1xyXG4gICAgfVxyXG4gICAgNjAle1xyXG4gICAgICAgIG9wYWNpdHk6MTtcclxuICAgICAgICAtd2Via2l0LXRyYW5zZm9ybSA6dHJhbnNsYXRlWSgtMzBweCk7XHJcbiAgICB9XHJcbiAgICA4MCV7XHJcbiAgICAgICBcclxuICAgICAgICAtd2Via2l0LXRyYW5zZm9ybSA6dHJhbnNsYXRlWSgxMHB4KTtcclxuICAgIH1cclxuXHJcbiAgICAxMDAle1xyXG4gICAgICBcclxuICAgICAgICAtd2Via2l0LXRyYW5zZm9ybSA6dHJhbnNsYXRlWSgwKTtcclxuICAgIH1cclxufVxyXG4iXX0= */");

/***/ }),

/***/ 2645:
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home5/home5.page.html ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"main_content_div\">\n\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n\n    <div class=\"user_div\">\n      <div class=\"first_div\">\n        <ion-label class=\"welcome\">Welcome</ion-label>\n        <ion-label class=\"username\">Yamini</ion-label>\n      </div>\n      <div class=\"user_back\" [style.backgroundImage]=\"'url(assets/11.jpg)'\"></div>\n    </div>\n\n    <div class=\"content_div animated bounceInUp\">\n      <ion-label class=\"hello_lbl\">Hello , Please Choose Your Subject</ion-label>\n\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"6\" (click)=\"goToSubject()\" *ngFor=\"let item of subjects \">\n            <div class=\"col_div\">\n              <img src=\"{{item.img}}\">\n              <ion-label>{{item.name}}</ion-label>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_home5_home5_module_ts.js.map