(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_home_home1_home1_module_ts"],{

/***/ 32112:
/*!**********************************************************!*\
  !*** ./src/app/pages/home/home1/home1-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home1PageRoutingModule": () => (/* binding */ Home1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _home1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home1.page */ 57047);




const routes = [
    {
        path: '',
        component: _home1_page__WEBPACK_IMPORTED_MODULE_0__.Home1Page
    }
];
let Home1PageRoutingModule = class Home1PageRoutingModule {
};
Home1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Home1PageRoutingModule);



/***/ }),

/***/ 20039:
/*!**************************************************!*\
  !*** ./src/app/pages/home/home1/home1.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home1PageModule": () => (/* binding */ Home1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _home1_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home1-routing.module */ 32112);
/* harmony import */ var _home1_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home1.page */ 57047);







let Home1PageModule = class Home1PageModule {
};
Home1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home1_routing_module__WEBPACK_IMPORTED_MODULE_0__.Home1PageRoutingModule
        ],
        declarations: [_home1_page__WEBPACK_IMPORTED_MODULE_1__.Home1Page]
    })
], Home1PageModule);



/***/ }),

/***/ 57047:
/*!************************************************!*\
  !*** ./src/app/pages/home/home1/home1.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home1Page": () => (/* binding */ Home1Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_home1_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./home1.page.html */ 71223);
/* harmony import */ var _home1_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home1.page.scss */ 14087);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 29535);





let Home1Page = class Home1Page {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
        this.subjects = [
            {
                img: 'assets/english.png',
                name: 'English'
            },
            {
                img: 'assets/chemistry.png',
                name: 'Chemistry'
            },
            {
                img: 'assets/statistics.png',
                name: 'Statistics'
            },
            {
                img: 'assets/maths.png',
                name: 'Mathamatics'
            },
            {
                img: 'assets/physics.png',
                name: 'Physics'
            },
            {
                img: 'assets/social.png',
                name: 'Social Science'
            },
        ];
    }
    goToSubject() {
    }
};
Home1Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
Home1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-home1',
        template: _raw_loader_home1_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_home1_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Home1Page);



/***/ }),

/***/ 14087:
/*!**************************************************!*\
  !*** ./src/app/pages/home/home1/home1.page.scss ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background:linear-gradient( to right , #b91d73, #f953c6);\n}\n\n.main_content_div {\n  width: 100%;\n}\n\n.main_content_div .menu_btn {\n  position: relative;\n  top: 40px;\n  left: 10px;\n}\n\n.main_content_div ion-label {\n  display: block;\n  color: #b91d73;\n  text-align: center;\n}\n\n.main_content_div .user_div {\n  padding: 20px;\n  width: 100%;\n  height: 260px;\n  background: linear-gradient(to right, #b91d73, #f953c6);\n  display: flex;\n  padding-top: 40px;\n  justify-content: space-between;\n}\n\n.main_content_div .user_div .first_div {\n  padding-top: 35px;\n}\n\n.main_content_div .user_div .first_div .welcome {\n  font-size: 18px;\n  color: white;\n  font-weight: 500;\n}\n\n.main_content_div .user_div .first_div .username {\n  font-size: 24px;\n  color: white;\n  font-weight: 600;\n}\n\n.main_content_div .user_div .user_back {\n  height: 100px;\n  width: 80px;\n  border: 3px solid white;\n  background-position: top;\n  background-size: cover;\n  background-repeat: no-repeat;\n  border-radius: 7px;\n}\n\n.main_content_div .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 75px;\n  margin-top: -90px;\n  padding-top: 30px;\n  padding: 20px;\n}\n\n.main_content_div .content_div .hello_lbl {\n  font-weight: 600;\n  font-size: 18px;\n  margin-bottom: 10px;\n  padding-left: 5px;\n  margin-top: 10px;\n}\n\n.main_content_div .content_div ion-grid {\n  padding: 0px;\n}\n\n.main_content_div .content_div .col_div {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 5px;\n}\n\n.main_content_div .content_div .col_div img {\n  width: 70px;\n}\n\n.main_content_div .content_div .col_div ion-label {\n  color: var(--ion-color-primary);\n  margin-top: 5px;\n}\n\n.animated {\n  animation-duration: 10s;\n  animation-fill-mode: both;\n}\n\n.bounceInUp {\n  animation-name: bounceInUp;\n}\n\n@keyframes bounceInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translateY(-30px);\n  }\n  80% {\n    -webkit-transform: translateY(10px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUxLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDBEQUFBO0FBQ0o7O0FBRUE7RUFDSSxXQUFBO0FBQ0o7O0FBQ0k7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FBQ1I7O0FBRUk7RUFDSSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBQVI7O0FBR0k7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSx1REFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLDhCQUFBO0FBRFI7O0FBR1E7RUFDSSxpQkFBQTtBQURaOztBQUVZO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUFoQjs7QUFHWTtFQUNJLGVBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFEaEI7O0FBS1E7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLHVCQUFBO0VBQ0Esd0JBQUE7RUFDQSxzQkFBQTtFQUNBLDRCQUFBO0VBQ0Esa0JBQUE7QUFIWjs7QUFPSTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7QUFMUjs7QUFPUTtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUxaOztBQVFRO0VBQ0ksWUFBQTtBQU5aOztBQVNRO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7QUFQWjs7QUFTWTtFQUNJLFdBQUE7QUFQaEI7O0FBVVk7RUFDSSwrQkFBQTtFQUNBLGVBQUE7QUFSaEI7O0FBZUE7RUFFSSx1QkFBQTtFQUVBLHlCQUFBO0FBWko7O0FBa0NBO0VBRUksMEJBQUE7QUFmSjs7QUFrQkE7RUFDSTtJQUNJLFVBQUE7SUFDQSxxQ0FBQTtFQWZOO0VBaUJFO0lBQ0ksVUFBQTtJQUNBLG9DQUFBO0VBZk47RUFpQkU7SUFFSSxtQ0FBQTtFQWhCTjtFQW1CRTtJQUVJLGdDQUFBO0VBbEJOO0FBQ0YiLCJmaWxlIjoiaG9tZTEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAtLWJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCB0byByaWdodCAsICNiOTFkNzMsICNmOTUzYzYpO1xyXG59XHJcblxyXG4ubWFpbl9jb250ZW50X2RpdntcclxuICAgIHdpZHRoOiAxMDAlO1xyXG5cclxuICAgIC5tZW51X2J0bntcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOjQwcHg7XHJcbiAgICAgICAgbGVmdDoxMHB4O1xyXG4gICAgfVxyXG5cclxuICAgIGlvbi1sYWJlbHtcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICBjb2xvcjojYjkxZDczO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIH1cclxuXHJcbiAgICAudXNlcl9kaXZ7XHJcbiAgICAgICAgcGFkZGluZzoyMHB4O1xyXG4gICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgaGVpZ2h0OjI2MHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCB0byByaWdodCAsICNiOTFkNzMsICNmOTUzYzYpO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgcGFkZGluZy10b3A6IDQwcHg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cclxuICAgICAgICAuZmlyc3RfZGl2e1xyXG4gICAgICAgICAgICBwYWRkaW5nLXRvcDozNXB4O1xyXG4gICAgICAgICAgICAud2VsY29tZXtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC51c2VybmFtZXtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOndoaXRlO1xyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnVzZXJfYmFja3tcclxuICAgICAgICAgICAgaGVpZ2h0OjEwMHB4O1xyXG4gICAgICAgICAgICB3aWR0aDo4MHB4O1xyXG4gICAgICAgICAgICBib3JkZXI6M3B4IHNvbGlkIHdoaXRlO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiB0b3A7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDdweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLmNvbnRlbnRfZGl2e1xyXG4gICAgICAgIGJhY2tncm91bmQ6d2hpdGU7XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNzVweDtcclxuICAgICAgICBtYXJnaW4tdG9wOi05MHB4O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOjMwcHg7XHJcbiAgICAgICAgcGFkZGluZzoyMHB4O1xyXG5cclxuICAgICAgICAuaGVsbG9fbGJse1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICBmb250LXNpemU6MThweDtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbToxMHB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDVweDtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlvbi1ncmlke1xyXG4gICAgICAgICAgICBwYWRkaW5nOjBweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jb2xfZGl2e1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBoZWlnaHQ6MTUwcHg7XHJcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwwLDAsMC4yKTtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG5cclxuICAgICAgICAgICAgaW1ne1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6NzBweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICAgICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDo1cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG59XHJcblxyXG4uYW5pbWF0ZWR7XHJcbiAgICAtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjoxMHM7XHJcbiAgICBhbmltYXRpb24tZHVyYXRpb24gOjEwcztcclxuICAgIC13ZWJraXQtYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcclxuICAgIGFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XHJcbn1cclxuXHJcbkAtd2Via2l0LWtleWZyYW1lcyBib3VuY2VJblVwe1xyXG4gICAgMCV7XHJcbiAgICAgICAgb3BhY2l0eTowO1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKDIwMDBweCk7XHJcbiAgICB9XHJcbiAgICA2MCV7XHJcbiAgICAgICAgb3BhY2l0eToxO1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKC0zMHB4KTtcclxuICAgIH1cclxuICAgIDgwJXtcclxuICAgICAgIFxyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKDEwcHgpO1xyXG4gICAgfVxyXG5cclxuICAgIDEwMCV7XHJcbiAgICAgIFxyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKDApO1xyXG4gICAgfVxyXG59XHJcbi5ib3VuY2VJblVwe1xyXG4gICAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogYm91bmNlSW5VcDtcclxuICAgIGFuaW1hdGlvbi1uYW1lOiBib3VuY2VJblVwO1xyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIGJvdW5jZUluVXB7XHJcbiAgICAwJXtcclxuICAgICAgICBvcGFjaXR5OjA7XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoMjAwMHB4KTtcclxuICAgIH1cclxuICAgIDYwJXtcclxuICAgICAgICBvcGFjaXR5OjE7XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoLTMwcHgpO1xyXG4gICAgfVxyXG4gICAgODAle1xyXG4gICAgICAgXHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoMTBweCk7XHJcbiAgICB9XHJcblxyXG4gICAgMTAwJXtcclxuICAgICAgXHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoMCk7XHJcbiAgICB9XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 71223:
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home1/home1.page.html ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n    <div class=\"main_content_div\">\n\n      <ion-buttons slot=\"start\" class=\"menu_btn\">\n          <ion-menu-button color=\"light\"></ion-menu-button>\n      </ion-buttons>\n\n      <div class=\"user_div\">\n          <div class=\"first_div\">\n            <ion-label class=\"welcome\">Welcome</ion-label>\n            <ion-label class=\"username\">Yamini</ion-label>\n          </div>\n          <div class=\"user_back\" [style.backgroundImage]=\"'url(assets/11.jpg)'\"></div>\n      </div>\n\n      <div class=\"content_div animated bounceInUp\">\n        <ion-label class=\"hello_lbl\">Hello , Please Choose Your Subject</ion-label>\n\n        <ion-grid fixed>\n          <ion-row>\n            <ion-col size=\"6\" (click)=\"goToSubject()\" *ngFor=\"let item of subjects \">\n              <div class=\"col_div\">\n                <img src=\"{{item.img}}\" >\n                <ion-label>{{item.name}}</ion-label>\n              </div>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </div>\n    </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_home1_home1_module_ts.js.map