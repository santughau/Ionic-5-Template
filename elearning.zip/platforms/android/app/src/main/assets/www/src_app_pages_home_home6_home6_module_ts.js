(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_home_home6_home6_module_ts"],{

/***/ 40906:
/*!**********************************************************!*\
  !*** ./src/app/pages/home/home6/home6-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home6PageRoutingModule": () => (/* binding */ Home6PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _home6_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home6.page */ 82573);




const routes = [
    {
        path: '',
        component: _home6_page__WEBPACK_IMPORTED_MODULE_0__.Home6Page
    }
];
let Home6PageRoutingModule = class Home6PageRoutingModule {
};
Home6PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Home6PageRoutingModule);



/***/ }),

/***/ 6390:
/*!**************************************************!*\
  !*** ./src/app/pages/home/home6/home6.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home6PageModule": () => (/* binding */ Home6PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _home6_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home6-routing.module */ 40906);
/* harmony import */ var _home6_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home6.page */ 82573);







let Home6PageModule = class Home6PageModule {
};
Home6PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home6_routing_module__WEBPACK_IMPORTED_MODULE_0__.Home6PageRoutingModule
        ],
        declarations: [_home6_page__WEBPACK_IMPORTED_MODULE_1__.Home6Page]
    })
], Home6PageModule);



/***/ }),

/***/ 82573:
/*!************************************************!*\
  !*** ./src/app/pages/home/home6/home6.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Home6Page": () => (/* binding */ Home6Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_home6_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./home6.page.html */ 73545);
/* harmony import */ var _home6_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home6.page.scss */ 94665);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let Home6Page = class Home6Page {
    constructor() { }
    ngOnInit() {
        this.subjects = [
            {
                img: 'assets/english.png',
                name: 'English'
            },
            {
                img: 'assets/chemistry.png',
                name: 'Chemistry'
            },
            {
                img: 'assets/statistics.png',
                name: 'Statistics'
            },
            {
                img: 'assets/maths.png',
                name: 'Mathamatics'
            },
            {
                img: 'assets/physics.png',
                name: 'Physics'
            },
            {
                img: 'assets/social.png',
                name: 'Social Science'
            },
        ];
    }
    goToSubject() {
    }
};
Home6Page.ctorParameters = () => [];
Home6Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-home6',
        template: _raw_loader_home6_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_home6_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Home6Page);



/***/ }),

/***/ 94665:
/*!**************************************************!*\
  !*** ./src/app/pages/home/home6/home6.page.scss ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background:linear-gradient( to right, #2F0743, #41295a);\n}\n\n.main_content_div {\n  width: 100%;\n}\n\n.main_content_div .menu_btn {\n  position: absolute;\n  top: 40px;\n  left: 10px;\n}\n\n.main_content_div ion-label {\n  display: block;\n  color: #2F0743;\n  text-align: center;\n}\n\n.main_content_div .user_div {\n  padding: 20px;\n  width: 100%;\n  height: 260px;\n  background: linear-gradient(to right, #2F0743, #41295a);\n  display: flex;\n  padding-top: 40px;\n  justify-content: space-between;\n}\n\n.main_content_div .user_div .first_div {\n  padding-top: 35px;\n}\n\n.main_content_div .user_div .first_div .welcome {\n  font-size: 18px;\n  color: white;\n  font-weight: 500;\n}\n\n.main_content_div .user_div .first_div .username {\n  font-size: 24px;\n  color: white;\n  font-weight: 600;\n}\n\n.main_content_div .user_div .user_back {\n  height: 100px;\n  width: 100px;\n  border: 3px solid white;\n  background-position: top;\n  background-size: cover;\n  background-repeat: no-repeat;\n  border-radius: 50%;\n}\n\n.main_content_div .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 75px;\n  border-top-left-radius: 75px;\n  margin-top: -90px;\n  padding: 20px;\n  padding-top: 30px;\n}\n\n.main_content_div .content_div .hello_lbl {\n  font-weight: 600;\n  font-size: 18px;\n  margin-bottom: 10px;\n  padding-left: 5px;\n  margin-top: 10px;\n}\n\n.main_content_div .content_div ion-grid {\n  padding: 0px;\n}\n\n.main_content_div .content_div .col_div {\n  background: linear-gradient(to right, #2F0743, #41295a);\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-top-left-radius: 50px;\n  border-bottom-right-radius: 50px;\n}\n\n.main_content_div .content_div .col_div img {\n  width: 70px;\n}\n\n.main_content_div .content_div .col_div ion-label {\n  color: white;\n  margin-top: 5px;\n}\n\n.animated {\n  animation-duration: 10s;\n  animation-fill-mode: both;\n}\n\n.bounceInUp {\n  animation-name: bounceInUp;\n}\n\n@keyframes bounceInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translateY(-30px);\n  }\n  80% {\n    -webkit-transform: translateY(10px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWU2LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHlEQUFBO0FBQ0o7O0FBRUE7RUFDSyxXQUFBO0FBQ0w7O0FBQ0k7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FBQ1I7O0FBRUk7RUFDSSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBQVI7O0FBR0k7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSx1REFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLDhCQUFBO0FBRFI7O0FBR1E7RUFDSSxpQkFBQTtBQURaOztBQUdZO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQURoQjs7QUFHWTtFQUNJLGVBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFEaEI7O0FBS1E7RUFDSSxhQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0Esd0JBQUE7RUFDQSxzQkFBQTtFQUNBLDRCQUFBO0VBQ0Esa0JBQUE7QUFIWjs7QUFPSTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtBQUxSOztBQU9RO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBTFo7O0FBUVM7RUFDRyxZQUFBO0FBTlo7O0FBU1E7RUFDSyx1REFBQTtFQUNELGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSwwQ0FBQTtFQUNBLDRCQUFBO0VBQ0EsZ0NBQUE7QUFQWjs7QUFRWTtFQUNJLFdBQUE7QUFOaEI7O0FBU1k7RUFDSSxZQUFBO0VBQ0EsZUFBQTtBQVBoQjs7QUFnQkE7RUFFSSx1QkFBQTtFQUVBLHlCQUFBO0FBYko7O0FBbUNBO0VBRUksMEJBQUE7QUFoQko7O0FBbUJBO0VBQ0k7SUFDSSxVQUFBO0lBQ0EscUNBQUE7RUFoQk47RUFrQkU7SUFDSSxVQUFBO0lBQ0Esb0NBQUE7RUFoQk47RUFrQkU7SUFFSSxtQ0FBQTtFQWpCTjtFQW9CRTtJQUVJLGdDQUFBO0VBbkJOO0FBQ0YiLCJmaWxlIjoiaG9tZTYucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAtLWJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCB0byByaWdodCwgIzJGMDc0MywgIzQxMjk1YSk7XHJcbn1cclxuXHJcbi5tYWluX2NvbnRlbnRfZGl2e1xyXG4gICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgXHJcbiAgICAubWVudV9idG57XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIHRvcDogNDBweDtcclxuICAgICAgICBsZWZ0OiAxMHB4O1xyXG4gICAgfVxyXG5cclxuICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgY29sb3I6IzJGMDc0MztcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB9XHJcblxyXG4gICAgLnVzZXJfZGl2e1xyXG4gICAgICAgIHBhZGRpbmc6IDIwcHg7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgaGVpZ2h0OiAyNjBweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoIHRvIHJpZ2h0LCAjMkYwNzQzLCAjNDEyOTVhKTtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiA0MHB4O1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHJcbiAgICAgICAgLmZpcnN0X2RpdntcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6IDM1cHg7XHJcblxyXG4gICAgICAgICAgICAud2VsY29tZXtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLnVzZXJuYW1le1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnVzZXJfYmFja3tcclxuICAgICAgICAgICAgaGVpZ2h0OiAxMDBweDtcclxuICAgICAgICAgICAgd2lkdGg6IDEwMHB4O1xyXG4gICAgICAgICAgICBib3JkZXI6IDNweCBzb2xpZCB3aGl0ZTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogdG9wO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCUgO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuY29udGVudF9kaXZ7XHJcbiAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDc1cHg7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNzVweDtcclxuICAgICAgICBtYXJnaW4tdG9wOi05MHB4O1xyXG4gICAgICAgIHBhZGRpbmc6MjBweDtcclxuICAgICAgICBwYWRkaW5nLXRvcDozMHB4O1xyXG5cclxuICAgICAgICAuaGVsbG9fbGJse1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogNXB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgIGlvbi1ncmlke1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY29sX2RpdntcclxuICAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCggdG8gcmlnaHQsICMyRjA3NDMsICM0MTI5NWEpO1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDE1MHB4O1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsMCwwLDAuMik7XHJcbiAgICAgICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDUwcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1MHB4O1xyXG4gICAgICAgICAgICBpbWd7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogNzBweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgXHJcblxyXG4gICAgfVxyXG59XHJcblxyXG4uYW5pbWF0ZWR7XHJcbiAgICAtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjoxMHM7XHJcbiAgICBhbmltYXRpb24tZHVyYXRpb24gOjEwcztcclxuICAgIC13ZWJraXQtYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcclxuICAgIGFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XHJcbn1cclxuXHJcbkAtd2Via2l0LWtleWZyYW1lcyBib3VuY2VJblVwe1xyXG4gICAgMCV7XHJcbiAgICAgICAgb3BhY2l0eTowO1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKDIwMDBweCk7XHJcbiAgICB9XHJcbiAgICA2MCV7XHJcbiAgICAgICAgb3BhY2l0eToxO1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKC0zMHB4KTtcclxuICAgIH1cclxuICAgIDgwJXtcclxuICAgICAgIFxyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKDEwcHgpO1xyXG4gICAgfVxyXG5cclxuICAgIDEwMCV7XHJcbiAgICAgIFxyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDp0cmFuc2xhdGVZKDApO1xyXG4gICAgfVxyXG59XHJcbi5ib3VuY2VJblVwe1xyXG4gICAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogYm91bmNlSW5VcDtcclxuICAgIGFuaW1hdGlvbi1uYW1lOiBib3VuY2VJblVwO1xyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIGJvdW5jZUluVXB7XHJcbiAgICAwJXtcclxuICAgICAgICBvcGFjaXR5OjA7XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoMjAwMHB4KTtcclxuICAgIH1cclxuICAgIDYwJXtcclxuICAgICAgICBvcGFjaXR5OjE7XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoLTMwcHgpO1xyXG4gICAgfVxyXG4gICAgODAle1xyXG4gICAgICAgXHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoMTBweCk7XHJcbiAgICB9XHJcblxyXG4gICAgMTAwJXtcclxuICAgICAgXHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm0gOnRyYW5zbGF0ZVkoMCk7XHJcbiAgICB9XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 73545:
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home6/home6.page.html ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"main_content_div\">\n\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n\n    <div class=\"user_div\">\n      <div class=\"first_div\">\n        <ion-label class=\"welcome\">Welcome</ion-label>\n        <ion-label class=\"username\">Yamini</ion-label>\n      </div>\n      <div class=\"user_back\" [style.backgroundImage]=\"'url(assets/11.jpg)'\"></div>\n    </div>\n\n    <div class=\"content_div animated bounceInUp\">\n      <ion-label class=\"hello_lbl\">Hello , Please Choose Your Subject</ion-label>\n\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"6\" (click)=\"goToSubject()\" *ngFor=\"let item of subjects \">\n            <div class=\"col_div\">\n              <img src=\"{{item.img}}\">\n              <ion-label>{{item.name}}</ion-label>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_home6_home6_module_ts.js.map