(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_list_list6_list6_module_ts"],{

/***/ 18400:
/*!**********************************************************!*\
  !*** ./src/app/pages/list/list6/list6-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "List6PageRoutingModule": () => (/* binding */ List6PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _list6_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list6.page */ 82901);




const routes = [
    {
        path: '',
        component: _list6_page__WEBPACK_IMPORTED_MODULE_0__.List6Page
    }
];
let List6PageRoutingModule = class List6PageRoutingModule {
};
List6PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], List6PageRoutingModule);



/***/ }),

/***/ 79577:
/*!**************************************************!*\
  !*** ./src/app/pages/list/list6/list6.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "List6PageModule": () => (/* binding */ List6PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _list6_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list6-routing.module */ 18400);
/* harmony import */ var _list6_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list6.page */ 82901);







let List6PageModule = class List6PageModule {
};
List6PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _list6_routing_module__WEBPACK_IMPORTED_MODULE_0__.List6PageRoutingModule
        ],
        declarations: [_list6_page__WEBPACK_IMPORTED_MODULE_1__.List6Page]
    })
], List6PageModule);



/***/ }),

/***/ 82901:
/*!************************************************!*\
  !*** ./src/app/pages/list/list6/list6.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "List6Page": () => (/* binding */ List6Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_list6_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./list6.page.html */ 64649);
/* harmony import */ var _list6_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list6.page.scss */ 55372);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);




let List6Page = class List6Page {
    constructor() {
        this.segId = 'Tests';
    }
    ngOnInit() {
        this.chapters = [
            {
                img: 'assets/light.jpg',
                name: 'Theory of Light',
                per: 90
            },
            {
                img: 'assets/water.jpg',
                name: 'Theory of Water',
                per: 40
            },
            {
                img: 'assets/motion.jpg',
                name: 'Theory of Motion',
                per: 50
            },
            {
                img: 'assets/sound.jpg',
                name: 'Theory of Sound',
                per: 65
            },
            {
                img: 'assets/sky.jpg',
                name: 'Theory of Sky',
                per: 75
            },
            {
                img: 'assets/energy.jpg',
                name: 'Theory of Energy',
                per: 45
            },
        ];
    }
    segmentChanged(val) {
        this.segId = val.target.value;
    }
};
List6Page.ctorParameters = () => [];
List6Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-list6',
        template: _raw_loader_list6_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_list6_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], List6Page);



/***/ }),

/***/ 55372:
/*!**************************************************!*\
  !*** ./src/app/pages/list/list6/list6.page.scss ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".grad_back {\n  width: 100%;\n  height: 150px;\n  background: linear-gradient(to right, #2F0743, #41295a);\n  border-bottom-right-radius: 50px;\n  border-bottom-left-radius: 50px;\n  position: relative;\n}\n.grad_back .subject {\n  color: white;\n  font-weight: 600;\n  font-size: 24px;\n  position: absolute;\n  left: 140px;\n  bottom: 16px;\n}\n.grad_back .btn_flex {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  height: 50px;\n  align-items: center;\n  padding-top: 40px;\n}\n.grad_back ion-icon {\n  font-size: 20px;\n  color: white;\n}\n.main_content_div {\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .card_div {\n  padding: 10px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 10px;\n  margin-bottom: 15px;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  position: relative;\n}\n.main_content_div .card_div .round_div {\n  height: 50px;\n  width: 50px;\n  border-radius: 50px;\n  min-width: 50px;\n  background: linear-gradient(to right, #2F0743, #41295a);\n  position: relative;\n}\n.main_content_div .card_div .round_div ion-icon {\n  position: absolute;\n  color: white;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 30px;\n}\n.main_content_div .card_div .content_div {\n  width: 100%;\n  padding-left: 10px;\n  position: relative;\n}\n.main_content_div .card_div .content_div .title_lbl {\n  font-size: 16px;\n  font-weight: 600;\n  color: #2F0743;\n}\n.main_content_div .card_div .content_div .small_lbl {\n  font-size: 12px;\n  color: gray;\n  margin-top: 5px;\n  margin-bottom: 5px;\n}\nion-segment-button {\n  --indicator-color:linear-gradient(to right, #2F0743, #41295a);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpc3Q2LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdURBQUE7RUFDQSxnQ0FBQTtFQUNBLCtCQUFBO0VBQ0Esa0JBQUE7QUFDSjtBQUNJO0VBQ0ksWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFDUjtBQUVJO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FBQVI7QUFHSTtFQUNJLGVBQUE7RUFDQSxZQUFBO0FBRFI7QUFLQTtFQUNJLGFBQUE7QUFGSjtBQUlJO0VBQ0ksY0FBQTtBQUZSO0FBSUk7RUFDSSxhQUFBO0VBQ0EsMENBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUZSO0FBR1E7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLHVEQUFBO0VBQ0Esa0JBQUE7QUFEWjtBQUVZO0VBQ0ksa0JBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7RUFDQSxnQ0FBQTtFQUNBLGVBQUE7QUFBaEI7QUFJUTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBRlo7QUFHWTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFEaEI7QUFHWTtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBRGhCO0FBUUE7RUFDSSw2REFBQTtBQUxKIiwiZmlsZSI6Imxpc3Q2LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ncmFkX2JhY2t7XHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgaGVpZ2h0OjE1MHB4O1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjMkYwNzQzLCAjNDEyOTVhKTtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNTBweDtcclxuICAgIHBvc2l0aW9uOnJlbGF0aXZlO1xyXG5cclxuICAgIC5zdWJqZWN0e1xyXG4gICAgICAgIGNvbG9yOndoaXRlO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICBsZWZ0OjE0MHB4O1xyXG4gICAgICAgIGJvdHRvbToxNnB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5idG5fZmxleHtcclxuICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIGhlaWdodDo1MHB4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgcGFkZGluZy10b3A6NDBweDtcclxuICAgIH1cclxuXHJcbiAgICBpb24taWNvbntcclxuICAgICAgICBmb250LXNpemU6MjBweDtcclxuICAgICAgICBjb2xvcjp3aGl0ZTtcclxuICAgIH1cclxufVxyXG5cclxuLm1haW5fY29udGVudF9kaXZ7XHJcbiAgICBwYWRkaW5nOjE2cHg7XHJcblxyXG4gICAgaW9uLWxhYmVse1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgfVxyXG4gICAgLmNhcmRfZGl2e1xyXG4gICAgICAgIHBhZGRpbmc6MTBweDtcclxuICAgICAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsMCwwLDAuMik7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czoxMHB4O1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjpyb3c7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgLnJvdW5kX2RpdntcclxuICAgICAgICAgICAgaGVpZ2h0OjUwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOjUwcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6NTBweDtcclxuICAgICAgICAgICAgbWluLXdpZHRoOiA1MHB4O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoIHRvIHJpZ2h0LCAjMkYwNzQzLCAjNDEyOTVhKTtcclxuICAgICAgICAgICAgcG9zaXRpb246cmVsYXRpdmU7XHJcbiAgICAgICAgICAgIGlvbi1pY29ue1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjp3aGl0ZTtcclxuICAgICAgICAgICAgICAgIGxlZnQ6NTAlO1xyXG4gICAgICAgICAgICAgICAgdG9wOjUwJTtcclxuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOjMwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jb250ZW50X2RpdntcclxuICAgICAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICAgIC50aXRsZV9sYmx7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IzJGMDc0MztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuc21hbGxfbGJse1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6Z3JheTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6NXB4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuaW9uLXNlZ21lbnQtYnV0dG9ue1xyXG4gICAgLS1pbmRpY2F0b3ItY29sb3I6bGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjMkYwNzQzLCAjNDEyOTVhKTtcclxuICAgIFxyXG59Il19 */");

/***/ }),

/***/ 64649:
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/list/list6/list6.page.html ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <div class=\"grad_back\">\n    <div class=\"btn_flex\">\n      <div>\n        <ion-buttons slot=\"start\">\n          <ion-back-button mode=\"md\" defaultHref=\"/home1\" color=\"light\"></ion-back-button>\n        </ion-buttons>\n      </div>\n\n      <div>\n        <ion-button fill=\"serach\" size=\"small\">\n          <ion-icon name=\"search-outline\"></ion-icon>\n        </ion-button>\n\n        <ion-button fill=\"serach\" size=\"small\">\n          <ion-icon name=\"notifications-outline\"></ion-icon>\n        </ion-button>\n      </div>\n    </div>\n\n    <ion-label class=\"subject\">Select Chapter</ion-label>\n  </div>\n\n  <ion-segment value=\"Tests\" mode=\"md\" (ionChange)=\"segmentChanged($event)\">\n    <ion-segment-button value=\"Chapters\">\n      <ion-label>Chapters</ion-label>\n    </ion-segment-button>\n\n    <ion-segment-button value=\"Tests\">\n      <ion-label>Tests</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n    <span *ngIf=\"segId == 'Chapters'\"></span>\n    <span *ngIf=\"segId == 'Tests'\">\n      <div class=\"card_div\" *ngFor=\"let item of chapters\">\n        <div class=\"round_div\">\n          <ion-icon name=\"checkmark-circle-outline\"></ion-icon>\n        </div>\n\n        <div class=\"content_div\">\n          <ion-label class=\"title_lbl\">{{item.name}}</ion-label>\n          <ion-label class=\"small_lbl\">Solve All Questions</ion-label>\n        </div>\n      </div>\n    </span>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_list_list6_list6_module_ts.js.map