(self["webpackChunkelearning"] = self["webpackChunkelearning"] || []).push([["src_app_pages_next_next1_next1_module_ts"],{

/***/ 18706:
/*!**********************************************************!*\
  !*** ./src/app/pages/next/next1/next1-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Next1PageRoutingModule": () => (/* binding */ Next1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _next1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./next1.page */ 28828);




const routes = [
    {
        path: '',
        component: _next1_page__WEBPACK_IMPORTED_MODULE_0__.Next1Page
    }
];
let Next1PageRoutingModule = class Next1PageRoutingModule {
};
Next1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Next1PageRoutingModule);



/***/ }),

/***/ 97311:
/*!**************************************************!*\
  !*** ./src/app/pages/next/next1/next1.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Next1PageModule": () => (/* binding */ Next1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _next1_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./next1-routing.module */ 18706);
/* harmony import */ var _next1_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./next1.page */ 28828);







let Next1PageModule = class Next1PageModule {
};
Next1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _next1_routing_module__WEBPACK_IMPORTED_MODULE_0__.Next1PageRoutingModule
        ],
        declarations: [_next1_page__WEBPACK_IMPORTED_MODULE_1__.Next1Page]
    })
], Next1PageModule);



/***/ }),

/***/ 28828:
/*!************************************************!*\
  !*** ./src/app/pages/next/next1/next1.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Next1Page": () => (/* binding */ Next1Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_next1_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./next1.page.html */ 69380);
/* harmony import */ var _next1_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./next1.page.scss */ 83476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 29535);





let Next1Page = class Next1Page {
    constructor(_router) {
        this._router = _router;
        this.slideOpts = {
            slidesPerView: 1.5
        };
    }
    ngOnInit() {
        this.students = [
            {
                img: 'assets/1.jpg',
                name: 'Miss Priyanka'
            },
            {
                img: 'assets/2.jpg',
                name: 'Miss Yamini'
            },
            {
                img: 'assets/4.jpg',
                name: 'Miss Laxmi'
            },
            {
                img: 'assets/6.jpg',
                name: 'Miss Piyusha'
            },
            {
                img: 'assets/8.jpg',
                name: 'Miss Swara'
            }
        ];
    }
    goBack() {
        this._router.navigate(['/home1']);
    }
};
Next1Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
Next1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-next1',
        template: _raw_loader_next1_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_next1_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Next1Page);



/***/ }),

/***/ 83476:
/*!**************************************************!*\
  !*** ./src/app/pages/next/next1/next1.page.scss ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".main_content_div {\n  width: 100%;\n}\n.main_content_div .back_div {\n  width: 100%;\n  height: 350px;\n  background: linear-gradient(to right, #b91d73, #f953c6);\n  border-bottom-right-radius: 50%;\n  position: relative;\n}\n.main_content_div .back_div .back_btn {\n  font-size: 30px;\n  left: 16px;\n  top: 40px;\n  position: absolute;\n}\n.main_content_div .back_div .white_div {\n  height: 130px;\n  width: 130px;\n  background: white;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .back_div img {\n  width: 70px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .bottom_div {\n  padding: 20px;\n  padding-top: 100px;\n}\n.main_content_div .bottom_div .slide_div {\n  display: flex;\n  align-items: center;\n  text-align: left;\n}\n.main_content_div .bottom_div .slide_div .user_back {\n  height: 70px;\n  width: 70px;\n  min-width: 70px;\n  border-radius: 100%;\n  background-position: top;\n  z-index: 999;\n}\n.main_content_div .bottom_div .slide_div .bg_image {\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n.main_content_div .bottom_div .slide_div .content_div {\n  margin-left: -20px;\n  padding-left: 25px;\n  padding-right: 25px;\n  height: 50px;\n  background: #b91d73;\n  color: white;\n  border-top-right-radius: 25px;\n  border-bottom-right-radius: 25px;\n  z-index: 0;\n  display: flex;\n  align-items: center;\n}\n.main_content_div .bottom_div .slide_div .content_div ion-label {\n  display: block;\n  font-size: 14px;\n}\n.main_content_div .bottom_div .btn_div {\n  margin-top: 50px;\n  text-align: center;\n}\n.main_content_div .bottom_div .btn_div ion-button {\n  color: #b91d73;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5leHQxLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJQTtFQUNJLFdBQUE7QUFISjtBQUlJO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSx1REFBQTtFQUNBLCtCQUFBO0VBQ0Esa0JBQUE7QUFGUjtBQUlRO0VBQ0ksZUFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7QUFGWjtBQUtRO0VBQ0ksYUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7RUFDQSxnQ0FBQTtBQUhaO0FBTVE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0FBSlo7QUFRSTtFQUNJLGFBQUE7RUFDQSxrQkFBQTtBQU5SO0FBT1E7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQUxaO0FBT1k7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLHdCQUFBO0VBQ0EsWUFBQTtBQUxoQjtBQVFZO0VBQ0ksMkJBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0FBTmhCO0FBU1k7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7RUFDQSxnQ0FBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFQaEI7QUFRZ0I7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQU5wQjtBQVdRO0VBQ0ksZ0JBQUE7RUFDQSxrQkFBQTtBQVRaO0FBVVk7RUFDSSxjQUFBO0FBUmhCIiwiZmlsZSI6Im5leHQxLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG5cclxufVxyXG5cclxuLm1haW5fY29udGVudF9kaXZ7XHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgLmJhY2tfZGl2e1xyXG4gICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgaGVpZ2h0OiAzNTBweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQgLCAjYjkxZDczICwgI2Y5NTNjNik7XHJcbiAgICAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDUwJTtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgICAgIC5iYWNrX2J0bntcclxuICAgICAgICAgICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgICAgICAgICBsZWZ0OjE2cHg7XHJcbiAgICAgICAgICAgIHRvcDo0MHB4O1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAud2hpdGVfZGl2e1xyXG4gICAgICAgICAgICBoZWlnaHQ6MTMwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOjEzMHB4O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgIGxlZnQ6NTAlO1xyXG4gICAgICAgICAgICB0b3A6NTAlO1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaW1ne1xyXG4gICAgICAgICAgICB3aWR0aDogNzBweDtcclxuICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHRvcDogNTAlO1xyXG4gICAgICAgICAgICBsZWZ0OiA1MCU7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5ib3R0b21fZGl2e1xyXG4gICAgICAgIHBhZGRpbmc6MjBweDtcclxuICAgICAgICBwYWRkaW5nLXRvcDoxMDBweDtcclxuICAgICAgICAuc2xpZGVfZGl2e1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG5cclxuICAgICAgICAgICAgLnVzZXJfYmFja3tcclxuICAgICAgICAgICAgICAgIGhlaWdodDo3MHB4O1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6NzBweDtcclxuICAgICAgICAgICAgICAgIG1pbi13aWR0aDogNzBweDtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiB0b3A7XHJcbiAgICAgICAgICAgICAgICB6LWluZGV4OiA5OTk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5iZ19pbWFnZXtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuY29udGVudF9kaXZ7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDotMjBweDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDoyNXB4O1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDogMjVweDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDo1MHB4O1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDojYjkxZDczO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDI1cHg7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjVweDtcclxuICAgICAgICAgICAgICAgIHotaW5kZXg6IDA7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OmZsZXg7XHJcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZToxNHB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuYnRuX2RpdntcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDo1MHB4O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojYjkxZDczO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxufSJdfQ== */");

/***/ }),

/***/ 69380:
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/next/next1/next1.page.html ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"main_content_div\">\n    <div class=\"back_div\">\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"light\" class=\"back_btn\"></ion-icon>\n\n      <div class=\"white_div\">\n        <img src=\"../../../../assets/statistics.png\" />\n      </div>\n    </div>\n\n    <div class=\"bottom_div\">\n      <ion-slides [options]=\"slideOpts\">\n        <ion-slide *ngFor=\"let item of students\">\n          <div class=\"slide_div\">\n            <div class=\"user_back bg_image\" [style.backgroundImage]=\"'url( '+item.img+' )'\"></div>\n            <div class=\"content_div\">\n              <ion-label>{{item.name}}</ion-label>\n            </div>\n          </div>\n        </ion-slide>\n      </ion-slides>\n\n      <div class=\"btn_div\">\n        <ion-button (click)=\"goToSubjectDetails()\" fill=\"outline\" shape=\"round\">\n          Next\n        </ion-button>\n      </div>\n    </div>\n  </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_next_next1_next1_module_ts.js.map